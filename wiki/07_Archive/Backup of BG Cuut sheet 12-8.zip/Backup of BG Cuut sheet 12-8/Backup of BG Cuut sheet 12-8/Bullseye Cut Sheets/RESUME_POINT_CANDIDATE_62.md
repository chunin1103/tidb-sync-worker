# Resume Point: Candidate #62 of 109

**Date:** December 7, 2025
**Progress:** Completed 61 of 109 cutting candidates (56%)
**Next:** Continue with Candidate #62

---

## CRITICAL REFERENCE FILES

1. **Full candidate list:** `101_Cutting_Candidates.csv` (actually 109 candidates)
2. **Inventory data:** `Bullseye Cut Sheet Sample File 12-5-25.csv`
3. **Cutting reference guide:** `CUTTING_REFERENCE_GUIDE.md`
4. **Previous decisions (1-20):** `RESUME_POINT_CANDIDATE_21.md`
5. **Previous decisions (21-35):** `RESUME_POINT_CANDIDATE_36.md`

---

## PRIORITY STRUCTURE FOR EXPORT

**Priority 1:** Original 30 plans (zeros with cutting plans) - from earlier sessions
**Priority 2:** Tier 1 of 109 - Zero Stock (Skipped) - Candidates 1-22
**Priority 3:** Tier 2 of 109 - Could Improve - Candidates 23-109

Export will have Priority column so warehouse knows cutting order.

---

## KEY RULES

### 1. Skip Rule (Added This Session)
**If all children (excluding the biggest available piece) have 0.25+ years (91+ days), DON'T CUT.**
- Applies to Tier 2 only (zeros still get addressed)
- No exceptions for dead stock - 91+ days is always enough for today
- Revisit later when stock drops

### 2. Cutting Yields
- **1 Half** → 2×10×10 + 2×5×10 (BOTH!)
- **1×10×10** → 2×5×10 OR 4×5×5
- **1×5×10** → 2×5×5

### 3. Decision Framework
1. **Get products off zero** (prevent stockouts)
2. **Optimize balance** (0.25+ years = 91+ days target)
3. **Minimize labor** (simplest solution that works)

### 4. Don't Create New Zeros
- NEVER cut ALL of a size (unless 0 sales)
- Always leave at least 1 piece if it sells
- Exception: If purchased = 0 for that size

### 5. Use Overstocked Sizes First
- If 10×10 is overstocked, cut that instead of Half
- If 5×10 is overstocked, cut that to make 5×5
- Save Half for when truly needed

### 6. Low Volume Products
- Keep all sizes in stock when possible
- Don't create zeros even if sales are low (1-2/yr)
- Customer availability matters

### 7. FLAG FOR REORDER
When we can't cut because:
- Half is the problem size (can't cut source)
- Only 1 Half and it sells
- Limited source would create zero

---

## DECISIONS FOR CANDIDATES 21-61

### Tier 1 (Zero Stock - Skipped) - Candidates 21-22

| # | Glass Type | Parent ID | Decision | Details |
|---|------------|-----------|----------|---------|
| 21 | Light Silver Gray Transparent Silver Iridescent | 159082 | CUT | 1 Half + cascade 1×5×10→5×5 |
| 22 | White Olive Green Gold Pink Mottle Mix | 179505 | CUT | 1×10×10→2×5×10 (use overstocked 10×10) |

### Tier 2 (Could Improve) - Candidates 23-61

| # | Glass Type | Parent ID | Decision | Details |
|---|------------|-----------|----------|---------|
| 23 | Red Opalescent | 445 | CUT | 5 Half (FLAG FOR REORDER) |
| 24 | Clear Egyptian Blue Opal Streaky | 6968 | CUT | 3 Half |
| 25 | Reactive Cloud Opalescent | 6822 | CUT | 1 Half (FLAG FOR REORDER) |
| 26 | Canary Yellow Opalescent | 8304 | CUT | 2 Half + cascade 2×5×10→5×5 |
| 27 | Peacock Blue Transparent Rainbow Iridescent | 172007 | DON'T CUT | FLAG FOR REORDER - only 1 Half sells 3/yr |
| 28 | Aventurine Green Transparent | 827 | CUT | 2 Half |
| 29 | Turquoise Blue Opalescent | 401 | DON'T CUT | FLAG FOR REORDER - Half is problem size |
| 30 | Tan Transparent | 15044 | CUT | 2 Half (dead stock conversion) |
| 31 | Light Green White Opal Streaky | 166670 | CUT | 1 Half (FLAG FOR REORDER) |
| 32 | Spring Green Opalescent | 457 | CUT | 3 Half |
| 33 | Copper Blue White Opal | 169757 | CUT | 2 Half |
| 34 | Clear Black Opal Streaky | 9699 | CUT | 2 Half |
| 35 | Olive Green Opal Forest Green Deep Brown Streaky | 16451 | CUT | 2 Half + cascade 1×5×10→5×5 |
| 36 | Light Bronze Transparent Gold Iridescent | 163659 | CUT | 1 Half |
| 37 | Lily Pad Green Transparent | 161099 | CUT | 2 Half |
| 38 | Blue Opal Plum Streaky | 160903 | CUT | 1 Half |
| 39 | French Vanilla Opalescent | 470 | CUT | 7 Half (FLAG FOR REORDER - massive 5×10 overstock) |
| 40 | Glacier Blue Opalescent | 163624 | CUT | 3 Half |
| 41 | White Aventurine Green Streaky | 168538 | DON'T CUT | FLAG FOR REORDER - only 1 Half at 91 days |
| 42 | Deep Royal Purple Transparent | 9104 | CUT | 3 Half |
| 43 | Yellow Opalescent Deep Forest Green Streaky | 8317 | CUT | 1 Half + cascade 1×5×10→5×5 |
| 44 | Light Coral Transparent | 15593 | CUT | 1×10×10→2×5×10 (use overstocked 10×10) |
| 45 | French Vanilla Light Turquoise Blue Infusion Streaky | 159865 | CUT | 1 Half |
| 46 | Aventurine Bronze Transparent | 181596 | CUT | 3 Half (FLAG FOR REORDER) |
| 47 | Aquamarine Blue Transparent | 16336 | CUT | 2 Half + 1×10×10→5×10 + cascade 1×5×10→5×5 |
| 48 | Woodland Brown Opal Ivory Black Streaky | 6074 | CUT | 2×10×10→4×5×10 (use overstocked 10×10) |
| 49 | Clear Rainbow Mardi Gras | 169141 | CUT | 1×10×10→2×5×10 (use overstocked 10×10) |
| 50 | Golden Green Opalescent | 16316 | CUT | 1×5×10→2×5×5 |
| 51 | French Vanilla Opal Light Turquoise Blue Wispy Streaky | 8840 | CUT | 1 Half |
| 52 | Cream Opalescent | 9244 | DON'T CUT | FLAG FOR REORDER - Half is problem size |
| 53 | Ming Green Transparent Tint | 164864 | DON'T CUT | FLAG FOR REORDER - Half is problem size |
| 54 | Crystal Clear Transparent | 1106 | CUT | 2×10×10→4×5×10 (use overstocked 10×10) |
| 55 | Powder Blue Opal Marine Blue Trans | 172131 | DON'T CUT | FLAG FOR REORDER - only 1 Half sells 3/yr |
| 56 | Mink Opalescent | 10012 | DON'T CUT | FLAG FOR REORDER - low volume, keep all sizes |
| 57 | Kelly Green Transparent Rainbow Iridescent | 155892 | CUT | 1 Half |
| 58 | Light Plum Transparent | 16361 | CUT | 1 Half |
| 59 | Robin's Egg Blue Opalescent | 163629 | CUT | 4 Half |
| 60 | Clear Aventurine Blue Streaky | 8087 | CUT | 3 Half |
| 61 | Caribbean Blue White Streaky | 6050 | DON'T CUT | FLAG FOR REORDER - only 1 Half at 73 days |

---

## STATISTICS FOR CANDIDATES 21-61

**Total Reviewed:** 41 candidates
**CUT Decisions:** 32 (78%)
**DON'T CUT Decisions:** 9 (22%)

### DON'T CUT Reasons:
- FLAG FOR REORDER - Half is problem size: 3 (#29, #52, #53)
- FLAG FOR REORDER - Only 1 Half that sells: 4 (#27, #55, #56, #61)
- FLAG FOR REORDER - Half at threshold: 1 (#41)
- FLAG FOR REORDER - Low volume keep all sizes: 1 (#56)

### Cutting Patterns Used:
- Cut Half only: 22
- Cut Half + cascade: 4 (#21, #26, #35, #43)
- Cut Half + 10×10 + cascade: 1 (#47)
- Cut 10×10 only: 5 (#22, #44, #48, #49, #54)
- Cut 5×10 only: 1 (#50)

---

## KEY LEARNINGS FROM CANDIDATES 21-61

### 1. Use Overstocked 10×10 Before Half
- Candidates #22, #44, #48, #49, #54: Cut 10×10 instead of Half
- Saves Half for future needs
- Uses up overstock

### 2. Low Volume = Keep All Sizes
- Candidate #56: Only 15/yr total - keep all sizes in stock
- Customer availability matters more than optimization

### 3. Half as Problem Size = Can't Cut
- When Half is the minimum AND sells, nothing we can do
- Must FLAG FOR REORDER from Bullseye

### 4. Cascade When It Makes Sense
- Only cascade when 5×5 needs help AND 5×10 is overstocked
- Don't cascade just because we can

### 5. Good Enough vs Perfect
- User preferred Cut 2 over Cut 3 when difference was marginal (#26, #40)
- Save labor for more items
- Revisit later if needed

---

## HOW TO CONTINUE

### Next Candidate: #62

**Command to get data:**
```bash
grep "^62," "Bullseye Cut Sheets/101_Cutting_Candidates.csv"
```

### Quick Check Process:
1. Get candidate data
2. **Skip Rule Check:** Are all children (excluding biggest available) at 0.25+ years?
   - YES → DON'T CUT (skip quickly)
   - NO → Continue analysis
3. Identify problem size(s)
4. Check source availability
5. Recommend cut or DON'T CUT with reason

### Format for Each Candidate:

```markdown
## Candidate #[X] of 109: [Glass Type]

**Parent ID:** [ID]
**Total Annual Sales:** [X] pieces/year

### CURRENT INVENTORY:

| Size | Qty | Sales/yr | **Years (Days)** |
|------|-----|----------|------------------|
| Half | X | X | X.XXX (XXX days) |
| 10×10 | X | X | X.XXX (XXX days) |
| 5×10 | X | X | X.XXX (XXX days) |
| 5×5 | X | X | X.XXX (XXX days) |

### RECOMMENDATION:

**[CUT or DON'T CUT]: [Operation]**

### AFTER CUTTING:

| Size | After | Years (Days) |
|------|-------|--------------|
| [sizes with results] |

**Min: X.XXX years (XXX days)**
```

---

## REMAINING WORK

- **Completed:** 61 of 109 (56%)
- **Remaining:** 48 candidates (#62-109)
- All remaining are Tier 2 (Could Improve - no zeros)

### After 109 Candidates:
- Compile all decisions into final export
- Add Priority column for warehouse
- Generate Excel cut sheets

---

## SESSION NOTES

**This Session:** Reviewed candidates 21-61 (41 candidates)
**Decisions:** 32 CUT, 9 DON'T CUT
**Key Patterns:** Use overstocked sizes first, keep all sizes for low volume, FLAG FOR REORDER when Half is problem
**User Feedback:** Prefer conservative cuts, save labor, good enough over perfect

**Resume from Candidate #62!**
