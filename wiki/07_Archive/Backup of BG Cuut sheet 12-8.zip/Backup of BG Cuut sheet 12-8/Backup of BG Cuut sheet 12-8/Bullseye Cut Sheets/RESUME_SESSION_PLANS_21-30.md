# Quick Start: Resume Excel Rules Learning - Plans 21-30

**For the next Claude Code session:**

---

## What's Been Done

✅ **Plans 1-20 reviewed and confirmed** (see `SESSION_SUMMARY_2025-12-07_EXCEL_RULES_LEARNING.md`)

✅ **Complete rule set learned through Q&A**

---

## What You Need to Do

### **Continue with Plan #21 and work through Plan #30**

---

## How to Continue (Copy This Format)

### For Each Plan:

1. **Read the plan from optimizer output:**
   ```bash
   grep "^[PLAN_NUMBER]," "Balanced_Cutting_Instructions.csv"
   ```

2. **Get inventory data:**
   ```bash
   grep ",[PARENT_ID]," "Bullseye Cut Sheet Sample File 12-5-25.csv"
   ```

3. **Present in this format:**

```
## Plan #[X]: [Glass Type]

**Priority:** [X]
**Parent ID:** [PARENT_ID]
**Total Purchased:** [X]/year

---

### Current Inventory:

| Size | Product_ID | Qty | Purchased/yr | Years (Days) |
|------|------------|-----|--------------|--------------|
| Half Sheet | [ID] | [qty] | [purchases] | [years] ([days]) |
| 10×10 | [ID] | [qty] | [purchases] | [years] ([days]) |
| 5×10 | [ID] | [qty] | [purchases] | [years] ([days]) |
| 5×5 | [ID] | [qty] | [purchases] | [years] ([days]) |

---

### Optimizer Plan: [Description]

**After Cutting:**

| Size | Pieces | Years (Days) | vs 0.25 Threshold |
|------|--------|--------------|-------------------|
| Half | [X] | [years] ([days]) | ✓/❌ |
| 10×10 | [X] | [years] ([days]) | ✓/❌ |
| 5×10 | [X] | [years] ([days]) | ✓/❌ |
| 5×5 | [X] | [years] ([days]) | ✓/❌ |

**Min: [years] ([days])**

---

### Analysis:

[Apply decision framework - see below]

**Plan #[X] confirmed: [Decision]?**
```

4. **Wait for user confirmation ("yes" or discussion)**

5. **Move to next plan**

---

## Decision Framework (Quick Reference)

### The Three Priorities (In Order):
1. **Get products off zero** (prevent stockouts)
2. **Optimize balance** (0.25+ years = 91+ days target)
3. **Minimize labor** (maximize throughput)

### Key Rules:

**Source Material:**
- Limited Half Sheets (2-3 available) → cut minimum, accept low coverage
- Good Half Sheets (4+ available) → cut enough to not revisit soon

**Don't Create New Zeros:**
- Never cut ALL of a size

**Labor Throughput:**
- "Good enough" on 15 products > "perfect" on 10 products
- Cut 2 vs 3 from same bin = negligible IF it prevents revisiting
- But don't over-optimize past 0.25 years if simpler achieves goal

**Special Cases:**
- Cascade cutting: Use produced pieces, show net in Steps/Labels/Deltas
- Cutting from 10×10: When heavily overstocked (3+ years), apply "good enough" rule
- Zero on slow seller: Low risk but still avoid creating it

**Watch For:**
- 0 purchased/year → flag and ask
- Partial size sets (5×5 InActive) → note it
- Demand mismatches → flag for Bullseye reorder

---

## Files You Need

1. **Optimizer output:** `Balanced_Cutting_Instructions.csv`
2. **Inventory data:** `Bullseye Cut Sheet Sample File 12-5-25.csv`
3. **Complete rules learned:** `SESSION_SUMMARY_2025-12-07_EXCEL_RULES_LEARNING.md`

---

## Expected Output

### After completing all 30 plans:

You should have a complete understanding of:
- When to accept minimal coverage vs push for better balance
- How to handle cascade cutting in Excel output
- When to cut from inventory (10×10s) vs Half Sheets
- Labor throughput tradeoffs
- All edge cases and special situations

Then update:
1. Excel generator code with finalized rules
2. Optimizer threshold (0.25 years instead of 0.5)
3. Add simplification detection
4. Add reorder flagging

---

## Current Progress

**Completed:** Plans 1-20 ✓
**Remaining:** Plans 21-30
**Estimated time:** ~1-2 hours at current pace

---

**Start Command:**

```bash
grep "^21," "Balanced_Cutting_Instructions.csv"
```

Then get Parent_ID and search inventory CSV.

**Good luck!**
