import csv
from collections import defaultdict
import sys

csv_file = r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye Cut Sheet Sample File 12-5-25.csv"

parents = defaultdict(lambda: {
    'Half': {'qty': 0, 'purchased': 0},
    '10x10': {'qty': 0, 'purchased': 0},
    '5x10': {'qty': 0, 'purchased': 0},
    '5x5': {'qty': 0, 'purchased': 0},
    'name': ''
})

with open(csv_file, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        product_name = row.get('Product_Name', '')
        status = row.get('Products Status', '')
        has_size = any(size in product_name for size in ['10"x10"', '5"x10"', '5"x5"', 'Half Sheet'])
        is_3mm = '3mm' in product_name
        if not (has_size and is_3mm and status == 'Active'):
            continue
        parent_id = row.get('Products_Parent_Id', '').strip()
        if not parent_id:
            continue
        qty = int(float(row.get('Quantity_in_Stock', 0) or 0))
        purchased = int(float(row.get('Purchased', 0) or 0))
        if not parents[parent_id]['name']:
            name = product_name
            for suffix in [' Half Sheet', ' 10"x10"', ' 5"x10"', ' 5"x5"', ' 3mm']:
                name = name.replace(suffix, '')
            parents[parent_id]['name'] = name
        size = None
        if 'Half Sheet' in product_name:
            size = 'Half'
        elif '10"x10"' in product_name:
            size = '10x10'
        elif '5"x10"' in product_name:
            size = '5x10'
        elif '5"x5"' in product_name:
            size = '5x5'
        if size:
            parents[parent_id][size]['qty'] += qty
            parents[parent_id][size]['purchased'] += purchased

# Load original 30 and new 121
original_30 = set()
with open('Balanced_Cutting_Instructions.csv', 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        original_30.add(row['Parent_ID'])

new_121 = set()
with open('101_Cutting_Candidates.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        new_121.add(row['Parent_ID'])

# Find zeros can't cut
zeros_cant_cut = []
for parent_id, data in parents.items():
    if parent_id in original_30 or parent_id in new_121:
        continue

    sizes = ['Half', '10x10', '5x10', '5x5']
    existing_sizes = sum(1 for s in sizes if data[s]['qty'] > 0 or data[s]['purchased'] > 0)
    has_half = data['Half']['qty'] > 0
    has_zero = any(data[s]['qty'] == 0 and data[s]['purchased'] > 0 for s in sizes)

    if existing_sizes > 1 and (not has_half or existing_sizes < 3) and has_zero:
        zero_sizes = [s for s in sizes if data[s]['qty'] == 0 and data[s]['purchased'] > 0]
        total_sales = sum(data[s]['purchased'] for s in sizes)

        reason = []
        if not has_half:
            reason.append('No Half Sheets')
        if existing_sizes < 3:
            reason.append(f'Only {existing_sizes} sizes')

        zeros_cant_cut.append({
            'parent_id': parent_id,
            'name': data['name'],
            'total_sales': total_sales,
            'zero_sizes': zero_sizes,
            'reason': ', '.join(reason),
            'data': data
        })

zeros_cant_cut.sort(key=lambda x: -x['total_sales'])

# Get range to display
start = int(sys.argv[1]) if len(sys.argv) > 1 else 1
count = int(sys.argv[2]) if len(sys.argv) > 2 else 5
end = min(start + count - 1, len(zeros_cant_cut))

print(f"ZEROS CAN'T CUT: #{start}-{end} of {len(zeros_cant_cut)}")
print("=" * 70)
print()

for i in range(start - 1, end):
    item = zeros_cant_cut[i]
    data = item['data']

    print(f"## #{i+1}: {item['name']}")
    print(f"**Parent ID:** {item['parent_id']}")
    print(f"**Total Sales:** {item['total_sales']}/yr")
    print(f"**Why Can't Cut:** {item['reason']}")
    print()
    print("| Size | Qty | Sales/yr | Years (Days) |")
    print("|------|-----|----------|--------------|")
    for size in ['Half', '10x10', '5x10', '5x5']:
        qty = data[size]['qty']
        purchased = data[size]['purchased']
        if qty > 0 or purchased > 0:
            if qty == 0 and purchased > 0:
                years_days = "**ZERO**"
            elif purchased > 0:
                years = qty / purchased
                days = int(years * 365)
                years_days = f"{years:.3f} ({days} days)"
            else:
                years_days = "N/A (no sales)"
            print(f"| {size} | {qty} | {purchased} | {years_days} |")
    print()
    print(f"**My Assessment:** FLAG FOR BULLSEYE REORDER - Can't cut, no Half Sheets")
    print()
    print("-" * 70)
    print()

print(f"Showing {start}-{end} of {len(zeros_cant_cut)}")
