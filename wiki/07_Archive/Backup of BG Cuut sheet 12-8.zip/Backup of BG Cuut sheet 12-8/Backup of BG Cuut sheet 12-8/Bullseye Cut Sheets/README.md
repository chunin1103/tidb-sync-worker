# Bullseye Glass Cutting Optimizer

**Purpose:** Weekly cut sheet planning for ArtGlassSupplies.com

Optimizes cutting of existing inventory to fill gaps between Bullseye orders using balanced optimization that minimizes risk across all sizes.

---

## Quick Start

### Step 1: Run the Optimizer

```bash
python glass_cutting_optimizer_balanced.py
```

**Input:** Place your inventory CSV export in this folder as:
`Bullseye Cut Sheet Sample File [DATE].csv`

**Output:** `Balanced_Cutting_Instructions.csv` (30 cutting plans)

### Step 2: Generate Excel Work Order

```bash
python generate_work_order_excel.py
```

**Output:** `Bullseye_Work_Order_[DATE].xlsx` (4-tab Excel file)

---

## What It Does

1. **Analyzes** your current inventory by glass type
2. **Identifies** products with zero inventory (TOP PRIORITY)
3. **Optimizes** cutting to balance Years_in_Stock across all sizes
4. **Generates** prioritized cutting instructions for staff

**Goal:** Maximize the MINIMUM Years_in_Stock to minimize risk of ANY size running out.

**Phase 2 Enhancement:** Smart business rules (5 total) with explicit priorities:

**Three Priorities (ordered):**
1. Get products off zero (prevent stockouts)
2. Optimize balance (minimize risk)
3. Minimize labor (simple operations)

**Rules Implemented:**
- ✓ Protect popular sizes from being cut (Rule #4)
- ✓ Minimize warehouse trips with cascade cutting (Rule #1)
- ✓ Prioritize getting off zero over perfect balance (Rule #2)
- ✓ Accept unavoidable byproduct accumulation (Rule #3)
- ✓ Handle extreme Half Sheet overstock intelligently (Rule #5)

See `PHASE_2_LEARNINGS.md` and `SESSION_SUMMARY_2025-12-05_EVENING.md` for complete details.

---

## Understanding the Output

### Optimizer CSV Output

The optimizer generates `Balanced_Cutting_Instructions.csv` with these columns:

| Column | Meaning |
|--------|---------|
| `Priority` | Cutting order (1 = most urgent) |
| `Glass_Type` | Which glass to cut |
| `Cut_Half_Sheets` | How many Half Sheets to cut |
| `Cut_10x10_to_5x10` | How many 10x10s to cut into 5x10s |
| `Cut_10x10_to_5x5` | How many 10x10s to cut into 5x5s |
| `Cut_5x10_to_5x5` | How many 5x10s to cut into 5x5s |
| `Before_*_Years` | Years in Stock before cutting |
| `After_*_Years` | Years in Stock after cutting |
| `Min_Years_Before` | Lowest years before (bottleneck) |
| `Min_Years_After` | Lowest years after (improved) |
| `Improvement` | How much safer this makes you |

### Priority System

**Tier 1 - CRITICAL:**
- Products with ANY size at zero inventory
- Sorted by annual sales (highest first)
- **Cut these FIRST!**

**Tier 2 - Balancing:**
- Products with low but non-zero minimum years
- Sorted by minimum years (lowest first)
- Cut these to prevent future stockouts

**Tier 3 - Well Balanced:**
- All sizes have 0.3+ years
- No cutting needed

### Excel Work Order Output

The Excel generator creates `Bullseye_Work_Order_[DATE].xlsx` with 4 tabs:

**Tab 1: Picks** - What worker pulls from warehouse
- Lists Product_IDs and SKUs to pull
- Organized by cutting plan priority

**Tab 2: Steps** - Cutting instructions with outcomes
- Shows: "Cut 1 Half Sheet" → "(2) 10×10, (4) 5×5"
- Final targets after all operations (cascade included)

**Tab 3: Barcode_Labels** - Labels to print
- Code 128 barcodes encoding Product_ID
- Only for pieces going back on shelf (net > 0)

**Tab 4: Inventory_Deltas** - System updates
- Shows Qty_before, Qty_after, Net_Change
- Only includes sizes with changes (net ≠ 0)

**Example (Plan #18):**
- Picks: Pull 1 Half Sheet
- Steps: Cut 1 Half Sheet → (2) 10×10, (4) 5×5
- Labels: Print 2 for 10×10, 4 for 5×5
- Deltas: Half -1, 10×10 +2, 5×5 +4

See `EXCEL_GENERATOR_GUIDE.md` for complete format documentation.

---

## Cutting Patterns Reference

### Half Sheet (17×20)
**Primary cut produces:**
- 2 × 10x10 pieces
- 2 × 5x10 pieces
- Waste: Two 2×10 strips

### 10×10
**Options:**
- 2 × 5x10 pieces (cut in half)
- 4 × 5x5 pieces (cut in quarters)
- 1 × 5x10 + 2 × 5x5 pieces (mixed)

### 5×10
**Produces:**
- 2 × 5x5 pieces (cut in half)

### 5×5
**Never cut** - smallest retail size

---

## Important Rules

1. **Use ALL pieces** from every cut (can't waste glass)
2. **Zero inventory = top priority** always
3. **Only cut Active products** (InActive are discontinued)
4. **Match by Parent ID** (all children can be cut from each other)
5. **Weekly cycles** - you'll run this regularly between Bullseye orders

---

## Files in This Folder

### Production Tools (USE THESE)
- **`glass_cutting_optimizer_balanced.py`** - Optimizer v2.2
- **`generate_work_order_excel.py`** - Excel generator v1.0 (NEW!)
- **`Bullseye Cut Sheet Sample File 12-5-25.csv`** - Sample inventory data
- **`Balanced_Cutting_Instructions.csv`** - Optimizer output (30 plans)
- **`Bullseye_Work_Order_2025-12-07.xlsx`** - Excel output example (NEW!)

### Documentation (READ THESE)
- **`README.md`** - This file (quick reference)
- **`CONTEXT_FOR_FUTURE_SESSIONS.md`** - Complete project overview (START HERE!)
- **`EXCEL_GENERATOR_GUIDE.md`** - Excel output documentation (NEW!)
- **`PHASE_2_LEARNINGS.md`** - Complete rule documentation
- **`OPTIMIZER_FIXES_2025-12-06.md`** - v2.2 fixes documentation (NEW!)
- **`SESSION_SUMMARY_2025-12-05_EVENING.md`** - Phase 2 validation session
- **`SESSION_SUMMARY_2025-12-06.md`** - Cascade fixes & Excel generator (NEW!)
- **`GLASS_CUTTING_KNOWLEDGE.md`** - Technical reference

### Research/Development
- **`analyze_cutting_balance.py`** - Research tool
- **`balanced_cutting_optimizer.py`** - Prototype
- **`glass_cutting_optimizer_old.py`** - Original (backup)
- **`find_well_stocked.py`** - Analysis utility

---

## Data Quality Checks

The optimizer automatically checks for:

**ERRORS:**
- InActive products with inventory (should be zero)

**WARNINGS:**
- Products out of stock, not reordering, but still Active (should be InActive)

These are displayed when you run the optimizer.

---

## Example Cutting Plan

```
Priority: 1
Glass: Clear, White Streaky, Double-rolled, 3mm COE90
Parent ID: 6018

Cutting Operations:
  - Cut 10 Half Sheets
  - Cut 4 × 5x10 to 5x5

Before Cutting:
  Half:  0.367 years (22 pieces)
  10x10: 0.000 years (0 pieces)  ← OUT OF STOCK
  5x10:  0.385 years (20 pieces)
  5x5:   0.304 years (7 pieces)
  Min: 0.000 years

After Cutting:
  Half:  0.200 years (12 pieces)  ✓
  10x10: 0.190 years (20 pieces)  ✓
  5x10:  0.692 years (36 pieces)  ✓
  5x5:   0.652 years (15 pieces)  ✓
  Min: 0.190 years (MUCH BETTER!)

Improvement: +0.190 years minimum runway
```

---

## Troubleshooting

**Q: No cutting instructions generated**
- All products are well balanced!
- Or missing data (need all 4 sizes per glass type)

**Q: Too many cutting operations**
- Lots of products at zero
- This is normal if you haven't cut recently

**Q: Some glass types not showing up**
- Need all 4 sizes (Half, 10x10, 5x10, 5x5) to optimize
- Check that products are Active status
- Only processes 3mm glass currently

---

## Support

For questions or issues:
1. Check **GLASS_CUTTING_KNOWLEDGE.md** for detailed explanations
2. Review **SESSION_SUMMARY_2025-12-05.md** for examples
3. Verify your CSV has all required columns

---

## Version History

### Optimizer

**v2.2 - December 6, 2025 (Cascade Fixes)**
- **FIX:** Cascade cutting now constrained to only use produced pieces (Rule #1)
- **FIX:** Added "good enough" threshold (0.5 years) to prevent over-optimization
- **FIX:** Recognizes same-bin operations as negligible extra work
- Fixes Plans #18, #24 to use single-trip cascade operations
- See `OPTIMIZER_FIXES_2025-12-06.md` for details

**v2.1 - December 5, 2025 (Phase 2 Complete)**
- **NEW:** Priority-Based Half Sheet Overstock Decisions (Rule #5)
- **VALIDATED:** All 30 cutting plans reviewed and approved
- **VALIDATED:** All 5 Phase 2 rules working correctly
- Three explicit priorities: Get off zero > Optimize balance > Minimize labor
- Handles extreme overstock scenarios intelligently
- Biweekly cycle optimization (not weekly)
- Edge cases validated: partial size sets, multiple stockouts, extreme overstock
- See `SESSION_SUMMARY_2025-12-05_EVENING.md` for full validation results

**v2.0 - December 5, 2025 (Phase 2)**
- **NEW:** Protects popular sizes from being cut unnecessarily
- **NEW:** Cascade cutting preference (use fresh byproducts)
- **NEW:** Getting off zero prioritized over perfect balance
- **NEW:** Accepts unavoidable byproduct accumulation
- Sorts Tier 1 by total popularity (sum of sales across all sizes)
- Generates 30 optimized cutting plans (4 modified to protect bestsellers)
- See `PHASE_2_LEARNINGS.md` for detailed rule explanations

**v1.0 - December 5, 2025**
- Initial balanced optimizer
- Prioritizes zero-inventory products
- Optimizes for minimum Years_in_Stock across all sizes
- Data quality checks included
- Tested and working with production data

### Excel Generator

**v1.0 - December 7, 2025 (Initial Release)**
- Converts optimizer CSV to warehouse-friendly 4-tab Excel format
- **Picks tab:** What to pull from warehouse
- **Steps tab:** Cutting instructions with final outcomes
- **Barcode_Labels tab:** Code 128 barcodes for pieces going back on shelf
- **Inventory_Deltas tab:** System inventory updates (count in/out)
- Handles cascade cutting correctly (uses produced pieces)
- Tested on all 30 cutting plans
- See `EXCEL_GENERATOR_GUIDE.md` for complete documentation

---

*For detailed technical information, see GLASS_CUTTING_KNOWLEDGE.md, PHASE_2_LEARNINGS.md, and EXCEL_GENERATOR_GUIDE.md*
