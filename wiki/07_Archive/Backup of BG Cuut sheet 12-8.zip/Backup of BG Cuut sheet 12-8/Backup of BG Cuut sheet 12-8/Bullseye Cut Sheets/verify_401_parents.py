import csv
import re
from collections import defaultdict

# Read the main inventory file
csv_file = r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye Cut Sheet Sample File 12-5-25.csv"

parents = defaultdict(lambda: {
    'Half': {'qty': 0, 'purchased': 0},
    '10x10': {'qty': 0, 'purchased': 0},
    '5x10': {'qty': 0, 'purchased': 0},
    '5x5': {'qty': 0, 'purchased': 0},
    'name': ''
})

with open(csv_file, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)

    for row in reader:
        product_name = row.get('Product_Name', '')
        status = row.get('Products Status', '')

        has_size = any(size in product_name for size in ['10"x10"', '5"x10"', '5"x5"', 'Half Sheet'])
        is_3mm = '3mm' in product_name

        if not (has_size and is_3mm and status == 'Active'):
            continue

        parent_id = row.get('Products_Parent_Id', '').strip()
        if not parent_id:
            continue

        qty = int(float(row.get('Quantity_in_Stock', 0) or 0))
        purchased = int(float(row.get('Purchased', 0) or 0))

        if not parents[parent_id]['name']:
            parents[parent_id]['name'] = product_name

        size = None
        if 'Half Sheet' in product_name:
            size = 'Half'
        elif '10"x10"' in product_name or '10x10' in product_name:
            size = '10x10'
        elif '5"x10"' in product_name or '5x10' in product_name:
            size = '5x10'
        elif '5"x5"' in product_name or '5x5' in product_name:
            size = '5x5'

        if size:
            parents[parent_id][size]['qty'] += qty
            parents[parent_id][size]['purchased'] += purchased

# Read cutting candidates
cutting_ids = set()
with open('101_Cutting_Candidates.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        cutting_ids.add(row['Parent_ID'])

print(f"Total 3mm Active parents: {len(parents)}")
print(f"Cutting candidates (109): {len(cutting_ids)}")
print()

# Categorize each parent
categories = {
    'cutting_candidates': [],      # Already in 109 list
    'well_balanced': [],           # Min >= 0.25 years, no zeros
    'no_source': [],               # No Half Sheets OR <3 sizes (can't cut), no zeros
    'partial_sizes': [],           # Only 1-2 sizes exist
    'zeros_cant_cut': [],          # Has zeros but no source material
}

for parent_id, data in parents.items():
    if parent_id in cutting_ids:
        categories['cutting_candidates'].append(parent_id)
        continue

    sizes = ['Half', '10x10', '5x10', '5x5']

    # Count sizes that exist (have stock OR sell)
    existing_sizes = sum(1 for s in sizes if data[s]['qty'] > 0 or data[s]['purchased'] > 0)

    # Count sizes with stock
    stocked_sizes = sum(1 for s in sizes if data[s]['qty'] > 0)

    # Has Half Sheet?
    has_half = data['Half']['qty'] > 0

    # Check for zeros (sizes that sell but have no stock)
    has_zero = any(data[s]['qty'] == 0 and data[s]['purchased'] > 0 for s in sizes)

    # Calculate min years (only for sizes that sell)
    min_years = float('inf')
    for s in sizes:
        if data[s]['purchased'] > 0:
            years = data[s]['qty'] / data[s]['purchased']
            if years < min_years:
                min_years = years

    if min_years == float('inf'):
        min_years = 999  # Nothing sells

    # Categorize
    if existing_sizes <= 1:
        categories['partial_sizes'].append(parent_id)
    elif not has_half or stocked_sizes < 3:
        # No source material - can't cut
        if has_zero:
            categories['zeros_cant_cut'].append(parent_id)
        else:
            categories['no_source'].append(parent_id)
    elif min_years >= 0.25:
        categories['well_balanced'].append(parent_id)
    else:
        # Has source, could improve, but not in 109 - this is unexpected!
        # These should have been in the 109 candidates
        categories['cutting_candidates'].append(parent_id)  # Add to cutting candidates as "missed"

print("=" * 60)
print("401 PARENT BREAKDOWN VERIFICATION")
print("=" * 60)
print(f"Cutting Candidates (109 + 22 extra):  {len(categories['cutting_candidates'])}")
print(f"Well Balanced (min >= 91 days):       {len(categories['well_balanced'])}")
print(f"Zeros Can't Cut (no Half/<3 sizes):   {len(categories['zeros_cant_cut'])}")
print(f"No Source (no Half/<3 sz, no zero):   {len(categories['no_source'])}")
print(f"Partial Size Sets (1 size only):      {len(categories['partial_sizes'])}")
print("-" * 60)
total = sum(len(v) for v in categories.values())
print(f"TOTAL:                                {total}")
print()

print("=" * 60)
print("COMPARISON TO ORIGINAL 401 BREAKDOWN")
print("=" * 60)
print("""
Original Breakdown:
  - Get Cutting Plans:         30  (Priority 1 - already processed)
  - Have Zeros (Could Cut):    14  (Now in 109 as Tier 1)
  - Have Zeros (Can't Cut):    66  (Need Bullseye reorders)
  - Could Improve Balance:     87  (Now in 109 as Tier 2)
  - Well Balanced:            173  (No action needed)
  - No Source Material:        20  (Can't cut)
  - Partial Size Sets:         11  (Not cuttable)
  --------------------------------
  TOTAL:                      401
""")

print("Current Analysis:")
print(f"  - Cutting Candidates:       {len(categories['cutting_candidates'])} (30 Priority 1 + 109 reviewed = 139)")
print(f"  - Well Balanced:            {len(categories['well_balanced'])} (was 173)")
print(f"  - Zeros Can't Cut:          {len(categories['zeros_cant_cut'])} (was 66)")
print(f"  - No Source:                {len(categories['no_source'])} (was 20)")
print(f"  - Partial Sets:             {len(categories['partial_sizes'])} (was 11)")
print()

# Summary interpretation
print("=" * 60)
print("SUMMARY")
print("=" * 60)
print("[OK] 109 Cutting Candidates: COMPLETE - All 109 reviewed")
print("     68 CUT decisions, 21 DON'T CUT decisions")
print("")
print(f"[OK] Well Balanced ({len(categories['well_balanced'])}): No action needed")
print("     All sizes have 91+ days of stock")
print("")
print(f"[!!] Zeros Can't Cut ({len(categories['zeros_cant_cut'])}): FLAG FOR BULLSEYE REORDER")
print("     Have zeros but no Half Sheets or <3 sizes")
print("")
print(f"[OK] No Source ({len(categories['no_source'])}): No action possible")
print("     Can't cut - no source material available")
print("")
print(f"[OK] Partial Sets ({len(categories['partial_sizes'])}): Not applicable")
print("     Only 1 size exists - not a cutting candidate")
