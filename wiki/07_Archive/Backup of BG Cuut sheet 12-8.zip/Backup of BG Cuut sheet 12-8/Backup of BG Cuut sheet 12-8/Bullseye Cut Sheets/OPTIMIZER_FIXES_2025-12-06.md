# Optimizer Fixes - December 6, 2025

**Session Goal:** Review cascade cutting logic and fix over-optimization issues

**Status:** 4 plans reviewed, 3 issues identified, fixes documented

---

## Issues Discovered

### **Issue #1: Cascade Cutting Can Exceed Produced Pieces**

**Problem:** Optimizer recommends cutting more pieces than the Half Sheets produce, requiring extra warehouse picks.

**Examples Found:**
- **Plan #18:** Cut 1 Half (produces 2×10×10 + 2×5×10) but cut 3×5×10→5×5 (needs 1 extra pick)
- **Plan #24:** Cut 1 Half (produces 2×10×10 + 2×5×10) but cut 3×10×10→5×10 (needs 1 extra pick)

**Root Cause:** Optimizer doesn't constrain secondary cuts to only use pieces produced by primary cuts.

**Impact:** Violates Rule #1 (Minimize Warehouse Trips) - creates multi-trip operations when single trip is possible.

**Fix Required:**
```python
# Constrain cascade cuts to only use produced pieces
produced_10x10 = half_cut * 2
produced_5x10 = half_cut * 2

# Don't allow cutting more than what was produced
max_10x10_cascade = min(max_10x10_to_cut, produced_10x10)
max_5x10_cascade = min(max_5x10_to_cut, produced_5x10)
```

---

### **Issue #2: Over-Optimizing Past "Good Enough"**

**Problem:** Optimizer tries to achieve perfect mathematical balance even when current state is already operationally fine.

**Business Context:**
- Orders placed ~10 times/year (every 36 days on average)
- 0.5 years in stock = ~6 months = ~5 order cycles = plenty of safety
- Biweekly cutting cycles allow for iterative adjustment

**Example Found:**
- **Plan #20:** Optimizer recommends cutting 5 total 10×10s to achieve perfect balance
- Reality: Only need 2×10×10 cut to get 5×10 off zero with 0.5 years runway
- 5×5 already at 0.556 years (6 months) - doesn't need improvement

**Root Cause:** No "good enough" threshold - optimizer always tries to maximize minimum years.

**Impact:**
- Creates unnecessarily complex cutting plans
- Wastes labor on marginal improvements
- Reduces plan completion rates

**Fix Required:**
```python
# Define "good enough" threshold
GOOD_ENOUGH_THRESHOLD = 0.5  # 6 months = ~5 order cycles

# After getting all sizes off zero, check if we're already good enough
if min_years >= GOOD_ENOUGH_THRESHOLD:
    # Try simpler operations first
    # Only do complex cascades if significant improvement (e.g., +0.3 years)
```

---

### **Issue #3: Not Considering Operation Simplicity**

**Problem:** Optimizer doesn't recognize that repeating the same operation at the same bin location is very cheap labor-wise.

**Business Context:**
- All pieces of same SKU stored in same bin location
- Cutting 2×10×10 vs 1×10×10 at same bin:
  - Pick: Same bin, same trip
  - Cut: Same operation, just repeat
  - Label: 4 labels vs 2 labels = seconds
  - Return: Same bin location
- **Labor difference is negligible**

**Examples:**
- **Plan #20:** Cut 1 vs 2×10×10 - chose 2 for better balance (negligible extra work)
- **Plan #30:** Cut 1 vs 2×10×10 - chose 2 for better balance (negligible extra work)

**User Insight:** "Grab 2 10×10s from one bin location is easy... every SKU has a bin location of its own"

**Impact:** Optimizer may choose less balanced "simpler" option when balanced option is actually just as simple.

**Fix Required:**
```python
# When comparing cutting options from same source SKU:
# - Cutting 1 vs 2 pieces = same complexity (same bin, same operation)
# - Choose better balance when labor is equivalent
#
# Complex operations are:
# - Multiple bin locations (different parent IDs)
# - Multiple different cutting patterns
# - Cascade operations that require tracking intermediate state
#
# Not complex:
# - Repeating same cut on same SKU (cut 2×10×10 instead of 1×10×10)
```

---

## Decisions Made

### Plan #18: Red Opal White Opal Streaky
- **Current:** Cut 1 Half + 3×5×10→5×5 (2 trips)
- **Fixed:** Cut 1 Half + 2×5×10→5×5 (1 trip)
- **Reasoning:** Use only produced pieces, single trip

### Plan #20: Cranberry Pink Gold Purple White
- **Current:** Cut 4×10×10→5×10 + 1×10×10→5×5 (over-optimized)
- **Fixed:** Cut 2×10×10→5×10 (good enough)
- **Reasoning:** Gets 5×10 off zero with 0.5 years runway, 5×5 already at 0.556 years

### Plan #24: Special Production Orange Opal with Black Stripes
- **Current:** Cut 1 Half + 3×10×10→5×10 (2 trips)
- **Fixed:** Cut 1 Half + 1×10×10→5×10 (1 trip)
- **Reasoning:** Single trip, preserves Half Sheets (user values largest sheets), good balance

### Plan #30: Clear Transparent Reed Texture Rainbow Iridescent
- **Current:** Cut 2×10×10→5×10
- **Decision:** Keep as is ✓
- **Reasoning:** Already optimal, cutting 2 vs 1 is negligible work, achieves 1.000 year balance

---

## Key Learnings

### 1. Warehouse Efficiency Matters
**Single bin operations are cheap:**
- Picking 1 vs 2 pieces from same bin = negligible difference
- Same cutting operation repeated = negligible difference
- Returning to same bin = negligible difference

**Multi-bin operations are expensive:**
- Different parent IDs = different bin locations
- Different cutting patterns = cognitive load
- Tracking cascade state = complexity

### 2. "Good Enough" is a Business Decision
**Context:**
- 10 orders/year from Bullseye
- Biweekly cutting cycles
- Labor is the limiting factor (plans often incomplete)

**Threshold:**
- 0.5 years = ~6 months = ~5 order cycles = good enough
- Don't over-optimize for marginal gains
- Simpler plans = higher completion rates

### 3. Preserve Flexibility
**Half Sheets are special:**
- Largest size available
- Maximum cutting flexibility
- Can't be created from smaller pieces
- User explicitly values preserving them when possible

**Decision framework when choosing between options:**
1. Priority 1: Get products off zero
2. Priority 2: Optimize balance
3. Priority 3: Minimize labor
4. **Tiebreaker:** Preserve larger sheets when labor is equivalent

---

## Code Changes Needed

### File: `glass_cutting_optimizer_balanced.py`

**Change #1: Add Cascade Constraints**
```python
# After calculating max Half Sheets to cut
produced_10x10 = half_cut * 2
produced_5x10 = half_cut * 2

# Constrain cascade cuts to only use produced pieces
if cut_10_to_510 or cut_10_to_55:
    max_from_cascade = produced_10x10
    # Reduce max if it would exceed produced
    # ... implementation details
```

**Change #2: Add Good Enough Threshold**
```python
GOOD_ENOUGH_THRESHOLD = 0.5  # years in stock

# After finding best plan
if best and best['min'] >= GOOD_ENOUGH_THRESHOLD:
    # Check if simpler plan gets us to good enough
    # Prefer simpler if both achieve >= 0.5 years
```

**Change #3: Recognize Same-Bin Simplicity**
```python
# When comparing plans from same source SKU:
# - Don't penalize cutting 2 vs 1 (same complexity)
# - Choose better balance when labor equivalent
```

---

## Testing Required

After implementing fixes, test all 30 plans to ensure:
1. No cascade cuts exceed produced pieces
2. Plans don't over-optimize past 0.5 year threshold
3. Plans recognize same-bin operations as simple
4. All edge cases still handled correctly

---

## Related Rules

**Rule #1: Minimize Warehouse Trips - Cascade Cutting**
- Issue #1 directly violates this rule
- Fix ensures cascade cuts stay within single trip

**Rule #2: Getting Off Zero > Perfect Safety Margins**
- Issue #2 relates to this - don't over-optimize
- Fix adds explicit "good enough" threshold

**Rule #3: Minimize Labor (Priority 3)**
- Issue #3 helps clarify what "simple" means
- Same-bin operations are effectively free

---

**Next Steps:**
1. Implement code fixes in optimizer
2. Run optimizer on full dataset
3. Compare old vs new recommendations
4. Validate that 4 problem plans are fixed
5. Ensure no regressions in other 26 plans

---

*Last Updated: December 6, 2025*
*Session: Cascade cutting review and optimizer fixes*
