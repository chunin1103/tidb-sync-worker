# Session Summary - Bullseye Glass Cutting Optimizer Development
**Date:** December 5, 2025
**Business:** ArtGlassSupplies.com
**Project:** Weekly Cut Sheet Optimizer for Bullseye 3mm Sheet Glass

---

## Session Overview

Built a balanced glass cutting optimizer that minimizes risk of stockouts by balancing Years_in_Stock across all sizes (Half Sheet, 10x10, 5x10, 5x5) for weekly cut sheet planning.

---

## Key Business Learnings

### How Glass Arrives from Bullseye
- **Full Sheets:** 20" × 35" (tolerance: 20" × 32-37")
- **Shipped as:** ~2.5 half sheets per full sheet
- **Immediately cut** upon receipt into needed sizes based on demand
- **Between orders:** Run weekly cut sheets to fill inventory gaps

### Sizes Sold
1. **Half Sheet** - 17" × 20" (from cutting full sheet in half)
2. **10x10** - 10" × 10"
3. **5x10** - 5" × 10"
4. **5x5** - 5" × 5" (smallest retail size)

### Rolled Edges
- **Manufacturing feature** - All Bullseye sheets have at least one rolled edge
- **Customers expect them** - Not a defect
- **Included on final pieces:**
  - Half Sheets, 10x10, 5x10: Have rolled edges
  - 5x5: May or may not have rolled edge (depends on cut position)

### Waste Management
- All waste goes into **"Scrap Packs"** - sold to customers
- **Nothing is truly wasted**
- Don't need to minimize waste - focus on optimal inventory balance

---

## Cutting Fundamentals

### Glass is Cut by Dividing in Half
- **Only straight cuts**
- **Can only cut DOWN** (larger to smaller), never up
- **Must use ALL pieces** from each cut (can't waste the bonus pieces)

### Standard Cutting Patterns

**Half Sheet (17×20) Primary Cut:**
```
17×20 Half Sheet
├─ Cut to 17×10 + 17×10 (down the middle)
├─ Each 17×10 →
│  ├─ 10×10 (cut at 10")
│  └─ 7×10 remainder → 5×10 (cut at 5") + 2×10 waste

Result: 2×10x10 + 2×5x10 + waste (two 2×10 strips)
```

**10×10 Options:**
1. 10×10 → 2×5x10 (cut in half)
2. 10×10 → 4×5x5 (cut in half both ways)
3. 10×10 → 1×5x10 + 2×5x5 (cut once, then cut remainder)

**5×10:**
- 5×10 → 2×5x5 (cut in half)

**5×5:**
- Never cut (smallest retail size)

---

## Why Full Sheets Are Better

**Cutting Full Sheet (20×35) directly:**
- 6×10x10 + 2×5x10 (or 4×5x5)

**Cutting 2 Half Sheets separately:**
- 4×10x10 + 4×5x10

**Difference:** Full sheet gives **2 MORE 10x10s** (50% more of most valuable size!)

**Implication:** When receiving new inventory (Problem 1), cutting full sheets directly is optimal.

---

## CSV Data Structure

### File: `Bullseye Cut Sheet Sample File 12-4-25.csv`

**Key Columns:**

| Column | Description | How It Works |
|--------|-------------|--------------|
| `Product_Name` | Full description | "Bullseye Glass [Color] [Type], [Thickness] COE90 - Size [Size]" |
| `Product_ID` | Unique child SKU | Each size variant has unique ID |
| `Products_Parent_Id` | Groups same glass, different sizes | All children with same Parent ID = can be cut from each other |
| `Purchased` | Units sold in date range (1 year) | **Best indicator of demand/popularity** |
| `Quantity_in_Stock` | Current inventory | Actual count right now |
| `Years_in_Stock` | Calculated: Qty ÷ Purchased | How long current stock will last at current sales rate |
| `Reorder` | Y or N | **Manually set** - Should we reorder when out? |
| `Reorder_Quantity` | Calculated: Purchased ÷ 4 | Target: 3 months (quarter year) of stock |
| `Products Status` | Active or InActive | Active = selling, InActive = discontinued |
| `Vendor SKU` | Bullseye's SKU | For ordering (Problem 1) |

**Parent/Child Structure:**
- **Parent** = Organizational only, never sold (unless no children)
- **Children** = Actual SKUs customers buy (different sizes of same glass)
- Example: Parent 6018 has 4 children (Half, 10x10, 5x10, 5x5) - all same glass type

**Important Formulas:**
- `Years_in_Stock = Quantity_in_Stock ÷ Purchased`
- `Reorder_Quantity = Purchased ÷ 4` (quarter year target)

---

## Data Quality Checks

### Implemented Error Detection

**ERROR: InActive product has stock**
- Condition: `Status = "InActive"` AND `Quantity > 0`
- Problem: Discontinued products shouldn't have inventory
- Example found: ID 180999 has 5 units but marked InActive

**WARNING: Out of stock, Reorder=N, but still Active**
- Condition: `Reorder = "N"` AND `Quantity = 0` AND `Status = "Active"`
- Problem: Product out of stock, not reordering, but still marked Active
- Should probably be InActive
- Examples found: 17 products in sample file

---

## The Balanced Optimization Discovery

### Problem with Simple Gap-Filling

**Example: Parent 6018 (Clear, White Streaky)**

**Before Cutting:**
- Half Sheet: 22 (0.367 years)
- 10x10: 0 (0.000 years) ← OUT OF STOCK
- 5x10: 20 (0.385 years)
- 5x5: 7 (0.304 years)

**Naive Approach:** Just fill 10x10 to 0.4 years
- Need: 42 pieces
- Cut: 21 Half Sheets
- Result:
  - Half: 1 (0.017 years) ← **NEW PROBLEM!**
  - 10x10: 42 (0.400 years) ✓
  - 5x10: 62 (1.115 years) ← **OVERSTOCKED!**
  - 5x5: 7 (0.304 years)
- **Creates new imbalances!**

### The Balanced Solution

**Algorithm:**
1. Try ALL possible cutting combinations
2. Calculate Years_in_Stock for each size after each combination
3. Find the minimum Years_in_Stock across all sizes
4. **Select combination that MAXIMIZES the minimum** (maximize safety)
5. Secondary goal: Minimize range (most balanced)

**Optimal Result for Parent 6018:**
- Cut: 10 Half Sheets → 20×10x10 + 20×5x10
- Then cut: 4×5x10 → 8×5x5

**After Balanced Cutting:**
- Half: 12 (0.200 years) ✓
- 10x10: 20 (0.190 years) ✓
- 5x10: 36 (0.692 years) ✓
- 5x5: 15 (0.652 years) ✓
- **Minimum: 0.190** (vs 0.017 with naive approach!)

**Why This Works:**
- All sizes have similar runway (0.19-0.69 years)
- No single point of failure
- Depletes at similar rates for weekly cycles
- 10× better minimum than naive approach

---

## Priority System (CRITICAL)

### RULE #1: Always Get Zero-Inventory Products Off Zero FIRST

**Sorting for Cut Sheets:**

**Tier 1 - CRITICAL (Out of Stock):**
- Products with ANY size at zero inventory
- Sort by: Annual Sales (Purchased) - highest first
- These MUST be cut immediately

**Tier 2 - Balancing (All in Stock):**
- Products needing balance but no zeros
- Sort by: Minimum Years_in_Stock - lowest first
- Then by: Annual Sales - highest first

**Tier 3 - Well Balanced:**
- All sizes have 0.3+ years
- No cutting needed

**Example Prioritization:**
1. Glass A: 10x10 at ZERO, 105 annual sales → Priority 1
2. Glass B: 5x10 at ZERO, 31 annual sales → Priority 2
3. Glass C: All in stock, min 0.150 years, 41 sales → Priority 3
4. Glass D: All in stock, min 0.330 years → No cut needed

---

## Example Analysis Sessions

### Parent 6018: Clear, White Streaky

**Inventory:**
- Half: 22 (0.367 years, 60 sales)
- 10x10: 0 (0.000 years, 105 sales) ← OUT, BEST SELLER
- 5x10: 20 (0.385 years, 52 sales)
- 5x5: 7 (0.304 years, 23 sales)

**Optimal Cutting:**
- Cut 10 Half Sheets
- Cut 4×5x10 to 5x5
- Result: All sizes balanced at 0.19-0.69 years

### Parent 9100: Aqua Blue Tint & White Streaky

**Inventory:**
- Half: 3 (0.18 years, 17 sales)
- 10x10: 0 (0.000 years, 66 sales) ← OUT, BEST SELLER
- 5x10: 0 (0.000 years, 31 sales) ← OUT
- No 5x5 variant exists

**Learning:** Not all glass types have all 4 sizes. Only cut when possible.

### Parent 156460: Clear Transparent, Prismatic Texture

**Inventory:**
- Half: 0 (out)
- 10x10: 0 (out)
- 5x10: 0 (out)
- 5x5: 1 (in stock)

**Learning:** Cannot cut anything - only have smallest size. Must wait for Bullseye order.

### Parent 175067: Peacock Blue, White Opal, Streaky

**Inventory:**
- Half: 5 (0.330 years, 15 sales)
- 10x10: 6 (0.150 years, 41 sales) ← LOW, BEST SELLER
- 5x10: 9 (0.360 years, 25 sales)
- 5x5: 6 (0.300 years, 20 sales)

**Learning:** NO sizes at zero, but 10x10 is imbalanced (0.150 vs 0.300-0.360). This is Tier 2 priority - could balance proactively, but Tier 1 (zero inventory) comes first.

---

## Two Optimization Problems

### Problem 1: Full Sheet Planning (FUTURE)
**When:** Receiving new full sheets from Bullseye
**Goal:** Decide how to cut full sheets optimally based on demand
**Status:** Not yet built - needs separate tool

**Inputs:**
- Number of full sheets arriving (by glass type)
- Current inventory levels
- Historical sales (Purchased)
- Years_in_Stock for all sizes

**Output:**
- How many full sheets to cut into 6×10x10 + 2×5x10
- How many to cut into other patterns
- Optimize for predicted demand

### Problem 2: Gap Filling (CURRENT - BUILT)
**When:** Between Bullseye orders (weekly cut sheets)
**Goal:** Use existing cut inventory to fill gaps temporarily
**Status:** ✅ BUILT - `glass_cutting_optimizer_balanced.py`

**How It Works:**
1. Load inventory CSV
2. Group by Parent ID (glass type)
3. For each glass type with all 4 sizes:
   - Try all cutting combinations
   - Calculate resulting Years_in_Stock
   - Select combination that maximizes minimum
4. Prioritize: Zero inventory first, then by min years
5. Output: Cutting instructions with before/after stats

---

## Files Created This Session

### Documentation
- **`GLASS_CUTTING_KNOWLEDGE.md`** - Complete reference guide
  - Business workflow
  - Cutting patterns
  - Data structure
  - Balanced optimization algorithm
  - Priority system
  - Examples

- **`SESSION_SUMMARY_2025-12-05.md`** - This file
  - Session overview
  - All learnings
  - Decisions made
  - Examples analyzed

### Tools Built
- **`glass_cutting_optimizer_balanced.py`** - PRODUCTION optimizer
  - Uses balanced optimization
  - Prioritizes zero-inventory products
  - Generates CSV with before/after Years_in_Stock
  - Tested and working

- **`analyze_cutting_balance.py`** - Research tool
  - Explores different cutting scenarios
  - Shows impact of naive vs balanced approach
  - Used to discover optimal algorithm

- **`balanced_cutting_optimizer.py`** - Prototype
  - Proof of concept for balanced approach
  - Led to production version

### Backups
- **`glass_cutting_optimizer_old.py`** - Original simple gap-filler
  - Kept for reference
  - Shows evolution from simple to balanced

### Output Files
- **`Balanced_Cutting_Instructions.csv`** - Output format
  - Shows all cutting operations
  - Before/After Years_in_Stock for each size
  - Prioritized by urgency
  - Example: Found 2 glass types needing cuts

---

## Key Decisions & Logic

### 1. Use Parent ID, Not Name Parsing
**Decision:** Group glass by `Products_Parent_Id` instead of parsing product names
**Reason:** More accurate, handles all edge cases
**Result:** Found 271 glass types (vs 229 with name parsing)

### 2. Only Process Active Products
**Decision:** Skip InActive products entirely
**Reason:** Don't waste time cutting for discontinued items
**Implementation:** Filter `status == "Active"` before optimization

### 3. Balanced Optimization > Simple Gap-Filling
**Decision:** Use algorithm that balances ALL sizes
**Reason:** Simple gap-filling creates new imbalances
**Evidence:** Parent 6018 example (min years 0.017 vs 0.190)

### 4. Zero Inventory = Top Priority
**Decision:** Always prioritize products with zero inventory
**Reason:** Out of stock = lost sales = critical issue
**Implementation:** Sort with zeros first, then by min years

### 5. Must Use All Pieces from Cuts
**Decision:** Account for ALL pieces produced (e.g., bonus 5x10s from Half cuts)
**Reason:** Can't waste glass - all pieces must go to inventory
**Implementation:** Calculate full cascade in optimization

### 6. Weekly Cutting Cycles
**Decision:** Optimize for recurring weekly cuts, not one-time fill
**Reason:** This is ongoing operation between Bullseye orders
**Implication:** Balance matters more than hitting exact targets

---

## How to Use the Tools

### Running the Balanced Optimizer

```bash
cd "C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets"
python glass_cutting_optimizer_balanced.py
```

**Input:** `Bullseye Cut Sheet Sample File 12-4-25.csv`
**Output:** `Balanced_Cutting_Instructions.csv`

**Output Format:**
- Priority (sorted by urgency)
- Parent ID & Glass Type
- Cutting operations (Half cuts, 10x10 cuts, 5x10 cuts)
- Before Years_in_Stock (all 4 sizes)
- After Years_in_Stock (all 4 sizes)
- Min Years Before/After
- Improvement

### Interpreting Results

**Priority 1 Example:**
```
Parent: 6018
Glass: Clear, White Streaky
Cut 10 Half Sheets, Cut 4 5x10s to 5x5
Before: Half=0.367, 10x10=0.000, 5x10=0.385, 5x5=0.304
After:  Half=0.200, 10x10=0.190, 5x10=0.692, 5x5=0.652
Min: 0.000 → 0.190 (+0.190)
```

**Action:** Cut the specified amounts to balance inventory

---

## Future Enhancements Discussed

1. **Add 2mm glass support** - Currently only processes 3mm
2. **Full Sheet Planner (Problem 1)** - When receiving new inventory
3. **Adjustable thresholds** - Minimum Years_in_Stock targets
4. **Mixed 10x10 cuts** - Option to cut 10x10 → 1×5x10 + 2×5x5
5. **Cost optimization** - Minimize cutting labor
6. **Seasonal adjustments** - Account for seasonal demand patterns

---

## Technical Notes

### Optimization Algorithm Complexity
- For each glass type: O(H × T1 × T2 × F) combinations
  - H = Half Sheets available (0 to max)
  - T1 = 10x10s to 5x10 (0 to available)
  - T2 = 10x10s to 5x5 (0 to remaining)
  - F = 5x10s to 5x5 (0 to available)
- Worst case: ~20 × 40 × 40 × 60 = ~2M combinations per glass type
- Fast enough for weekly planning (runs in seconds)

### Why Maximize Minimum Works
- **Game theory concept:** Maximize the worst-case scenario
- Ensures no size becomes the weak link
- Naturally balances inventory across sizes
- Works well for recurring weekly cycles

---

## Questions for Future Sessions

1. What minimum Years_in_Stock threshold should trigger cutting? (Currently: any zero)
2. Should we proactively balance when min < 0.2 years, even if not zero?
3. How to prioritize when multiple glass types have zeros? (Currently: by sales)
4. Should we cap maximum Years_in_Stock to avoid over-cutting?
5. How to handle seasonal variations in demand?

---

## Session Metrics

- **Files created:** 7
- **Glass types analyzed:** 4 detailed examples
- **Optimization approach:** Evolved from simple to balanced
- **Production tool:** Built and tested successfully
- **Documentation:** Comprehensive knowledge base created
- **Data quality checks:** 2 error types implemented

---

*This summary captures all processes, logic, and data from the December 5, 2025 session.
All information can be understood and recreated in future sessions using this document and the referenced files.*
