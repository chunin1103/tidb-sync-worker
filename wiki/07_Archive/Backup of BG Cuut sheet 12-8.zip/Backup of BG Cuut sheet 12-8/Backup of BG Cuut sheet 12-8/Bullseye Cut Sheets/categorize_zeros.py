import csv
from collections import defaultdict

csv_file = r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye Cut Sheet Sample File 12-5-25.csv"

parents = defaultdict(lambda: {
    'Half': {'qty': 0, 'purchased': 0},
    '10x10': {'qty': 0, 'purchased': 0},
    '5x10': {'qty': 0, 'purchased': 0},
    '5x5': {'qty': 0, 'purchased': 0},
    'name': ''
})

with open(csv_file, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        product_name = row.get('Product_Name', '')
        status = row.get('Products Status', '')
        has_size = any(size in product_name for size in ['10"x10"', '5"x10"', '5"x5"', 'Half Sheet'])
        is_3mm = '3mm' in product_name
        if not (has_size and is_3mm and status == 'Active'):
            continue
        parent_id = row.get('Products_Parent_Id', '').strip()
        if not parent_id:
            continue
        qty = int(float(row.get('Quantity_in_Stock', 0) or 0))
        purchased = int(float(row.get('Purchased', 0) or 0))
        if not parents[parent_id]['name']:
            name = product_name
            for suffix in [' Half Sheet', ' 10"x10"', ' 5"x10"', ' 5"x5"', ' 3mm']:
                name = name.replace(suffix, '')
            parents[parent_id]['name'] = name
        size = None
        if 'Half Sheet' in product_name:
            size = 'Half'
        elif '10"x10"' in product_name:
            size = '10x10'
        elif '5"x10"' in product_name:
            size = '5x10'
        elif '5"x5"' in product_name:
            size = '5x5'
        if size:
            parents[parent_id][size]['qty'] += qty
            parents[parent_id][size]['purchased'] += purchased

# Load original 30 and new 121 candidates
original_30 = set()
with open(r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Balanced_Cutting_Instructions.csv", 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        original_30.add(row['Parent_ID'])

new_121 = set()
with open(r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\101_Cutting_Candidates.csv", 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        new_121.add(row['Parent_ID'])

# Find zeros - categorize properly
zeros_can_cut = []
zeros_cant_cut = []

for parent_id, data in parents.items():
    if parent_id in original_30 or parent_id in new_121:
        continue

    sizes = ['Half', '10x10', '5x10', '5x5']
    existing_sizes = sum(1 for s in sizes if data[s]['qty'] > 0 or data[s]['purchased'] > 0)
    has_half = data['Half']['qty'] > 0
    has_zero = any(data[s]['qty'] == 0 and data[s]['purchased'] > 0 for s in sizes)

    if existing_sizes > 1 and (not has_half or existing_sizes < 3) and has_zero:
        zero_sizes = [s for s in sizes if data[s]['qty'] == 0 and data[s]['purchased'] > 0]
        total_sales = sum(data[s]['purchased'] for s in sizes)

        can_cut = False
        cut_instruction = []

        if '5x5' in zero_sizes and (data['5x10']['qty'] > 0 or data['10x10']['qty'] > 0):
            can_cut = True
            if data['5x10']['qty'] > 0:
                cut_instruction.append('5x10 -> 5x5')
            if data['10x10']['qty'] > 0:
                cut_instruction.append('10x10 -> 5x5')

        if '5x10' in zero_sizes and data['10x10']['qty'] > 0:
            can_cut = True
            cut_instruction.append('10x10 -> 5x10')

        if can_cut:
            zeros_can_cut.append({
                'parent_id': parent_id,
                'name': data['name'],
                'total_sales': total_sales,
                'zero_sizes': zero_sizes,
                'cut_instruction': ' OR '.join(cut_instruction),
                'data': data
            })
        else:
            reason = []
            if not has_half:
                reason.append('No Half Sheets')
            needs_5x5 = '5x5' in zero_sizes
            needs_5x10 = '5x10' in zero_sizes
            needs_10x10 = '10x10' in zero_sizes
            if needs_5x5 and data['5x10']['qty'] == 0 and data['10x10']['qty'] == 0:
                reason.append('No source for 5x5')
            if needs_5x10 and data['10x10']['qty'] == 0:
                reason.append('No source for 5x10')
            if needs_10x10 and data['Half']['qty'] == 0:
                reason.append('No source for 10x10')

            zeros_cant_cut.append({
                'parent_id': parent_id,
                'name': data['name'],
                'total_sales': total_sales,
                'zero_sizes': zero_sizes,
                'reason': ', '.join(reason) if reason else 'No cutting source',
                'data': data
            })

zeros_can_cut.sort(key=lambda x: -x['total_sales'])
zeros_cant_cut.sort(key=lambda x: -x['total_sales'])

# Write CSV for low priority cuts
with open(r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Low_Priority_Cuts.csv", 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['Priority', 'Parent_ID', 'Glass_Type', 'Zero_Sizes', 'Cut_Instruction', 'Total_Sales',
                     'Half_Qty', 'Half_Sales', '10x10_Qty', '10x10_Sales', '5x10_Qty', '5x10_Sales', '5x5_Qty', '5x5_Sales'])
    for i, item in enumerate(zeros_can_cut, 1):
        d = item['data']
        writer.writerow([
            i, item['parent_id'], item['name'], ', '.join(item['zero_sizes']), item['cut_instruction'], item['total_sales'],
            d['Half']['qty'], d['Half']['purchased'],
            d['10x10']['qty'], d['10x10']['purchased'],
            d['5x10']['qty'], d['5x10']['purchased'],
            d['5x5']['qty'], d['5x5']['purchased']
        ])

# Write CSV for Bullseye reorder flags
with open(r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye_Reorder_Flags.csv", 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['Priority', 'Parent_ID', 'Glass_Type', 'Zero_Sizes', 'Reason', 'Total_Sales',
                     'Half_Qty', 'Half_Sales', '10x10_Qty', '10x10_Sales', '5x10_Qty', '5x10_Sales', '5x5_Qty', '5x5_Sales'])
    for i, item in enumerate(zeros_cant_cut, 1):
        d = item['data']
        writer.writerow([
            i, item['parent_id'], item['name'], ', '.join(item['zero_sizes']), item['reason'], item['total_sales'],
            d['Half']['qty'], d['Half']['purchased'],
            d['10x10']['qty'], d['10x10']['purchased'],
            d['5x10']['qty'], d['5x10']['purchased'],
            d['5x5']['qty'], d['5x5']['purchased']
        ])

print(f"Created: Low_Priority_Cuts.csv ({len(zeros_can_cut)} items)")
print(f"Created: Bullseye_Reorder_Flags.csv ({len(zeros_cant_cut)} items)")
print()
print("LOW PRIORITY CUTS (can cut from 10x10 or 5x10):")
for i, item in enumerate(zeros_can_cut, 1):
    print(f"  {i}. {item['name'][:50]} - {item['cut_instruction']}")
