import csv
from collections import defaultdict

input_csv = r'C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye Cut Sheet Sample File 12-5-25.csv'
output_csv = r'C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Balanced_Cutting_Instructions.csv'

# Load parents that ARE in the cutting plan
parents_in_plan = set()
with open(output_csv, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        parents_in_plan.add(row['Parent_ID'])

# Find parents with all 4 sizes and all in stock
parent_data = defaultdict(lambda: {'products': [], 'name': ''})

with open(input_csv, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)

    for row in reader:
        product_name = row['Product_Name']
        parent_id = row['Products_Parent_Id']
        status = row['Products Status']

        try:
            qty = int(float(row['Quantity_in_Stock']))
            purchased = int(row['Purchased'])
            years = float(row['Years_in_Stock'])
        except (ValueError, KeyError):
            continue

        # Only 3mm Active products
        if '3mm' not in product_name or status != 'Active':
            continue

        # Determine size
        if 'Half Sheet' in product_name or 'Half sheet' in product_name:
            size = 'Half'
        elif '10"x10"' in product_name:
            size = '10x10'
        elif '5"x10"' in product_name:
            size = '5x10'
        elif '5"x5"' in product_name or "5''x5''" in product_name:
            size = '5x5'
        else:
            continue

        parent_data[parent_id]['products'].append({
            'size': size,
            'qty': qty,
            'purchased': purchased,
            'years': years
        })

        if not parent_data[parent_id]['name']:
            clean_name = product_name.split(' - Size ')[0].replace('Bullseye Glass ', '')
            parent_data[parent_id]['name'] = clean_name

# Find parents with all 4 sizes and ALL in stock
examples = []
for parent_id, data in parent_data.items():
    # Must have all 4 sizes
    sizes = {p['size'] for p in data['products']}
    if sizes != {'Half', '10x10', '5x10', '5x5'}:
        continue

    # Must NOT be in cutting plan
    if parent_id in parents_in_plan:
        continue

    # All sizes must have stock
    if all(p['qty'] > 0 for p in data['products']):
        examples.append((parent_id, data))
        if len(examples) >= 2:
            break

# Display examples
print('Examples of parents EXCLUDED from cutting (all sizes have stock):\n')
print('='*80)

for i, (parent_id, data) in enumerate(examples, 1):
    print(f'Example {i}: {data["name"]}')
    print(f'Parent ID: {parent_id}')
    print(f'\nInventory Status:')

    # Sort by size order
    size_order = ['Half', '10x10', '5x10', '5x5']
    for size in size_order:
        product = next(p for p in data['products'] if p['size'] == size)
        print(f'  {size:6} - Qty: {product["qty"]:3} | Purchased/yr: {product["purchased"]:3} | Years in stock: {product["years"]:.3f}')

    # Calculate min years
    min_years = min(p['years'] for p in data['products'])
    print(f'\nMinimum Years in Stock: {min_years:.3f}')
    print(f'Status: All sizes have inventory - NO CUTTING NEEDED')
    print('='*80)
    print()
