# Resume Point: Candidate #36 of 109

**Date:** December 7, 2025
**Progress:** Completed 35 of 109 cutting candidates (32%)
**Next:** Continue with Candidate #36

---

## CRITICAL REFERENCE FILES

1. **Full candidate list:** `101_Cutting_Candidates.csv` (actually 109 candidates)
2. **Inventory data:** `Bullseye Cut Sheet Sample File 12-5-25.csv`
3. **Cutting reference guide:** `CUTTING_REFERENCE_GUIDE.md`
4. **Previous decisions (1-20):** `RESUME_POINT_CANDIDATE_21.md`

---

## NEW RULE (Added This Session)

**Skip Rule:** If all children (excluding the biggest available piece) have 0.25+ years (91+ days), **DON'T CUT**.
- Applies to Tier 2 only (zeros still get addressed)
- No exceptions for dead stock - 91+ days is always enough for today
- Revisit later when stock drops

---

## DECISIONS FOR CANDIDATES 21-35

### Candidate #21: Light Silver Gray Transparent Silver Iridescent (159082) - **CUT**
- **Decision: Cut 1 Half + cascade 1×5×10 → 5×5**
- Gets 5×5 off ZERO to 146 days
- Half has 0 sales - dead stock conversion

### Candidate #22: White Olive Green Gold Pink Mottle Mix (179505) - **CUT**
- **Decision: Cut 1×10×10 → 2×5×10**
- Uses overstocked 10×10 instead of Half
- Gets 5×10 off ZERO to 243 days

### Candidate #23: Red Opalescent (445) - **CUT**
- **Decision: Cut 5 Half**
- 10×10 at 4 days was critical (102 sales/yr!)
- Gets 10×10 to 39 days - FLAG FOR REORDER
- High demand product (169/yr)

### Candidate #24: Clear Egyptian Blue Opal Streaky (6968) - **CUT**
- **Decision: Cut 3 Half**
- 10×10 at 9 days was critical
- Gets 10×10 to 64 days
- Can't reach 91 days without depleting Half

### Candidate #25: Reactive Cloud Opalescent (6822) - **CUT**
- **Decision: Cut 1 Half**
- Limited source (only 2 Half)
- Gets 10×10 from 10 days to 30 days
- FLAG FOR REORDER

### Candidate #26: Canary Yellow Opalescent (8304) - **CUT**
- **Decision: Cut 2 Half + cascade 2×5×10 → 5×5**
- Gets 5×5 from 15 days to 73 days
- All sizes balanced (73-122 days)
- Min: 73 days

### Candidate #27: Peacock Blue Transparent Rainbow Iridescent (172007) - **DON'T CUT**
- Only 1 Half with 3 sales/yr - can't cut
- FLAG FOR REORDER

### Candidate #28: Aventurine Green Transparent (827) - **CUT**
- **Decision: Cut 2 Half**
- Gets 5×10 from 20 days to 61 days
- 10×10 crosses 91-day threshold

### Candidate #29: Turquoise Blue Opalescent (401) - **DON'T CUT**
- Half is the problem size (20 days) - can't cut source
- FLAG FOR REORDER

### Candidate #30: Tan Transparent (15044) - **CUT**
- **Decision: Cut 2 Half**
- Half has 0 sales - dead stock conversion
- Gets 10×10 above 91 days

### Candidate #31: Light Green White Opal Streaky (166670) - **CUT**
- **Decision: Cut 1 Half**
- Limited source (only 2 Half with 2 sales/yr)
- Gets 10×10 from 22 days to 44 days
- FLAG FOR REORDER

### Candidate #32: Spring Green Opalescent (457) - **CUT**
- **Decision: Cut 3 Half**
- Plenty of Half (13 pieces)
- Gets both 10×10 and 5×10 above 91 days
- All sizes balanced (94-365 days)

### Candidate #33: Copper Blue White Opal (169757) - **CUT**
- **Decision: Cut 2 Half**
- Gets 10×10 from 26 days to 78 days
- Keeps 1 Half for tracking

### Candidate #34: Clear Black Opal Streaky (9699) - **CUT**
- **Decision: Cut 2 Half**
- Gets 10×10 from 27 days to 81 days
- 5×10 already massively overstocked (7 years)

### Candidate #35: Olive Green Opal Forest Green Deep Brown Streaky (16451) - **CUT**
- **Decision: Cut 2 Half + cascade 1×5×10 → 5×5**
- All sizes now above 91 days
- Min: 112 days

---

## PRIORITY STRUCTURE FOR EXPORT

**Priority 1:** Original 30 plans (zeros with cutting plans)
**Priority 2:** Tier 1 of 109 - Zero Stock (Skipped) - Candidates 1-22
**Priority 3:** Tier 2 of 109 - Could Improve - Candidates 23-109

Export will have Priority column so warehouse knows cutting order.

---

## KEY LEARNINGS FROM CANDIDATES 21-35

### 1. Use Overstocked Sizes First
- Candidate #22: Cut 10×10 instead of Half (10×10 was at 1.5 years)
- Save Half for when it's truly needed

### 2. Limited Source = Cut Minimum
- Candidates #25, #27, #29, #31: Only 1-2 Half available
- Cut what you can, FLAG FOR REORDER

### 3. Can't Cut Source Material
- Candidates #27, #29: Half was the problem size
- If Half is low and sells, can't cut it - need to reorder

### 4. Cascade When It Helps
- Candidates #21, #26, #35: Cascade got 5×5 above threshold
- But only when 5×10 is overstocked

### 5. New Skip Rule
- If all children at 0.25+ years (91+ days), DON'T CUT
- Saves labor for higher priority items

---

## CUTTING YIELDS (QUICK REFERENCE)

- **1 Half** → 2×10×10 + 2×5×10 (BOTH!)
- **1×10×10** → 2×5×10 OR 4×5×5
- **1×5×10** → 2×5×5

---

## HOW TO CONTINUE

### Next Candidate: #36

**Command to get data:**
```bash
grep "^36," "Bullseye Cut Sheets/101_Cutting_Candidates.csv"
```

### Quick Check with New Rule:
1. Get candidate data
2. Check: Are all children (excluding biggest available) at 0.25+ years?
   - YES → DON'T CUT (skip quickly)
   - NO → Analyze and recommend

### Format for Each Candidate:

```markdown
## Candidate #[X] of 109: [Glass Type]

**Parent ID:** [ID]
**Total Annual Sales:** [X] pieces/year

### CURRENT INVENTORY:

| Size | Qty | Sales/yr | **Years (Days)** |
|------|-----|----------|------------------|
| Half | X | X | X.XXX (XXX days) |
| 10×10 | X | X | X.XXX (XXX days) |
| 5×10 | X | X | X.XXX (XXX days) |
| 5×5 | X | X | X.XXX (XXX days) |

### RECOMMENDATION:

**[CUT or DON'T CUT]: [Operation]**

### AFTER CUTTING:

| Size | After | Years (Days) |
|------|-------|--------------|
| [sizes with results] |

**Min: X.XXX years (XXX days)**
```

---

## REMAINING WORK

- **Completed:** 35 of 109 (32%)
- **Remaining:** 74 candidates (#36-109)
- All remaining are Tier 2 (Could Improve - no zeros)

### After 109 Candidates:
- Review 270 non-cutting parents (optional)
- Generate Excel cut sheets with Priority column

---

## SESSION NOTES

**This Session:** Reviewed candidates 21-35 (15 candidates)
**Decisions:** 12 CUT, 3 DON'T CUT
**New Rule Added:** Skip if all children at 0.25+ years
**Quality:** Good - user caught opportunities to improve recommendations

**Resume from Candidate #36 with same methodology + new skip rule!**
