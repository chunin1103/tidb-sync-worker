# Cutting Reference Guide - For Reviewing All 401 Parents

**Created:** December 7, 2025
**Purpose:** Quick reference to prevent errors during 109 candidate review

---

## CUTTING YIELDS (CRITICAL - DO NOT FORGET!)

### 1 Half Sheet Produces:
- **2×10×10** (primary)
- **2×5×10** (byproduct - ALWAYS INCLUDED!)

**Net Effect:**
- Half: -1
- 10×10: +2
- 5×10: +2
- 5×5: 0

### 1×10×10 Cut to 5×10:
- **2×5×10**

**Net Effect:**
- Half: 0
- 10×10: -1
- 5×10: +2
- 5×5: 0

### 1×10×10 Cut to 5×5:
- **4×5×5**

**Net Effect:**
- Half: 0
- 10×10: -1
- 5×10: 0
- 5×5: +4

### 1×5×10 Cut to 5×5:
- **2×5×5**

**Net Effect:**
- Half: 0
- 10×10: 0
- 5×10: -1
- 5×5: +2

---

## CASCADE CUTTING

**Definition:** Using produced pieces from earlier cuts in the same session

**Example from Plan #1:**
1. Cut 13 Half → produces 26×10×10 + 26×5×10
2. Then cut 3 of those 5×10s → produces 6×5×5
3. **Net result:** Only show net changes in Excel output

**Rule:** Cascade operations count as "single trip" - same labor session

---

## DECISION FRAMEWORK (From 30 Plans)

### Three Priorities (In Order):
1. **Get products off zero** (prevent stockouts)
2. **Optimize balance** (0.25+ years = 91+ days target)
3. **Minimize labor** (maximize throughput)

### Core Rules:

**1. Don't Create New Zeros**
- NEVER cut ALL of a size
- Always leave at least 1 piece (if possible)
- Exception: If purchased = 0 for that size

**2. Source Material Context**
- Limited (2-3 Half): Cut minimum, accept low coverage
- Available (4+ Half): Cut enough to avoid revisiting soon

**3. "Good Enough" Threshold**
- Target: 0.25 years (91 days) minimum
- If cutting achieves 0.25+, don't over-optimize
- Ask: "What if we cut X-1?" - choose simpler if it still hits threshold

**4. Labor Throughput**
- Better to address 30 products at "good enough" than 10 products perfectly
- Cutting 2 vs 3 from same bin = negligible IF prevents revisiting
- But don't add complexity for marginal gains

**5. Demand Mismatches**
- If zeros exist with very limited source → FLAG FOR REORDER
- Cutting is for bridging gaps, not solving demand problems
- Example: 1 Half but needs 50×10×10/year = reorder, not cut

---

## SPECIAL CASES

### Cutting from 10×10 (Not Half):
**When justified:**
- 10×10 heavily overstocked (1.3+ years)
- Target size at zero
- Limited or no Half Sheets available

**Still apply "good enough"** - don't over-cut

### Partial Size Sets:
- Some products missing 5×5 (InActive)
- Note it, adjust calculations accordingly
- Can't cut to missing size

### Zero Purchases:
- If purchased = 0 for a size, ignore it in calculations
- Focus on sizes that actually sell

---

## COMMON PATTERNS FROM 30 PLANS

### Pattern 1: Simple Cut (No Cascade)
- Cut X Half Sheets
- Both 10×10 and 5×10 get restocked
- Most common pattern

### Pattern 2: Cascade Cutting
- Cut X Half → produces 10×10 + 5×10
- Then cut Y of those 5×10 → produces 5×5
- Show NET result only in Excel

### Pattern 3: Cutting from 10×10
- When 10×10 overstocked (3+ years)
- Cut 10×10 → 5×10 or 5×5
- Still apply "good enough" rule

### Pattern 4: Multiple Zeros
- THREE zeros = URGENT reorder flag
- Don't try to solve with cutting
- Flag for Bullseye immediately

---

## CALCULATION TEMPLATE

For each candidate:

1. **Show Current State:**
   - Each size: Qty, Purchased/yr, Years (Days)
   - Identify zeros
   - Identify min coverage

2. **Propose Cutting Plan:**
   - What to cut (e.g., "Cut 5 Half")
   - What's produced (e.g., "→ 10×10 + 10×5×10")
   - Any cascade operations

3. **Calculate After State:**
   - Apply cutting yields CORRECTLY
   - Include ALL byproducts
   - Calculate new years for each size

4. **Evaluate Against Rules:**
   - Any new zeros created? ❌
   - Min coverage after cutting?
   - Meets 0.25 threshold? ✓
   - "Good enough" check (could we cut less?)

5. **Decision:**
   - CUT (with specific operations)
   - DON'T CUT (with reason: reorder, limited source, etc.)
   - FLAG (overstock, urgent reorder, etc.)

---

## EXAMPLE FROM PLAN #1

**Dense White Opalescent (207/year)**

**Before:**
- Half: 18 (22/yr) = 0.818 years
- 10×10: 0 (117/yr) = 0.000 years ⚠️
- 5×10: 0 (46/yr) = 0.000 years ⚠️
- 5×5: 4 (22/yr) = 0.182 years

**Plan: Cut 13 Half + cascade 3×5×10→5×5**

**After:**
- Half: 5 (22/yr) = 0.227 years ✓
- 10×10: 26 (117/yr) = 0.222 years ✓
- 5×10: 23 (46/yr) = 0.500 years ✓
- 5×5: 10 (22/yr) = 0.455 years ✓

**Min: 0.222 years (81 days)**

**Decision: ✓ Cut - addresses TWO zeros, all sizes 0.22+ years**

---

## TIER 1 VS TIER 2 (Current Task)

### Tier 1 - Zero Stock (Skipped): 22 parents
**Question for each:** Why did optimizer skip?
- Insufficient source material?
- Cutting won't reach 0.25 threshold?
- Would create new zeros?
- Better to reorder?

### Tier 2 - Could Improve: 87 parents
**Question for each:** Should we cut now or later?
- How low is min coverage? (< 30 days = critical)
- How much demand? (high demand + low coverage = urgent)
- Enough source material?
- Reaches 0.25 threshold after cutting?

---

## READY TO PROCEED

✓ Cutting yields confirmed
✓ Decision framework clear
✓ Calculation template ready
✓ Common errors identified
✓ All 30 plan patterns reviewed

**Let's review the 109 candidates correctly!**
