# Excel Generator Rules Learning Session - December 7, 2025

**Session Goal:** Learn complete rule set for Excel generator through Q&A review of all 30 cutting plans

**Status:** Plans 1-20 COMPLETE ✓ | Plans 21-30 PENDING

---

## Key Learning: The Complete Framework

### The Three Priorities (In Order):

1. **Get products off zero** (prevent stockouts → revenue loss)
2. **Optimize balance** (minimize risk across all sizes)
3. **Minimize labor** (maximize throughput → more products addressed)

Priority 1 trumps Priority 2, which trumps Priority 3.

---

## Critical Rules Learned Through Plans 1-20

### Rule #1: The 0.25 Year Threshold (91 days)
- **Target:** All sizes should ideally reach 0.25 years (91 days) coverage
- **Rationale:** ~2.5 order cycles (orders every 37 days), ~3 cutting sessions (every 14 days)
- **Old threshold was 0.5 years (183 days) - TOO CONSERVATIVE**

### Rule #2: Minimum Survival Threshold (~37 days)
- At least 1 order cycle to give time for reordering
- Sometimes accept even less if limited by source material
- Examples: Plans #7, #8, #9 had 19-33 days (minimal but acceptable)

### Rule #3: Don't Create New Zeros
- **NEVER cut ALL of a size if it creates a stockout**
- Better to have minimal coverage than create new problem
- Examples: Plans #4, #6, #7, #8, #9, #10, #13-15 all limited by this

### Rule #4: Source Material Constraints
- **Limited source = accept minimal coverage**
- When you only have 2-3 Half Sheets, cutting all creates new zero
- Cut what you can, flag for reorder, move on
- Examples: Plans #7-10 (only 2-3 Half available, slow sellers 1-3/year)

### Rule #5: Labor Throughput Over Perfect Balance
- **Real goal: Maximize products addressed per labor-hour**
- NOT: Perfect balance per product
- Simple operations → worker completes MORE products
- "Good enough" on 15 products > "perfect" on 10 products

### Rule #6: Total Labor Across Time (NEW - from Plan #11)
- Consider labor over MULTIPLE sessions, not just one
- **Better balance now = less revisiting later**
- When source material IS available, cut enough to not need to revisit soon
- Example: Plan #11 - cut 3 Half instead of 2 for 146 vs 97 days (one and done)

### Rule #7: Cutting from Inventory (10×10s) When Justified
- When source size is HEAVILY overstocked (3+ years)
- Target size is out of stock
- Limited Half Sheets available
- Example: Plan #20 - 10×10 at 3.5 years, 5×10 at zero, only 1 Half
- **BUT: Apply simplicity principle - cut minimum to achieve "good enough"**

### Rule #8: Not All Zeros Are Equal (from Plan #15 discussion)
- Zero on slow seller (1/year) = very low risk
- Zero on fast seller (27/year) = high risk
- **BUT: Cutting is for bridging gaps, NOT solving demand mismatches**
- When demand is mismatched, flag for Bullseye reorder instead of over-cutting

### Rule #9: Watch for 0 Purchased/Year
- Products with 0 purchased/year break the math (Years_in_Stock undefined)
- Usually InActive products
- If Active with 0 purchases → flag it, ask about it

### Rule #10: Cascade Cutting (Single Trip Operations)
- Use pieces produced from earlier cuts in same session
- Example: Plan #18 - Cut 1 Half → produces 2×5×10, then cut 2×5×10→5×5
- **Only count net changes in labels and inventory deltas**
- If produced 2, cut 2 → net = 0 (don't show in labels or deltas)

---

## Plan-by-Plan Decisions Summary

### Plans 1-5: Setting the Baseline

**Plan #1: Dense White Opalescent (Priority 1, 207/year)**
- Cut 13 Half + 3×5×10 cascade
- Large scale operation, high priority
- Outcome: All sizes 0.222-0.500 years ✓

**Plan #2: Red Transparent (Priority 2, 161/year)**
- Cut 5 Half + 3×5×10 cascade
- 10×10 bestseller (89/year) needed 0.112 years (41 days)
- **Learning:** For bestsellers, need enough to survive to next session (~40+ days minimum)
- Outcome: All sizes 0.112-0.447 years ✓

**Plan #3: Clear Transparent (Priority 3, 151/year)**
- **REVISED from optimizer:** Cut 5 Half instead of 7
- Optimizer wanted 7 (62 days on 10×10)
- We chose 5 (44 days on 10×10) - good enough, simpler
- **Learning:** Don't over-optimize past "good enough"
- Outcome: All sizes 0.120-0.615 years ✓

**Plan #4: Aqua Blue Tint & White Streaky (Priority 4, 132/year)**
- Cut 2 Half (only 3 available)
- TWO zeros to address (10×10 and 5×10)
- Cut 3 would create NEW zero in Half Sheets
- Outcome: Minimal coverage (22 days) but both off zero ✓

**Plan #5: Yellow Transparent (Priority 5, 111/year)**
- Cut 5 Half + 3×5×10 cascade
- All sizes 0.258-0.439 years (94-160 days)
- **Learning:** Confirmed 0.25 year threshold is right target
- Outcome: All above threshold ✓

---

### Plans 6-10: Limited Source Material Pattern

**Common pattern:** Only 2-4 Half Sheets, slow sellers (1-3/year), accept minimal coverage

**Plan #6: Deep Red Opalescent (Priority 6, 96/year)**
- Cut 2 Half (only 4 available)
- 5×10 reaches 50 days (below 0.25 threshold but acceptable)
- **Learning:** When limited, accept imperfect balance and move on

**Plan #7: Deep Royal Blue Transparent (Priority 7, 86/year)**
- Cut 1 Half (only 2 available)
- TWO zeros, minimal coverage (19 and 27 days)
- **Flag for Bullseye reorder**
- **Learning:** Sometimes barely scraping by is all you can do

**Plan #8: Dark Forest Green Opalescent (Priority 8, 85/year)**
- Cut 2 Half (only 3 available)
- 10×10 reaches 32 days (below threshold but acceptable)

**Plan #9: Clear Aventurine Blue Streaky (Priority 9, 73/year)**
- Cut 2 Half (only 3 available)
- 10×10 reaches 33 days

**Plan #10: Light Peach Cream Opalescent (Priority 10, 61/year)**
- Cut 2 Half (only 3 available)
- 10×10 reaches 46 days

---

### Plans 11-17: Better Source Material, Better Balance

**Plan #11: Egyptian Blue Opalescent (Priority 11, 50/year)**
- Cut 3 Half (4 available - better source material!)
- **KEY LEARNING:** Cut 3 vs 2 debate
- Cut 2 → 97 days minimum
- Cut 3 → 146 days minimum
- **Decision:** Cut 3 - same labor time, much better balance, won't need to revisit soon
- **New rule:** Total labor across time matters (one and done vs multiple sessions)
- Outcome: All sizes 0.400-0.800 years ✓

**Plan #12: Clear with White and Black Graffiti (Priority 12, 49/year)**
- Cut 4 Half (6 available)
- TWO zeros (10×10 and 5×10)
- Partial size set (5×5 is InActive)
- Outcome: All active sizes 0.296-0.471 years ✓

**Plan #13: Fern Green Transparent (Priority 13, 46/year)**
- Cut 2 Half (only 3 available, slow seller 1/year)
- Half overstocked at 3 years
- 10×10 reaches 50 days (acceptable given constraints)

**Plan #14: White Deep Royal Purple Cranberry Pink (Priority 14, 44/year)**
- Cut 1 Half (only 2 available)
- TWO zeros, minimal coverage (43 and 56 days)

**Plan #15: Mint Opal Deep Forest Green (Priority 15, 43/year)**
- Cut 2 Half (only 3 available)
- **KEY LEARNING:** Debate about cutting all 3 to improve 10×10
- Cut 3 would create zero on slow seller (1/year Half)
- **Decision:** Cut 2 - cutting is for bridging gaps, not solving demand mismatches
- **Flag for Bullseye reorder** - need more 10×10s
- Outcome: 10×10 at 54 days (acceptable) ✓

**Plan #16: White Opal Cranberry Pink Streaky (Priority 16, 37/year)**
- Cut 2 Half (3 available)
- Outcome: All sizes 0.308-1.000 years, well balanced ✓

**Plan #17: White Opalescent Rainbow Iridescent (Priority 17, 37/year)**
- Cut 3 Half (4 available)
- Outcome: All sizes 0.250-1.800 years ✓

---

### Plans 18-20: Special Cases

**Plan #18: Red Opal White Opal Streaky (Priority 18, 26/year) ⭐ CASCADE**
- Cut 1 Half + cascade 2×5×10→5×5
- **Perfect cascade example:** Using only produced pieces, single trip
- 5×10 net = 0 (produced 2, cut 2)
- **Excel formatting:**
  - Steps tab: "(2) 10×10, (4) 5×5" (no 5×10 shown)
  - Barcode labels: 2 for 10×10, 4 for 5×5 (no 5×10)
  - Inventory deltas: Half -1, 10×10 +2, 5×5 +4 (no 5×10 row)
- Outcome: All sizes 0.364-1.000 years ✓

**Plan #19: Pine Green Transparent (Priority 19, 22/year)**
- Cut 1 Half (only 2 available)
- Outcome: All sizes 0.286-1.000 years ✓

**Plan #20: Cranberry Pink Gold Purple White (Priority 20, 20/year) ⭐ CUT FROM 10×10**
- **REVISED from optimizer:** Cut 2×10×10→5×10 instead of 5×10×10
- 10×10 heavily overstocked (3.5 years)
- 5×10 at zero
- **Optimizer said:** Cut 5×10×10 → 10×5×10 (gets to 1.25 years)
- **We decided:** Cut 2×10×10 → 4×5×10 (gets to 0.50 years exactly!)
- **Learning:** Apply "good enough" threshold even when cutting from inventory
- 183 days is sufficient - don't need 456 days
- Less labor (2 cuts vs 5, 4 labels vs 10)
- **Labor throughput wins again** ✓
- Outcome: All sizes 0.500-2.500 years ✓

---

## Excel Output Format (Confirmed Through Examples)

### Tab 1: Picks
**What:** List of items to pull from warehouse
**Shows:** Product_ID, Vendor_SKU, Quantity, Product name
**Rule:** Only original picks (NOT produced pieces)

**Example (Plan #18):**
- Pull 1 Half Sheet (171316, SKU 2124-30.HS)

---

### Tab 2: Steps
**What:** Cutting instructions with NET outcomes
**Format:** "Cut X [size]" → "(qty) size, (qty) size..."
**Target shows:** NET result after ALL operations (including cascade)

**Example (Plan #1 - no cascade):**
- Cut 13 Half Sheets → "(26) 10×10, (23) 5×10, (6) 5×5"
- (23 is net: produced 26×5×10, cut 3×5×10→5×5)

**Example (Plan #18 - cascade):**
- Cut 1 Half Sheet → "(2) 10×10, (4) 5×5"
- (5×10 NOT shown because net = 0: produced 2, cut 2)

**Example (Plan #20 - from 10×10):**
- Cut 2×10×10 → "(4) 5×10"

---

### Tab 3: Barcode_Labels
**What:** Labels to print for pieces going back on shelf
**Rule:** ONLY sizes with net > 0
**Format:** Product_ID, Quantity, Product name

**Example (Plan #18):**
- 2 labels for 10×10 (171313)
- 4 labels for 5×5 (171315)
- NO labels for 5×10 (net = 0)

---

### Tab 4: Inventory_Deltas
**What:** System inventory updates (count in/out)
**Rule:** ONLY sizes with net ≠ 0
**Format:** Product_ID, Qty_before, Qty_after, Net_Change

**Example (Plan #18):**
- Half: 3 → 2 (net: -1)
- 10×10: 2 → 4 (net: +2)
- 5×5: 0 → 4 (net: +4)
- NO row for 5×10 (net = 0)

---

## Decision Framework for Future Plans

### When Reviewing Each Plan:

**Step 1: Understand the situation**
- How many zeros?
- What's the source material availability?
- Any sizes heavily overstocked?
- Sales velocity (high/medium/low)?

**Step 2: Apply the three priorities**
1. Does it get products off zero? ✓
2. Can we achieve good balance (0.25+ years all sizes)?
3. Is this the simplest approach?

**Step 3: Check for constraints**
- Limited Half Sheets? (accept minimal coverage)
- Would cutting more create new zero? (don't do it)
- Is cutting addressing demand mismatch? (flag for reorder instead)

**Step 4: Apply labor throughput lens**
- If source material LIMITED: Cut minimum, move on
- If source material AVAILABLE: Cut enough to not revisit soon
- Always choose simpler when marginal benefit is small

**Step 5: Special cases**
- Cascade cutting opportunity? (use produced pieces)
- Heavily overstocked size? (consider cutting from inventory)
- Zero on slow seller? (low risk, but still avoid creating it)

---

## Remaining Work

### Plans 21-30: TO BE REVIEWED
- Continue same Q&A format
- Apply all learned rules
- Document any new patterns discovered
- Finalize complete rule set

### After All 30 Plans Reviewed:
1. Update optimizer with revised 0.25 year threshold
2. Finalize Excel generator code with all rules
3. Add simplification detection (flag over-optimized plans)
4. Add reorder flagging for products with demand mismatches
5. Test Excel output on all 30 plans

---

## Quick Reference: Plans 1-20 Final Decisions

| Plan | Glass Type | Cut Decision | Key Learning |
|------|-----------|--------------|--------------|
| 1 | Dense White Opal | 13 Half + 3×5×10 cascade | Baseline large operation |
| 2 | Red Transparent | 5 Half + 3×5×10 cascade | Bestseller needs ~40+ days |
| 3 | Clear Transparent | **5 Half** (not 7) | Don't over-optimize |
| 4 | Aqua Blue Tint White | 2 Half (of 3) | Don't create new zeros |
| 5 | Yellow Transparent | 5 Half + 3×5×10 cascade | 0.25 year threshold confirmed |
| 6 | Deep Red Opal | 2 Half (of 4) | Accept imperfect when limited |
| 7 | Deep Royal Blue | 1 Half (of 2) | Minimal coverage acceptable |
| 8 | Dark Forest Green Opal | 2 Half (of 3) | Same pattern |
| 9 | Clear Aventurine Blue | 2 Half (of 3) | Same pattern |
| 10 | Light Peach Cream Opal | 2 Half (of 3) | Same pattern |
| 11 | Egyptian Blue Opal | **3 Half** (of 4) | Total labor across time |
| 12 | Clear White Black Graffiti | 4 Half (of 6) | Two zeros, partial sizes |
| 13 | Fern Green Transparent | 2 Half (of 3) | Overstocked Half acceptable |
| 14 | White Royal Purple Pink | 1 Half (of 2) | Two zeros, minimal coverage |
| 15 | Mint Opal Forest Green | 2 Half (of 3) | Flag for reorder vs over-cut |
| 16 | White Opal Cranberry Pink | 2 Half (of 3) | Good balance achieved |
| 17 | White Opal Rainbow Irid | 3 Half (of 4) | Good balance |
| 18 | Red Opal White Opal | 1 Half + 2×5×10 cascade | Perfect cascade example |
| 19 | Pine Green Transparent | 1 Half (of 2) | Balanced outcome |
| 20 | Cranberry Pink Gold Purple | **2×10×10→5×10** (not 5) | Good enough beats over-optimization |

---

## Notes for Next Session

**Start with Plan #21** - continue same format:
1. Show current inventory
2. Show optimizer recommendation
3. Calculate complete outcome
4. Apply decision framework
5. Get user confirmation
6. Move to next plan

**Remember:**
- Display years AND days in same column
- Always show complete outcome before asking for confirmation
- Question anything that seems over-optimized
- Flag products that need Bullseye reorder
- Apply labor throughput lens to every decision

**Token usage so far:** ~73,000 of 200,000 (plenty of room for remaining 10 plans)

---

**Session Status:** ✅ ALL 30 PLANS COMPLETE!
**Goal:** ACHIEVED - Complete rule set learned, ready for Excel generator implementation

---

## Plans 21-30: Final Decisions

**Plan #21:** Light Pink Transparent Rainbow Iridescent - Cut 1 Half ✓ (Flag: 5×5 at 8 years!)
**Plan #22:** Sienna Transparent - Cut 1 Half ✓
**Plan #23:** Ruby Red Transparent Tint - Cut 1 Half + 1×5×10 cascade ✓
**Plan #24:** Orange Opal Black Stripes - Cut 2×10×10→5×10 (REVISED from 3) ✓
**Plan #25:** Clear Transparent Soft Ripple - Cut 2 Half ✓
**Plan #26:** Cranberry Royal Blue Spring Green - Cut 1 Half ✓ (Flag: 5×5 at 3 years)
**Plan #27:** Light Amber with Aventurine Green - Cut 2 Half ✓ (Flag: 5×5 at 7 years!)
**Plan #28:** Black Opalescent Rainbow Iridescent - Cut 1 Half (REVISED from 2) ✓
**Plan #29:** Deep Gray Opalescent - Cut 1 Half + 1×5×10 cascade ✓ (Flag: THREE zeros - urgent reorder!)
**Plan #30:** Clear Transparent Reed Texture - Cut 2×10×10→5×10 ✓ (Perfect balance!)

---

*Last Updated: December 7, 2025 - Complete Session*
*All 30 plans reviewed and confirmed*
*See FINAL_DECISIONS_ALL_30_PLANS.md for complete summary*
