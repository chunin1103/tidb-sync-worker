# Bullseye Glass 3mm Inventory Analysis - Final Summary Report
**Date:** December 8, 2025
**Total Parents Analyzed:** 401

---

## Executive Summary

| Category | Count | Action |
|----------|-------|--------|
| Cutting Candidates (CUT) | 126 | Generate cutting instructions |
| Cutting Candidates (DON'T CUT) | 1 | No action |
| Bullseye Reorder Flags | 46 | Order Half Sheets from Bullseye |
| Well Balanced | 169 | No action needed |
| No Source Material | 13 | Monitoring only |
| Partial Size Sets | 12 | Monitoring only |
| Dead Stock (Zero Sales) | 4 | Monitoring only |
| Original 30 (Already Done) | 30 | Already have cutting plans |
| **TOTAL** | **401** | |

---

## Detailed Breakdown

### 1. CUTTING CANDIDATES - 127 Total

#### Tier 1: Zeros With Half Sheets (34 items)
**File:** `Tier1_Cutting_Decisions.csv`

These have Half Sheet stock AND one or more sizes at ZERO. All reviewed and approved.

**Top 5 by Sales:**
1. White Opalescent (388) - 92 sales/yr - Cut Half -> 10x10
2. Marigold Yellow Transparent (16381) - 71 sales/yr - Cut 1 Half -> 2x10x10 + 2x5x10
3. Kelly Green Transparent (9704) - 70 sales/yr - Cut 1 Half -> 2x10x10 + 2x5x10 + cascade
4. White Pink Opal Streaky (169091) - 61 sales/yr - Cut 1 Half -> 2x10x10 + 2x5x10 + cascade
5. Deco Gray Opalescent (8428) - 42 sales/yr - Cut 1 Half -> 2x10x10 + 2x5x10

#### Tier 2: Could Improve Balance (87 items)
**File:** `101_Cutting_Candidates.csv` (Tier 2 rows)

These have Half Sheets and all sizes have stock, but some are below 0.25 years threshold.
Previously reviewed in earlier session.

#### Low Priority: No Half Sheets (6 items)
**File:** `LowPriority_Cutting_Decisions.csv`

Can cut from 10x10 or 5x10, but no Half Sheets available.

| Parent ID | Glass Type | Decision |
|-----------|------------|----------|
| 181765 | White with Red Wispy Streaks | CUT 1x10x10->2x5x10, REORDER Half |
| 182033 | Golden Green with Pimento Red | CUT 1x10x10->2x5x10, REORDER Half |
| 155487 | Burnt Scarlet Transparent Tint | CUT 1x10x10->4x5x5 |
| 179481 | White Lime Green Turquoise | CUT 1x10x10->2x5x10, REORDER Half |
| 16401 | Gold Purple Transparent | CUT 1x5x10->2x5x5, REORDER 10x10 |
| 156955 | Clear Iridescent Patterned | DON'T CUT, REORDER 5x10 |

---

### 2. BULLSEYE REORDER FLAGS - 46 Total
**File:** `Reorder_Flag_Decisions.csv`

These have ZERO stock in one or more sizes with NO cutting source available.
Must order Half Sheets from Bullseye.

**URGENT (10x10 at <30 days):**
- 170968 White Opal Deep Forest Green Caramel - 10x10 at 14 days
- 10037 Clear White & Black Streaky - 10x10 at 19 days
- 3600 Salmon Pink Opalescent - 10x10 at 26 days

**With Additional Cutting:**
- 152693 Turquoise Blue Rainbow Iridescent - REORDER Half + CUT 2x5x10->4x5x5
- 170963 White Orange Opal Deep Forest Green - REORDER Half + CUT cascade 10x10->5x10->5x5
- 153056 Coral Orange Transparent Tint - REORDER Half + CUT 1x5x10->2x5x5

**Top 5 by Sales (All Zeros):**
1. 166067 Holly Berry Red Frit - 210 sales/yr - ALL sizes ZERO
2. 6018 Clear White Streaky - 180 sales/yr - 10x10 ZERO (105/yr)
3. 3 Opaque White - 149 sales/yr - 10x10 ZERO (86/yr)
4. 164854 Sapphire Blue Transparent Tint - 78 sales/yr
5. 163639 Dark Amber Transparent - 72 sales/yr

---

### 3. NO ACTION NEEDED - 198 Total

#### Well Balanced (169 items)
All sizes at 0.25+ years (91+ days). No cutting needed.

#### No Source Material (13 items)
No Half Sheets but also no zeros. Just monitoring.

#### Partial Size Sets (12 items)
Only 1 size exists. No cutting possible.

#### Dead Stock - Zero Sales (4 items)
| Parent ID | Glass Type |
|-----------|------------|
| 164889 | Special Production White Yellow Streaky |
| 3698 | White Chopstix Collage on Clear |
| 171992 | Black Opalescent Granite Texture Iridescent |
| 156053 | Olive Smoke Transparent Tint |

---

## Files Created

| File | Description |
|------|-------------|
| `Tier1_Cutting_Decisions.csv` | 34 zeros with Half Sheets - cutting instructions |
| `LowPriority_Cutting_Decisions.csv` | 6 items that can cut without Half |
| `Reorder_Flag_Decisions.csv` | 46 items needing Bullseye reorder |
| `Master_401_Parent_Summary.csv` | All 401 parents with decisions |
| `CUTTING_RULES_REFERENCE.md` | Reference guide for cutting rules |
| `101_Cutting_Candidates.csv` | Original 121 candidates (Tier 1 + Tier 2) |
| `Balanced_Cutting_Instructions.csv` | Original 30 with cutting plans |

---

## Key Metrics

- **Total Parents to Cut:** 126 (34 Tier 1 + 87 Tier 2 + 5 Low Priority)
- **Total Parents to Reorder:** 46 (plus 4 from Low Priority needing specific sizes)
- **Total Parents - No Action:** 198 (169 balanced + 13 no source + 12 partial + 4 dead)
- **Already Done:** 30 (original cutting plans)

---

## Next Steps

1. **Execute Tier 1 Cuts First** - These have ZERO stock with active sales
2. **Place Bullseye Reorder** - Prioritize by sales volume, especially URGENT items
3. **Execute Tier 2 Cuts** - Improve balance on items below threshold
4. **Execute Low Priority Cuts** - When time permits
5. **Monitor Well Balanced** - Re-check periodically

---

## Cutting Yields Reference

| Source | Output |
|--------|--------|
| 1 Half Sheet | 2 x 10x10 + 2 x 5x10 |
| 1 x 10x10 | 2 x 5x10 OR 4 x 5x5 |
| 1 x 5x10 | 2 x 5x5 |

**Key Rule:** The smallest size for sale is the only size that cannot be cut from a larger size.
