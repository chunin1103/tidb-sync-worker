#!/usr/bin/env python3
"""
Bullseye Glass Cutting Optimizer - BALANCED VERSION v2.3
Uses balanced optimization to minimize risk across ALL sizes

Version 2.3 Changes (2025-12-07):
- UPDATED: "Good enough" threshold changed from 0.5 to 0.25 years (91 days)
- Based on complete 30-plan review and labor throughput analysis

Version 2.2 Changes (2025-12-06):
- FIX: Cascade cutting now constrained to only use produced pieces (Rule #1)
- FIX: Added "good enough" threshold (0.5 years) to prevent over-optimization
- FIX: Recognize same-bin operations as negligible extra work
"""

import csv
import re
from dataclasses import dataclass, field
from typing import List, Dict, Tuple
from collections import defaultdict
import os

@dataclass
class GlassProduct:
    """Represents a glass product in inventory"""
    product_name: str
    product_id: str
    parent_id: str
    quantity: int
    reorder: str
    reorder_qty: float
    purchased: int
    years_in_stock: float
    status: str

    # Parsed attributes
    color: str = ""
    glass_type: str = ""
    thickness: str = ""
    size: str = ""

    def __post_init__(self):
        """Parse product name to extract size"""
        name = self.product_name

        # Extract size
        if "Half Sheet" in name:
            self.size = "Half"
        elif '10"x10"' in name or "10x10" in name:
            self.size = "10x10"
        elif '5"x10"' in name or "5x10" in name:
            self.size = "5x10"
        elif '5"x5"' in name or "5x5" in name:
            self.size = "5x5"
        else:
            self.size = "Unknown"

@dataclass
class CuttingPlan:
    """Represents optimal cutting plan for one glass type"""
    parent_id: str
    glass_name: str

    # Cutting operations
    half_to_cut: int = 0
    ten_to_5x10: int = 0
    ten_to_5x5: int = 0
    five10_to_5x5: int = 0

    # Before state
    before_qty: Dict[str, int] = field(default_factory=dict)
    before_years: Dict[str, float] = field(default_factory=dict)

    # After state
    after_qty: Dict[str, int] = field(default_factory=dict)
    after_years: Dict[str, float] = field(default_factory=dict)

    # Metrics
    min_years_before: float = 0.0
    min_years_after: float = 0.0
    improvement: float = 0.0

    # Priority metrics
    total_purchased: int = 0  # Sum of purchased across all sizes
    has_zero: bool = False    # True if any size is at zero inventory

    # Product names for display
    product_names: Dict[str, str] = field(default_factory=dict)


class BalancedGlassOptimizer:
    """Optimizes glass cutting using balanced approach"""

    def __init__(self, csv_path: str):
        self.csv_path = csv_path
        self.products: List[GlassProduct] = []
        self.glass_groups: Dict[str, List[GlassProduct]] = defaultdict(list)

    def load_inventory(self):
        """Load and parse inventory CSV"""
        print(f"Loading inventory from {self.csv_path}...")
        errors = []

        with open(self.csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)

            for row in reader:
                product_name = row['Product_Name']
                status = row['Products Status']
                quantity = int(float(row['Quantity_in_Stock']))  # Handle decimal values in CSV
                reorder = row['Reorder']

                # Data quality checks
                if status == "InActive" and quantity > 0:
                    errors.append(f"ERROR: InActive product has stock - {product_name} (ID: {row['Product_ID']}, Qty: {quantity})")

                if reorder == "N" and quantity == 0 and status == "Active":
                    errors.append(f"WARNING: Out of stock, Reorder=N, but still Active - {product_name} (ID: {row['Product_ID']})")

                # Only process sheet glass (3mm)
                if any(size in product_name for size in ['10"x10"', '5"x10"', '5"x5"', 'Half Sheet']):
                    if "3mm" in product_name and status == "Active":
                        product = GlassProduct(
                            product_name=product_name,
                            product_id=row['Product_ID'],
                            parent_id=row['Products_Parent_Id'],
                            quantity=quantity,
                            reorder=reorder,
                            reorder_qty=float(row['Reorder_Quantity']),
                            purchased=int(row['Purchased']),
                            years_in_stock=float(row['Years_in_Stock']),
                            status=status
                        )

                        self.products.append(product)
                        self.glass_groups[product.parent_id].append(product)

        # Report errors
        if errors:
            print(f"\n{'='*80}")
            print(f"DATA QUALITY ISSUES FOUND:")
            print(f"{'='*80}")
            for error in errors[:20]:  # Limit to first 20
                print(f"  {error}")
            if len(errors) > 20:
                print(f"  ... and {len(errors) - 20} more")
            print(f"{'='*80}\n")

        print(f"Loaded {len(self.products)} sheet glass products")
        print(f"Found {len(self.glass_groups)} unique glass types (by Parent ID)")

    def optimize_all(self) -> List[CuttingPlan]:
        """Optimize cutting for all glass types"""
        plans = []

        print("\nAnalyzing cutting opportunities using BALANCED optimization...")
        print("Goal: Maximize minimum Years_in_Stock across all sizes\n")

        for parent_id, products in self.glass_groups.items():
            plan = self._optimize_glass_type(parent_id, products)
            if plan:
                plans.append(plan)

        # Sort by tier:
        # Tier 1: Has any zero inventory - sort by total_purchased DESC (highest first)
        # Tier 2: No zeros - sort by min_years_before ASC (lowest first)
        def sort_key(plan):
            if plan.has_zero:
                # Tier 1: Negative total_purchased so higher values come first
                # Prefix with 0 to sort before Tier 2
                return (0, -plan.total_purchased, plan.min_years_before)
            else:
                # Tier 2: Sort by min_years_before ascending
                # Prefix with 1 to sort after Tier 1
                return (1, plan.min_years_before, -plan.total_purchased)

        plans.sort(key=sort_key)

        return plans

    def _optimize_glass_type(self, parent_id: str, products: List[GlassProduct]) -> CuttingPlan:
        """Optimize cutting for one glass type"""
        # Group by size
        by_size = {}
        for p in products:
            if p.size in ['Half', '10x10', '5x10', '5x5']:
                by_size[p.size] = p

        # Need at least 2 sizes to have cutting opportunities
        if len(by_size) < 2:
            return None

        # Get available sizes
        available_sizes = list(by_size.keys())

        # Get current state (only for available sizes)
        current = {
            size: {
                'qty': by_size[size].quantity,
                'sales': by_size[size].purchased
            }
            for size in available_sizes
        }

        # Skip if no sizes are out of stock
        if all(current[s]['qty'] > 0 for s in available_sizes):
            return None

        # Check if cutting is possible: need larger size with stock AND smaller size out/low
        has_cutting_opportunity = False

        # Check Half → 10x10, 5x10
        if 'Half' in by_size and current['Half']['qty'] > 0:
            if ('10x10' in by_size and current['10x10']['qty'] == 0) or \
               ('5x10' in by_size and current['5x10']['qty'] == 0):
                has_cutting_opportunity = True

        # Check 10x10 → 5x10, 5x5
        if '10x10' in by_size and current['10x10']['qty'] > 0:
            if ('5x10' in by_size and current['5x10']['qty'] == 0) or \
               ('5x5' in by_size and current['5x5']['qty'] == 0):
                has_cutting_opportunity = True

        # Check 5x10 → 5x5
        if '5x10' in by_size and current['5x10']['qty'] > 0:
            if '5x5' in by_size and current['5x5']['qty'] == 0:
                has_cutting_opportunity = True

        if not has_cutting_opportunity:
            return None

        # Calculate current years
        def years(qty, sales):
            return qty / sales if sales > 0 else 0

        current_years = {s: years(current[s]['qty'], current[s]['sales']) for s in available_sizes}
        min_before = min(current_years.values())

        # Try all cutting combinations
        best = None
        best_min_years = min_before

        max_half = current.get('Half', {}).get('qty', 0)

        for half_cut in range(0, max_half + 1):
            # Calculate what we get from cutting Half Sheets
            original_10x10 = current.get('10x10', {}).get('qty', 0)
            produced_10x10 = half_cut * 2  # FIX v2.2: Track produced separately
            initial_10x10 = original_10x10 + produced_10x10

            original_5x10 = current.get('5x10', {}).get('qty', 0)
            produced_5x10 = half_cut * 2  # FIX v2.2: Track produced separately

            # PHASE 2 RULE #4: Don't sacrifice popular sizes for less popular ones
            # Only cut 10x10s if absolutely necessary or if they're overstocked
            max_10x10_to_5x10 = 0
            max_10x10_to_5x5 = 0

            if '5x10' in by_size and initial_10x10 > 0:
                # Check if 10x10 is more popular than 5x10
                ten_sales = current.get('10x10', {}).get('sales', 0)
                five10_sales = current.get('5x10', {}).get('sales', 0)

                # Only allow cutting 10x10s to 5x10 if:
                # 1. 10x10 is less popular than 5x10, OR
                # 2. 10x10 has excessive stock (>1 year), OR
                # 3. Half Sheets were exhausted and this is the only option
                ten_years = years(initial_10x10, ten_sales) if ten_sales > 0 else 0

                if ten_sales <= five10_sales or ten_years > 1.0 or half_cut >= max_half:
                    # FIX v2.2: Prefer cascade cuts (produced pieces) over pulling extra inventory
                    # Only allow cutting up to produced amount for single-trip operations
                    if half_cut > 0:
                        max_10x10_to_5x10 = produced_10x10  # Use only produced pieces (single trip)
                    else:
                        max_10x10_to_5x10 = initial_10x10  # No Half cut, can use original inventory
                else:
                    max_10x10_to_5x10 = 0  # Don't cut popular 10x10s

            for ten_to_5x10 in range(0, max_10x10_to_5x10 + 1):
                remaining_10x10 = initial_10x10 - ten_to_5x10
                added_5x10_from_10 = ten_to_5x10 * 2

                # Determine range for 10x10 to 5x5 cuts
                if '5x5' in by_size and remaining_10x10 > 0:
                    ten_sales = current.get('10x10', {}).get('sales', 0)
                    five5_sales = current.get('5x5', {}).get('sales', 0)
                    ten_years = years(remaining_10x10, ten_sales) if ten_sales > 0 else 0

                    if ten_sales <= five5_sales or ten_years > 1.0 or half_cut >= max_half:
                        # FIX v2.2: Prefer cascade cuts over pulling extra inventory
                        if half_cut > 0:
                            remaining_produced = produced_10x10 - ten_to_5x10
                            max_10x10_to_5x5 = max(0, remaining_produced)  # Use only produced pieces
                        else:
                            max_10x10_to_5x5 = remaining_10x10  # No Half cut, can use original
                    else:
                        max_10x10_to_5x5 = 0
                else:
                    max_10x10_to_5x5 = 0

                for ten_to_5x5 in range(0, max_10x10_to_5x5 + 1):
                    final_10x10 = remaining_10x10 - ten_to_5x5
                    added_5x5_from_10 = ten_to_5x5 * 4

                    # Calculate total 5x10 available
                    total_5x10 = original_5x10 + produced_5x10 + added_5x10_from_10

                    # FIX v2.2: Determine range for 5x10 to 5x5 cuts - prefer cascade cuts
                    if '5x5' in by_size:
                        if half_cut > 0:
                            # Prefer using produced 5x10s only (single trip)
                            max_5x10_to_5x5 = produced_5x10 + added_5x10_from_10
                        else:
                            # No Half cut, can use all available 5x10s
                            max_5x10_to_5x5 = total_5x10
                    else:
                        max_5x10_to_5x5 = 0

                    for five10_cut in range(0, max_5x10_to_5x5 + 1):
                        final_5x10 = total_5x10 - five10_cut
                        added_5x5_from_5x10 = five10_cut * 2

                        # Final state (only for available sizes)
                        final = {}
                        if 'Half' in by_size:
                            final['Half'] = current['Half']['qty'] - half_cut
                        if '10x10' in by_size:
                            final['10x10'] = final_10x10
                        if '5x10' in by_size:
                            final['5x10'] = final_5x10
                        if '5x5' in by_size:
                            final['5x5'] = current.get('5x5', {}).get('qty', 0) + added_5x5_from_10 + added_5x5_from_5x10

                        # Skip invalid
                        if any(final.get(s, 0) < 0 for s in available_sizes):
                            continue

                        # Skip no-op
                        if half_cut == 0 and ten_to_5x10 == 0 and ten_to_5x5 == 0 and five10_cut == 0:
                            continue

                        # Calculate balance (only for available sizes)
                        final_years = {s: years(final[s], current[s]['sales']) for s in available_sizes}
                        min_years = min(final_years.values())
                        max_years = max(final_years.values())
                        range_years = max_years - min_years

                        # FIX v2.3: Apply "good enough" threshold to prevent over-optimization
                        # With 10 orders/year, 0.25 years = ~91 days = ~2.5 order cycles = good enough
                        GOOD_ENOUGH_THRESHOLD = 0.25

                        # Optimize for maximum minimum (safety first)
                        score = min_years - (range_years * 0.05)

                        # FIX v2.2: Recognize same-bin simplicity
                        # Cutting 2 vs 1 from same SKU is negligible extra work
                        # Count number of different operations (not total pieces)
                        num_operations = (1 if half_cut > 0 else 0) + \
                                       (1 if ten_to_5x10 > 0 else 0) + \
                                       (1 if ten_to_5x5 > 0 else 0) + \
                                       (1 if five10_cut > 0 else 0)

                        if best is None or score > (best_min_years - (best.get('range', 0) * 0.05)):
                            # Accept this plan if:
                            # 1. It's better than current best, OR
                            # 2. It's "good enough" and simpler (fewer operation types)
                            accept = True

                            if best is not None and min_years >= GOOD_ENOUGH_THRESHOLD:
                                # Already good enough - prefer simpler operations
                                best_ops = best.get('num_operations', 99)
                                if num_operations > best_ops:
                                    accept = False  # Don't accept more complex for marginal gain

                            if accept:
                                best_min_years = min_years
                                best = {
                                    'half': half_cut,
                                    'ten_5x10': ten_to_5x10,
                                    'ten_5x5': ten_to_5x5,
                                    'five10_5x5': five10_cut,
                                    'final': final,
                                    'final_years': final_years,
                                    'min': min_years,
                                    'max': max_years,
                                    'range': range_years,
                                    'num_operations': num_operations
                                }

        if best and best['min'] > min_before:
            # Create plan - get glass name from any available size
            first_product = by_size[available_sizes[0]]
            glass_name = first_product.product_name.split(' - Size ')[0].replace('Bullseye Glass ', '')

            # Calculate total purchased across all sizes
            total_purchased = sum(current[s]['sales'] for s in available_sizes)

            # Check if any size is at zero
            has_zero = any(current[s]['qty'] == 0 for s in available_sizes)

            plan = CuttingPlan(
                parent_id=parent_id,
                glass_name=glass_name,
                half_to_cut=best['half'],
                ten_to_5x10=best['ten_5x10'],
                ten_to_5x5=best['ten_5x5'],
                five10_to_5x5=best['five10_5x5'],
                before_qty={s: current[s]['qty'] for s in available_sizes},
                before_years=current_years,
                after_qty=best['final'],
                after_years=best['final_years'],
                min_years_before=min_before,
                min_years_after=best['min'],
                improvement=best['min'] - min_before,
                total_purchased=total_purchased,
                has_zero=has_zero,
                product_names={s: by_size[s].product_name for s in available_sizes}
            )

            return plan

        return None

    def generate_report(self, plans: List[CuttingPlan], output_path: str):
        """Generate cutting report CSV"""
        print(f"\nGenerating cutting report to {output_path}...")

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            fieldnames = [
                'Priority',
                'Tier',
                'Total_Purchased',
                'Parent_ID',
                'Glass_Type',
                'Cut_Half_Sheets',
                'Cut_10x10_to_5x10',
                'Cut_10x10_to_5x5',
                'Cut_5x10_to_5x5',
                'Before_Half_Years',
                'Before_10x10_Years',
                'Before_5x10_Years',
                'Before_5x5_Years',
                'After_Half_Years',
                'After_10x10_Years',
                'After_5x10_Years',
                'After_5x5_Years',
                'Min_Years_Before',
                'Min_Years_After',
                'Improvement'
            ]

            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            for i, plan in enumerate(plans, 1):
                tier = "1-Zero Stock" if plan.has_zero else "2-Balancing"

                writer.writerow({
                    'Priority': i,
                    'Tier': tier,
                    'Total_Purchased': plan.total_purchased,
                    'Parent_ID': plan.parent_id,
                    'Glass_Type': plan.glass_name,
                    'Cut_Half_Sheets': plan.half_to_cut,
                    'Cut_10x10_to_5x10': plan.ten_to_5x10,
                    'Cut_10x10_to_5x5': plan.ten_to_5x5,
                    'Cut_5x10_to_5x5': plan.five10_to_5x5,
                    'Before_Half_Years': f"{plan.before_years.get('Half', 0):.3f}",
                    'Before_10x10_Years': f"{plan.before_years.get('10x10', 0):.3f}",
                    'Before_5x10_Years': f"{plan.before_years.get('5x10', 0):.3f}",
                    'Before_5x5_Years': f"{plan.before_years.get('5x5', 0):.3f}",
                    'After_Half_Years': f"{plan.after_years.get('Half', 0):.3f}",
                    'After_10x10_Years': f"{plan.after_years.get('10x10', 0):.3f}",
                    'After_5x10_Years': f"{plan.after_years.get('5x10', 0):.3f}",
                    'After_5x5_Years': f"{plan.after_years.get('5x5', 0):.3f}",
                    'Min_Years_Before': f"{plan.min_years_before:.3f}",
                    'Min_Years_After': f"{plan.min_years_after:.3f}",
                    'Improvement': f"{plan.improvement:.3f}"
                })

        print(f"Report generated with {len(plans)} cutting plans")

    def print_summary(self, plans: List[CuttingPlan]):
        """Print summary of cutting plans"""
        if not plans:
            print("\n[OK] No cutting needed - all glass types are well balanced!")
            return

        print(f"\n{'='*80}")
        print(f"BALANCED CUTTING PLANS SUMMARY")
        print(f"{'='*80}")
        print(f"\nTotal glass types needing cuts: {len(plans)}")

        # Count by tier
        tier1_count = sum(1 for p in plans if p.has_zero)
        tier2_count = len(plans) - tier1_count

        print(f"  Tier 1 (Zero Stock - CRITICAL): {tier1_count}")
        print(f"  Tier 2 (Balancing): {tier2_count}")

        total_ops = sum(1 for p in plans if p.half_to_cut > 0)
        total_ops += sum(1 for p in plans if p.ten_to_5x10 > 0)
        total_ops += sum(1 for p in plans if p.ten_to_5x5 > 0)
        total_ops += sum(1 for p in plans if p.five10_to_5x5 > 0)

        print(f"Total cutting operations: {total_ops}")

        print(f"\nTop 5 Priority (sorted by tier, then popularity/urgency):")
        for plan in plans[:5]:
            tier = "T1-ZERO" if plan.has_zero else "T2-BAL"
            print(f"  [{tier}] {plan.glass_name[:55]}")
            print(f"    Total purchased/yr: {plan.total_purchased} | Min years: {plan.min_years_before:.3f} -> {plan.min_years_after:.3f}")


def main():
    """Main execution"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    input_csv = os.path.join(script_dir, "Bullseye Cut Sheet Sample File 12-5-25.csv")
    output_csv = os.path.join(script_dir, "Balanced_Cutting_Instructions.csv")

    if not os.path.exists(input_csv):
        print(f"Error: Input file not found: {input_csv}")
        return

    optimizer = BalancedGlassOptimizer(input_csv)
    optimizer.load_inventory()

    plans = optimizer.optimize_all()
    optimizer.print_summary(plans)

    if plans:
        optimizer.generate_report(plans, output_csv)
        print(f"\n[OK] Balanced cutting instructions saved to: {output_csv}")

    print("\nDone!")


if __name__ == "__main__":
    main()
