# Cutting Decisions: Candidates 21-109

**Date:** December 7, 2025
**Reviewed by:** Claude + User
**Total Candidates:** 89 (21-109)

---

## SUMMARY

| Decision | Count |
|----------|-------|
| **CUT** | 68 |
| **DON'T CUT** | 21 |

---

## TIER 1 - Zero Stock (Skipped) - Candidates 21-22

| # | Parent ID | Glass Type | Decision | Operation | Min After |
|---|-----------|------------|----------|-----------|-----------|
| 21 | 159082 | Light Silver Gray Transparent Silver Iridescent | CUT | 1 Half + cascade 1×5×10→5×5 | 146 days |
| 22 | 179505 | White Olive Green Gold Pink Mottle Mix | CUT | 1×10×10→2×5×10 | 243 days |

---

## TIER 2 - Could Improve - Candidates 23-109

| # | Parent ID | Glass Type | Decision | Operation | Min After |
|---|-----------|------------|----------|-----------|-----------|
| 23 | 445 | Red Opalescent | CUT | 5 Half | 39 days (FLAG REORDER) |
| 24 | 6968 | Clear Egyptian Blue Opal Streaky | CUT | 3 Half | 64 days |
| 25 | 6822 | Reactive Cloud Opalescent | CUT | 1 Half | 30 days (FLAG REORDER) |
| 26 | 8304 | Canary Yellow Opalescent | CUT | 2 Half + cascade 2×5×10→5×5 | 73 days |
| 27 | 172007 | Peacock Blue Transparent Rainbow Iridescent | DON'T CUT | FLAG REORDER - only 1 Half sells 3/yr | - |
| 28 | 827 | Aventurine Green Transparent | CUT | 2 Half | 61 days |
| 29 | 401 | Turquoise Blue Opalescent | DON'T CUT | FLAG REORDER - Half is problem size | - |
| 30 | 15044 | Tan Transparent | CUT | 2 Half | 46 days |
| 31 | 166670 | Light Green White Opal Streaky | CUT | 1 Half | 44 days (FLAG REORDER) |
| 32 | 457 | Spring Green Opalescent | CUT | 3 Half | 94 days |
| 33 | 169757 | Copper Blue White Opal | CUT | 2 Half | 78 days |
| 34 | 9699 | Clear Black Opal Streaky | CUT | 2 Half | 81 days |
| 35 | 16451 | Olive Green Opal Forest Green Deep Brown Streaky | CUT | 2 Half + cascade 1×5×10→5×5 | 112 days |
| 36 | 163659 | Light Bronze Transparent Gold Iridescent | CUT | 1 Half | 84 days |
| 37 | 161099 | Lily Pad Green Transparent | CUT | 2 Half | 140 days |
| 38 | 160903 | Blue Opal Plum Streaky | CUT | 1 Half | 58 days |
| 39 | 470 | French Vanilla Opalescent | CUT | 7 Half | 77 days (FLAG REORDER) |
| 40 | 163624 | Glacier Blue Opalescent | CUT | 3 Half | 69 days |
| 41 | 168538 | White Aventurine Green Streaky | DON'T CUT | FLAG REORDER - only 1 Half at 91 days | - |
| 42 | 9104 | Deep Royal Purple Transparent | CUT | 3 Half | 91 days |
| 43 | 8317 | Yellow Opalescent Deep Forest Green Streaky | CUT | 1 Half + cascade 1×5×10→5×5 | 110 days |
| 44 | 15593 | Light Coral Transparent | CUT | 1×10×10→2×5×10 | 110 days |
| 45 | 159865 | French Vanilla Light Turquoise Blue Infusion Streaky | CUT | 1 Half | 77 days |
| 46 | 181596 | Aventurine Bronze Transparent | CUT | 3 Half | 64 days (FLAG REORDER) |
| 47 | 16336 | Aquamarine Blue Transparent | CUT | 2 Half + 1×10×10→5×10 + cascade 1×5×10→5×5 | 104 days |
| 48 | 6074 | Woodland Brown Opal Ivory Black Streaky | CUT | 2×10×10→4×5×10 | 95 days |
| 49 | 169141 | Clear Rainbow Mardi Gras | CUT | 1×10×10→2×5×10 | 122 days |
| 50 | 16316 | Golden Green Opalescent | CUT | 1×5×10→2×5×5 | 122 days |
| 51 | 8840 | French Vanilla Opal Light Turquoise Blue Wispy Streaky | CUT | 1 Half | 86 days |
| 52 | 9244 | Cream Opalescent | DON'T CUT | FLAG REORDER - Half is problem size | - |
| 53 | 164864 | Ming Green Transparent Tint | DON'T CUT | FLAG REORDER - Half is problem size | - |
| 54 | 1106 | Crystal Clear Transparent | CUT | 2×10×10→4×5×10 | 137 days |
| 55 | 172131 | Powder Blue Opal Marine Blue Trans | DON'T CUT | FLAG REORDER - only 1 Half sells 3/yr | - |
| 56 | 10012 | Mink Opalescent | DON'T CUT | FLAG REORDER - low volume keep all sizes | - |
| 57 | 155892 | Kelly Green Transparent Rainbow Iridescent | CUT | 1 Half | 137 days |
| 58 | 16361 | Light Plum Transparent | CUT | 1 Half | 97 days |
| 59 | 163629 | Robin's Egg Blue Opalescent | CUT | 4 Half | 98 days |
| 60 | 8087 | Clear Aventurine Blue Streaky | CUT | 3 Half | 104 days |
| 61 | 6050 | Caribbean Blue White Streaky | DON'T CUT | FLAG REORDER - only 1 Half at 73 days | - |
| 62 | 16416 | Moss Green Opalescent | CUT | 1 Half | 104 days |
| 63 | 6988 | Clear Turquoise Blue White Streaky | CUT | 3 Half | 93 days |
| 64 | 175067 | Peacock Blue White Opal Streaky | CUT | 2 Half | 73 days |
| 65 | 10017 | Artichoke Opalescent | CUT | 2 Half | 108 days |
| 66 | 146037 | Spruce Green Transparent Tint | CUT | 1 Half | 96 days |
| 67 | 1124 | Light Aquamarine Blue Transparent | DON'T CUT | SKIP RULE - all children 0.25+ | - |
| 68 | 168528 | Amethyst Transparent | CUT | 2 Half | 91 days |
| 69 | 9857 | Mint Green Opalescent | DON'T CUT | FLAG REORDER - only 1 Half at 61 days | - |
| 70 | 16371 | Sea Blue Transparent | CUT | 2 Half | 110 days |
| 71 | 512 | Teal Green Opalescent | CUT | 2×10×10→4×5×10 | 142 days |
| 72 | 8925 | Elephant Gray Opalescent | DON'T CUT | FLAG REORDER - only 1 Half sells 2/yr | - |
| 73 | 16456 | Cranberry Pink Azure Blue White Streaky | CUT | 1 Half | 169 days |
| 74 | 156038 | Grass Green Transparent Tint | CUT | 1 Half | 122 days |
| 75 | 10042 | Black Fractures with Black Streamers on Clear | CUT | 1×10×10→2×5×10 | 182 days |
| 76 | 3991 | Light Aventurine Green Transparent | CUT | 2 Half | 104 days |
| 77 | 8436 | Light Bronze Transparent | CUT | 1 Half | 95 days |
| 78 | 153129 | Caribbean Blue Transparent | CUT | 2 Half | 100 days |
| 79 | 548 | Woodland Brown Opalescent | CUT | 1×10×10→4×5×5 | 97 days |
| 80 | 3967 | Cobalt Blue Opalescent | CUT | 1 Half | 100 days |
| 81 | 160997 | Leaf Green Transparent | CUT | 1×10×10→2×5×10 | 107 days |
| 82 | 155897 | Caribbean Blue Transparent Rainbow Iridescent | CUT | 1 Half | 133 days |
| 83 | 169737 | Pewter Transparent | CUT | 1 Half | 133 days |
| 84 | 308 | Black Opalescent | CUT | 5×10×10→10×5×10 | 123 days |
| 85 | 8406 | Translucent White Opalescent | DON'T CUT | FLAG REORDER - Half at 91 days sells 12/yr | - |
| 86 | 172126 | Lavender Opalescent | CUT | 1 Half | 114 days |
| 87 | 530 | Deep Cobalt Blue Opalescent | CUT | 2 Half + cascade 1×5×10→5×5 | 115 days |
| 88 | 4387 | Burnt Orange Opalescent | CUT | 1×10×10→2×5×10 | 122 days |
| 89 | 15613 | Cranberry Pink Royal Blue Spring Green White Streaky | DON'T CUT | FLAG REORDER - only 1 Half at 73 days | - |
| 90 | 6839 | Turquoise Blue Deep Royal Blue Streaky | CUT | 1×5×10→2×5×5 | 91 days |
| 91 | 161094 | Leaf Green Transparent Rainbow Iridescent | CUT | 1×10×10→2×5×10 | 219 days |
| 92 | 154462 | Light Amber Transparent Tint | CUT | 1 Half | 219 days |
| 93 | 154457 | Yellow Transparent Rainbow Iridescent | CUT | 1×10×10→2×5×10 | 219 days |
| 94 | 158735 | Black Opalescent Prismatic Texture Iridescent | CUT | 1×10×10→4×5×5 | 243 days |
| 95 | 145988 | Reactive Ice Transparent Rainbow Iridescent | CUT | 1 Half | 219 days |
| 96 | 10813 | Light Orange Transparent | CUT | 1 Half + cascade 1×5×10→5×5 | 91 days |
| 97 | 161789 | White Opal Salmon Pink Opal Streaky | DON'T CUT | FLAG REORDER - only 1 Half sells 2/yr | - |
| 98 | 8356 | Neo-Lavender Shift Transparent | CUT | 1 Half | 115 days |
| 99 | 8184 | Garnet Red Transparent | CUT | 2 Half | 119 days |
| 100 | 175703 | Warm White Light Amber Streaky | CUT | 1 Half | 100 days |
| 101 | 857 | Turquoise Blue Transparent | CUT | 1×10×10→2×5×10 | 96 days |
| 102 | 7016 | Aventurine Blue Transparent | CUT | 1×10×10→2×5×10 | 81 days (Half FLAG REORDER) |
| 103 | 8394 | Aqua Blue Transparent Tint | CUT | 2 Half | 103 days |
| 104 | 5958 | Clear Spring Green Opal Streaky | CUT | 1×10×10→2×5×10 | 162 days |
| 105 | 16461 | Cranberry Pink Emerald Green White Streaky | DON'T CUT | FLAG REORDER - only 1 Half sells 1/yr | - |
| 106 | 179973 | Pistachio Opalescent | DON'T CUT | FLAG REORDER - only 1 Half sells 1/yr | - |
| 107 | 8129 | Orange Transparent | CUT | 1×10×10→2×5×10 | 129 days |
| 108 | 8410 | Light Silver Gray Transparent | CUT | 1 Half | 129 days |
| 109 | 159122 | Petrified Wood Streaky | CUT | 1×10×10→2×5×10 | 111 days |

---

## RULES APPLIED

### 1. Skip Rule
If all children (excluding biggest available) at 0.25+ years (91+ days) → DON'T CUT

### 2. Use Overstocked Sizes First
- Cut 10×10 before Half when 10×10 is overstocked
- Cut 5×10 before Half when 5×10 is overstocked

### 3. Don't Create Zeros
- Never cut all of a size that sells
- Exception: 0 sales = dead stock, can cut all

### 4. Low Volume = Keep All Sizes
- Products with low total sales - keep all sizes in stock

### 5. Dead Stock Rule (Added This Session)
- 0 sales = dead stock
- Don't cascade into sizes with 0 sales
- Treat as "fine" for skip rule

### 6. Cutting Yields
- 1 Half → 2×10×10 + 2×5×10 (BOTH!)
- 1×10×10 → 2×5×10 OR 4×5×5
- 1×5×10 → 2×5×5

---

## DON'T CUT SUMMARY (21 candidates)

| # | Parent ID | Reason |
|---|-----------|--------|
| 27 | 172007 | Only 1 Half sells 3/yr |
| 29 | 401 | Half is problem size |
| 41 | 168538 | Only 1 Half at 91 days |
| 52 | 9244 | Half is problem size |
| 53 | 164864 | Half is problem size |
| 55 | 172131 | Only 1 Half sells 3/yr |
| 56 | 10012 | Low volume keep all sizes |
| 61 | 6050 | Only 1 Half at 73 days |
| 67 | 1124 | SKIP RULE - all children 0.25+ |
| 69 | 9857 | Only 1 Half at 61 days |
| 72 | 8925 | Only 1 Half sells 2/yr |
| 85 | 8406 | Half at 91 days sells 12/yr |
| 89 | 15613 | Only 1 Half at 73 days |
| 97 | 161789 | Only 1 Half sells 2/yr |
| 105 | 16461 | Only 1 Half sells 1/yr |
| 106 | 179973 | Only 1 Half sells 1/yr |

---

## REMAINING WORK

- **Candidates 1-20:** Previously reviewed (see RESUME_POINT_CANDIDATE_21.md)
- **Original 30 Plans:** From earlier sessions
- **Remaining 270+ parents:** Non-cutting candidates to review

**Total Parents in System:** 401
**Cutting Candidates Reviewed:** 109 complete
