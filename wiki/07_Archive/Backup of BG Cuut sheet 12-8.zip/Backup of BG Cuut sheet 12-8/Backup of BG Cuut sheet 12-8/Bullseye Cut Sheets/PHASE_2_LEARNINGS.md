# Phase 2: Constraint Rules & Business Logic

**Date:** December 5, 2025
**Session:** Complete review of all 30 cutting plans with user
**Goal:** Develop smart constraints that reflect real business needs

---

## Summary

Through reviewing actual cutting plans, we discovered that **getting products off zero** and **minimizing labor** are more important than perfect mathematical balance. We added rules to prevent the optimizer from making technically optimal but practically poor decisions.

---

## Phase 2 Rules Implemented

### **Rule #1: Minimize Warehouse Trips - Cascade Cutting**

**Problem:** Optimizer was recommending separate trips to pull different sizes

**Example:**
- ❌ BAD: Pull 5 Half Sheets, cut them. Then go pull 3 more 5x10s, cut those.
- ✓ GOOD: Pull 5 Half Sheets, cut them to get fresh 5x10s, then cut 3 of THOSE fresh 5x10s

**Implementation:** Prefer cutting freshly-produced byproduct pieces over pulling additional warehouse stock

**Business Impact:** Reduces labor time, fewer trips to warehouse

---

### **Rule #2: Getting Off Zero > Perfect Safety Margins**

**Problem:** Added safety thresholds (0.15 years for high sellers, 0.10 for medium, 0.08 for low) but these rejected valid plans

**Example - Plan #4 (Aqua Blue Tint & White Streaky):**
- Cutting 2 Half Sheets leaves 10x10 at 0.061 years (violates 0.15 threshold)
- **BUT** it gets 2 sizes off zero!
- User decision: "I'd rather have 0.061 years than 0.000 years"

**Implementation:** Removed hard threshold rejections. Getting products in stock takes priority.

**Business Impact:**
- Weekly cycles allow for corrections
- Stock-out costs more than low inventory
- Can adjust next week if needed

---

### **Rule #3: Byproduct Accumulation is Acceptable**

**Problem:** Optimizer tries to balance all sizes equally, but Half Sheet cuts ALWAYS produce 5x10s

**Example - Plan #1:**
- Need 10x10s (most popular)
- Must cut Half Sheets to get them
- This creates unavoidable 5x10 byproducts
- 5x10s end up with 0.500 years while 10x10s have 0.222 years

**Decision:** This is acceptable! Focus is getting 10x10s back in stock

**Future Solution:** Run sales on overstocked 5x10s

**Business Impact:** Don't over-optimize away from primary goal (getting bestsellers in stock)

---

### **Rule #4: Don't Sacrifice Popular Sizes for Less Popular Ones** ⭐

**Problem:** Optimizer was cutting popular 10x10s to make less-popular 5x5s

**Example - Plan #5 (Yellow Transparent):**

**BEFORE Rule #4:**
- 10x10: 57 sold/year (BESTSELLER!)
- 5x5: 16 sold/year (slower)
- Optimizer: Cut 2×10x10→5x10 and 1×10x10→5x5 🚫

**AFTER Rule #4:**
- Optimizer: Don't touch 10x10s! Cut more Half Sheets instead ✓
- Result: 5 Half Sheets + 3 fresh 5x10s→5x5s
- Single warehouse trip
- Protects the popular 10x10s

**Implementation Logic:**

Only allow cutting a size (like 10x10) if:
1. **Target is more popular** than source, OR
2. **Source has excessive stock** (>1 year), OR
3. **No other option** (all Half Sheets exhausted)

**Business Impact:**
- Protects revenue from bestselling sizes
- Every 10x10 cut = lost revenue opportunity when it's the bestseller
- Simpler cutting plans (fewer operations)
- Fewer warehouse trips

---

### **Rule #5: Priority-Based Half Sheet Overstock Decisions** ⭐

**Problem:** When Half Sheets are extremely overstocked (>3 years), how much should we cut?

**Example - Plan #28 (Black Opalescent Rainbow Iridescent):**

**Current Status:**
- Half: 5 pieces (5.000 years - extreme overstock!)
- 10x10: 5 pieces (0.625 years)
- 5x10: 0 pieces (OUT OF STOCK)
- 5x5: 3 pieces (1.000 years)

**Three Options Considered:**
1. Cut 1 Half Sheet → Min years: 0.875, Max: 4.000 (range: 3.125)
2. Cut 2 Half Sheets → Min years: 1.125, Max: 3.000 (range: 1.875) ✓
3. Cut 3 Half Sheets + cascade → Min years: 1.375, Max: 2.333 (range: 0.958) but adds complexity

**Implementation: Apply Priority Framework**

When deciding between cutting options:

1. **Priority 1: Get products off zero** (all options must meet this)
2. **Priority 2: Optimize years in stock to be close** (minimize range between min/max)
3. **Priority 3: Minimize employee time** (operation complexity)

**Decision Logic:**
- If cutting 1 vs 2 Half Sheets = essentially same labor → **choose option with better balance**
- Don't over-optimize with cascade cutting for diminishing returns
- Address extreme overstock opportunistically (won't self-resolve through biweekly cycles due to low demand)

**Business Impact:**
- Balances three competing priorities explicitly
- Reduces extreme Half Sheet overstock when opportunity arises
- Acknowledges Half Sheets don't sell fast enough to self-correct (typically 1-3/year)
- Keeps operations simple (avoids unnecessary complexity)

**Key Insight:** Half Sheets are most acceptable to overstock (can't be created, maximum flexibility), BUT extreme overstock (>3 years) should still be addressed when cutting for other reasons. Use the priority framework to find the right balance.

---

## Key Insights

### 1. Perfect Balance ≠ Best Business Outcome
Mathematical optimization can make decisions that look great on paper but harm the business:
- Cutting popular items to fill unpopular ones
- Creating overly complex cutting plans
- Rejecting valid solutions for being "too risky"

### 2. Labor is the Limiting Factor
Weekly cut sheets are often not completed due to limited labor:
- **Simpler plans are better** (fewer operations, fewer trips)
- **Prioritization matters** (sort by popularity)
- **Cascade operations when possible** (use fresh byproducts)

### 3. Biweekly Cycles Allow Imperfection
Since cut sheets run biweekly:
- Don't need perfect balance this cycle
- Can adjust next cycle based on actual sales (not theoretical annual averages)
- Getting off zero TODAY > perfect margins
- Iterative approach responds to real demand patterns

### 4. Sales Velocity is King
The optimizer must respect that:
- Not all sizes are equal
- Popular sizes deserve protection
- Revenue loss from popular stockouts > slow seller stockouts

### 5. Three Explicit Priorities Drive Decisions
All cutting decisions should be evaluated against:
1. **Get products off zero** (prevent stockouts)
2. **Optimize balance** (minimize range between min/max years)
3. **Minimize labor** (operation complexity and warehouse trips)

These priorities are ordered - Priority 1 trumps Priority 2, which trumps Priority 3.

---

## Before vs After Phase 2

### Optimizer Behavior Changes:

| Scenario | Before Phase 2 | After Phase 2 |
|----------|----------------|---------------|
| **5x5 out, 10x10 popular** | Cut 10x10s to make 5x5s | Cut Half Sheets only |
| **Multiple operations needed** | 2-3 warehouse trips | Single trip when possible |
| **Low but non-zero inventory** | Reject as "too risky" | Accept - better than zero |
| **5x10 byproduct pileup** | Try to cut more to balance | Accept as unavoidable |

### Results:

- **30 cutting plans generated** (4 products modified by Rule #4 to protect popular sizes)
- **All plans respect the three priorities** (zero stockouts, balance, labor)
- **Simpler cutting operations** (fewer unnecessary 10x10 cuts)
- **More single-trip plans** (cascade cutting preferred)
- **Bestsellers protected** (Rule #4 working correctly)

---

## Testing Results

### Plan #5 Transformation (Yellow Transparent):

**Sales Profile:**
- Half: 7/year (low)
- 10x10: 57/year ⭐ (BESTSELLER)
- 5x10: 31/year (medium)
- 5x5: 16/year (low)

**Before Phase 2:**
```
Cut 4 Half Sheets
Cut 2×10x10 → 5x10  🚫 Sacrificing bestseller!
Cut 1×10x10 → 5x5   🚫 Sacrificing bestseller!
Cut 1×5x10 → 5x5
Result: Perfect balance (0.351 min years)
Operations: Multiple trips needed
```

**After Phase 2:**
```
Cut 5 Half Sheets
Cut 3 fresh 5x10s → 5x5 (from Half Sheet byproducts)
Result: Good balance (0.258 min years)
Operations: SINGLE TRIP ✓
10x10s protected: 15→25 pieces (0.439 years) ✓
```

**Analysis:**
- Slightly less balanced (0.258 vs 0.351)
- But protects bestseller 10x10s
- Simpler operation (1 trip vs 2-3)
- More 10x10s available for customers

---

## Rules NOT Implemented (Rejected Approaches)

### ❌ Hard Safety Thresholds
**Idea:** Require minimum years in stock (0.15 for high sellers, etc.)
**Problem:** Rejected valid plans that got products off zero
**Learning:** Getting off zero > perfect margins

### ❌ Pure Revenue-Weighted Optimization
**Idea:** Weight balance by sales × price
**Problem:** Too complex, hard to explain/trust
**Learning:** Simple rules work better with weekly cycles

### ❌ Minimize All 10x10 Cutting
**Idea:** Never cut 10x10s
**Problem:** Sometimes it's necessary (no Half Sheets, or 10x10 overstocked)
**Learning:** Context matters - apply rules intelligently

---

## Future Enhancements

Potential Phase 3 improvements discussed but not yet implemented:

1. **Explicit cascade display** in output CSV
   - Show: "Step 1: Pull 5 Half, Step 2: Cut 3 fresh 5x10s"
   - Makes warehouse operations crystal clear

2. **Warning flags** for concerning situations
   - "10x10 will be <0.10 years after this cut"
   - "This leaves Half Sheets at zero"

3. **Alternative plan suggestions**
   - "Could also cut 3 Half instead of 5 for simpler operation"

4. **Cost/time estimates**
   - "This plan requires 2 trips, ~45 minutes"

---

## Code Changes Made

### File: `glass_cutting_optimizer_balanced.py`

**Phase 2 Rule #4 Implementation:**

Added logic to check popularity before allowing 10x10 cuts:

```python
# PHASE 2 RULE #4: Don't sacrifice popular sizes for less popular ones
# Only cut 10x10s if absolutely necessary or if they're overstocked
max_10x10_to_5x10 = 0
max_10x10_to_5x5 = 0

if '5x10' in by_size and initial_10x10 > 0:
    ten_sales = current.get('10x10', {}).get('sales', 0)
    five10_sales = current.get('5x10', {}).get('sales', 0)
    ten_years = years(initial_10x10, ten_sales) if ten_sales > 0 else 0

    # Only allow cutting if:
    # 1. 10x10 is less popular than 5x10, OR
    # 2. 10x10 has excessive stock (>1 year), OR
    # 3. Half Sheets were exhausted (last resort)
    if ten_sales <= five10_sales or ten_years > 1.0 or half_cut >= max_half:
        max_10x10_to_5x10 = initial_10x10
    else:
        max_10x10_to_5x10 = 0  # Protect popular 10x10s
```

Similar logic applied to 10x10→5x5 cuts.

---

## Lessons Learned

### For Future AI/Optimizer Development:

1. **Business rules > Pure math** - Real constraints matter more than theoretical optimization

2. **Involve users early** - Testing with actual data revealed issues immediately

3. **Iterate quickly** - Tried thresholds, rejected them same session, moved on

4. **Simple is better** - Complex scoring functions are hard to trust/debug

5. **Context is everything** - "Don't cut 10x10s" isn't always true, depends on situation

6. **Labor costs matter** - Fewer operations can be worth less perfect balance

---

## Status

**Phase 2 Progress:** ✅ COMPLETE - All 30 plans reviewed and validated
**Rules Implemented:** 5 (added Rule #5: Priority-Based Half Sheet Overstock Decisions)
**Optimizer Version:** v2.1 with full Phase 2 rules
**Validation:** All rules working correctly across diverse scenarios

### Plans Reviewed Examples:
- **Rule #1 (Cascade Cutting):** Plans #2, #18, #23, #28, #29
- **Rule #2 (Getting Off Zero > Perfect Margins):** Plans #4, #14
- **Rule #3 (Byproduct Accumulation Acceptable):** Plans #1, #11, #17, #27
- **Rule #4 (Don't Sacrifice Popular Sizes):** Plans #5, #6, #20, #30
- **Rule #5 (Priority-Based Half Sheet Decisions):** Plan #28

### Edge Cases Validated:
- Partial size sets (only 3 sizes): Plan #24 ✓
- Multiple sizes out of stock: Plans #12, #14, #25, #29 ✓
- Extreme overstock scenarios: Plans #13, #15, #21, #27 ✓
- When to allow 10x10 cutting: Plans #20, #24, #30 ✓

---

*Last Updated: December 5, 2025 - Evening Session*
*Status: Phase 2 COMPLETE - Ready for production use*
