#!/usr/bin/env python3
"""
Deep analysis of optimal cutting strategy to balance Years_in_Stock
across all sizes and minimize out-of-stock risk.
"""

# Current inventory for Parent 6018
current = {
    'Half': {'qty': 22, 'sales': 60},
    '10x10': {'qty': 0, 'sales': 105},
    '5x10': {'qty': 20, 'sales': 52},
    '5x5': {'qty': 7, 'sales': 23}
}

def years_in_stock(qty, sales):
    """Calculate years in stock"""
    return qty / sales if sales > 0 else 0

def print_state(state, label):
    """Print current state with years in stock"""
    print(f"\n{label}")
    print("=" * 100)
    for size in ['Half', '10x10', '5x10', '5x5']:
        qty = state[size]['qty']
        sales = state[size]['sales']
        years = years_in_stock(qty, sales)
        print(f"{size:10} | Stock: {qty:3} | Sales: {sales:3} | Years: {years:.3f}")

    # Calculate stats
    years_list = [years_in_stock(state[s]['qty'], state[s]['sales']) for s in ['Half', '10x10', '5x10', '5x5']]
    min_years = min(years_list)
    max_years = max(years_list)
    avg_years = sum(years_list) / len(years_list)
    variance = sum((y - avg_years)**2 for y in years_list) / len(years_list)

    print(f"\nStats: Min={min_years:.3f}, Max={max_years:.3f}, Avg={avg_years:.3f}, Variance={variance:.4f}")

    # Check for out of stock
    out_of_stock = [s for s in ['Half', '10x10', '5x10', '5x5'] if state[s]['qty'] == 0]
    if out_of_stock:
        print(f"OUT OF STOCK: {', '.join(out_of_stock)}")

    return min_years, variance

print("CURRENT STATE:")
print_state(current, "Before Any Cutting")

print("\n" + "=" * 100)
print("EXPLORING CUTTING SCENARIOS")
print("=" * 100)

# Target: Get 10x10 to 0.4 years minimum
target_10x10_years = 0.4
needed_10x10 = int(target_10x10_years * current['10x10']['sales'])
print(f"\nTarget: 10x10 needs {needed_10x10} pieces to reach {target_10x10_years} years in stock")

# Scenario 1: Simple - Just cut enough Half Sheets to get 10x10s to 0.4 years
print("\n" + "-" * 100)
print("SCENARIO 1: Cut Half Sheets to make 10x10s (keep all pieces as-is)")
print("-" * 100)

half_sheets_to_cut_1 = (needed_10x10 + 1) // 2  # Each Half gives 2 10x10s
state1 = {
    'Half': {'qty': current['Half']['qty'] - half_sheets_to_cut_1, 'sales': current['Half']['sales']},
    '10x10': {'qty': half_sheets_to_cut_1 * 2, 'sales': current['10x10']['sales']},
    '5x10': {'qty': current['5x10']['qty'] + (half_sheets_to_cut_1 * 2), 'sales': current['5x10']['sales']},
    '5x5': {'qty': current['5x5']['qty'], 'sales': current['5x5']['sales']}
}

print(f"\nCut {half_sheets_to_cut_1} Half Sheets")
print(f"  Produces: {half_sheets_to_cut_1 * 2} x 10x10 + {half_sheets_to_cut_1 * 2} x 5x10")
min1, var1 = print_state(state1, "Result:")

# Scenario 2: Cut Half Sheets, then further cut some 5x10s to balance 5x5
print("\n" + "-" * 100)
print("SCENARIO 2: Cut Half Sheets, then cut some 5x10s to 5x5s to balance")
print("-" * 100)

# We want to balance Years_in_Stock across all sizes
# Try different amounts of 5x10 -> 5x5 conversion
best_scenario = None
best_min_years = 0
best_variance = float('inf')

for extra_5x10_to_cut in range(0, 25):
    state2 = {
        'Half': {'qty': current['Half']['qty'] - half_sheets_to_cut_1, 'sales': current['Half']['sales']},
        '10x10': {'qty': half_sheets_to_cut_1 * 2, 'sales': current['10x10']['sales']},
        '5x10': {'qty': current['5x10']['qty'] + (half_sheets_to_cut_1 * 2) - extra_5x10_to_cut, 'sales': current['5x10']['sales']},
        '5x5': {'qty': current['5x5']['qty'] + (extra_5x10_to_cut * 2), 'sales': current['5x5']['sales']}
    }

    # Check no negatives
    if state2['5x10']['qty'] < 0:
        break

    years_list = [years_in_stock(state2[s]['qty'], state2[s]['sales']) for s in ['Half', '10x10', '5x10', '5x5']]
    min_years = min(years_list)
    avg_years = sum(years_list) / len(years_list)
    variance = sum((y - avg_years)**2 for y in years_list) / len(years_list)

    # Prefer higher minimum (less risk) and lower variance (more balanced)
    if min_years > best_min_years or (min_years == best_min_years and variance < best_variance):
        best_min_years = min_years
        best_variance = variance
        best_scenario = {
            'half_cut': half_sheets_to_cut_1,
            '5x10_to_5x5': extra_5x10_to_cut,
            'state': state2.copy()
        }

if best_scenario:
    print(f"\nBest balance found:")
    print(f"  Cut {best_scenario['half_cut']} Half Sheets -> {best_scenario['half_cut'] * 2} x 10x10 + {best_scenario['half_cut'] * 2} x 5x10")
    print(f"  Then cut {best_scenario['5x10_to_5x5']} x 5x10 -> {best_scenario['5x10_to_5x5'] * 2} x 5x5")
    print_state(best_scenario['state'], "Result:")

# Scenario 3: More complex - cut Half Sheets, decide on 10x10 cuts too
print("\n" + "-" * 100)
print("SCENARIO 3: Optimize ALL cutting decisions to maximize balance")
print("-" * 100)

# Try all combinations
best_overall = None
best_overall_min = 0
best_overall_var = float('inf')

print("\nSearching for optimal cutting strategy...")

for half_to_cut in range(1, 23):  # Can cut 1-22 half sheets
    initial_10x10 = half_to_cut * 2
    initial_5x10 = current['5x10']['qty'] + (half_to_cut * 2)

    # Try cutting some 10x10s
    for ten_to_cut in range(0, initial_10x10 + 1):
        remaining_10x10 = initial_10x10 - ten_to_cut
        # 10x10 can become 2x5x10 or 4x5x5
        # For simplicity, assume we cut to 2x5x10
        added_5x10_from_10 = ten_to_cut * 2

        # Try cutting some 5x10s to 5x5
        total_5x10_available = initial_5x10 + added_5x10_from_10
        for five10_to_cut in range(0, total_5x10_available + 1):
            state = {
                'Half': {'qty': current['Half']['qty'] - half_to_cut, 'sales': current['Half']['sales']},
                '10x10': {'qty': remaining_10x10, 'sales': current['10x10']['sales']},
                '5x10': {'qty': total_5x10_available - five10_to_cut, 'sales': current['5x10']['sales']},
                '5x5': {'qty': current['5x5']['qty'] + (five10_to_cut * 2), 'sales': current['5x5']['sales']}
            }

            # Check constraints
            if state['Half']['qty'] < 0:
                continue

            # Check if 10x10 meets minimum target
            if years_in_stock(state['10x10']['qty'], state['10x10']['sales']) < target_10x10_years:
                continue

            # Calculate balance
            years_list = [years_in_stock(state[s]['qty'], state[s]['sales']) for s in ['Half', '10x10', '5x10', '5x5']]
            min_years = min(years_list)
            avg_years = sum(years_list) / len(years_list)
            variance = sum((y - avg_years)**2 for y in years_list) / len(years_list)

            # Maximize minimum years (safety), minimize variance (balance)
            score = min_years - (variance * 0.1)  # Weighted combination

            if best_overall is None or score > (best_overall_min - best_overall_var * 0.1):
                best_overall_min = min_years
                best_overall_var = variance
                best_overall = {
                    'half_cut': half_to_cut,
                    '10x10_cut': ten_to_cut,
                    '5x10_cut': five10_to_cut,
                    'state': state.copy()
                }

if best_overall:
    print(f"\nOPTIMAL STRATEGY FOUND:")
    print(f"  1. Cut {best_overall['half_cut']} Half Sheets -> {best_overall['half_cut'] * 2} x 10x10 + {best_overall['half_cut'] * 2} x 5x10")
    if best_overall['10x10_cut'] > 0:
        print(f"  2. Cut {best_overall['10x10_cut']} x 10x10 -> {best_overall['10x10_cut'] * 2} x 5x10")
    if best_overall['5x10_cut'] > 0:
        print(f"  3. Cut {best_overall['5x10_cut']} x 5x10 -> {best_overall['5x10_cut'] * 2} x 5x5")
    print_state(best_overall['state'], "\nFinal Result:")

print("\n" + "=" * 100)
print("CONCLUSION:")
print("=" * 100)
print("\nKey insight: Balancing Years_in_Stock minimizes risk of any size going out of stock")
print("Strategy: Target equal Years_in_Stock across all sizes after cutting")
