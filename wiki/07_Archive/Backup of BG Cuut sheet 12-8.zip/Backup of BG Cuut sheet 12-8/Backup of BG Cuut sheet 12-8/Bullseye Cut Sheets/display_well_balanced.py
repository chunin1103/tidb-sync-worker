import csv
from collections import defaultdict

# Read the main inventory file
csv_file = r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye Cut Sheet Sample File 12-5-25.csv"

parents = defaultdict(lambda: {
    'Half': {'qty': 0, 'purchased': 0},
    '10x10': {'qty': 0, 'purchased': 0},
    '5x10': {'qty': 0, 'purchased': 0},
    '5x5': {'qty': 0, 'purchased': 0},
    'name': ''
})

with open(csv_file, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)

    for row in reader:
        product_name = row.get('Product_Name', '')
        status = row.get('Products Status', '')

        has_size = any(size in product_name for size in ['10"x10"', '5"x10"', '5"x5"', 'Half Sheet'])
        is_3mm = '3mm' in product_name

        if not (has_size and is_3mm and status == 'Active'):
            continue

        parent_id = row.get('Products_Parent_Id', '').strip()
        if not parent_id:
            continue

        qty = int(float(row.get('Quantity_in_Stock', 0) or 0))
        purchased = int(float(row.get('Purchased', 0) or 0))

        if not parents[parent_id]['name']:
            # Clean up name
            name = product_name
            for suffix in [' Half Sheet', ' 10"x10"', ' 5"x10"', ' 5"x5"', ' 3mm']:
                name = name.replace(suffix, '')
            parents[parent_id]['name'] = name

        size = None
        if 'Half Sheet' in product_name:
            size = 'Half'
        elif '10"x10"' in product_name or '10x10' in product_name:
            size = '10x10'
        elif '5"x10"' in product_name or '5x10' in product_name:
            size = '5x10'
        elif '5"x5"' in product_name or '5x5' in product_name:
            size = '5x5'

        if size:
            parents[parent_id][size]['qty'] += qty
            parents[parent_id][size]['purchased'] += purchased

# Read cutting candidates to exclude
cutting_ids = set()
with open('101_Cutting_Candidates.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        cutting_ids.add(row['Parent_ID'])

# Find well-balanced parents
well_balanced = []

for parent_id, data in parents.items():
    if parent_id in cutting_ids:
        continue

    sizes = ['Half', '10x10', '5x10', '5x5']

    # Count sizes with stock
    stocked_sizes = sum(1 for s in sizes if data[s]['qty'] > 0)

    # Has Half Sheet?
    has_half = data['Half']['qty'] > 0

    # Check for zeros
    has_zero = any(data[s]['qty'] == 0 and data[s]['purchased'] > 0 for s in sizes)

    # Skip if no source or has zeros
    if not has_half or stocked_sizes < 3 or has_zero:
        continue

    # Calculate min years
    min_years = float('inf')
    size_data = {}
    for s in sizes:
        if data[s]['purchased'] > 0:
            years = data[s]['qty'] / data[s]['purchased']
            days = int(years * 365)
            size_data[s] = {'qty': data[s]['qty'], 'purchased': data[s]['purchased'], 'years': years, 'days': days}
            if years < min_years:
                min_years = years
        elif data[s]['qty'] > 0:
            size_data[s] = {'qty': data[s]['qty'], 'purchased': 0, 'years': 999, 'days': 999}

    if min_years >= 0.25 and min_years < 999:
        well_balanced.append({
            'parent_id': parent_id,
            'name': data['name'],
            'min_years': min_years,
            'min_days': int(min_years * 365),
            'sizes': size_data
        })

# Sort by min_years ascending (show lowest first)
well_balanced.sort(key=lambda x: x['min_years'])

# Display in batches of 5
import sys
start = int(sys.argv[1]) if len(sys.argv) > 1 else 1
end = start + 4

print(f"WELL BALANCED PARENTS: #{start}-{end} of {len(well_balanced)}")
print("=" * 70)
print()

for i, item in enumerate(well_balanced[start-1:end], start=start):
    print(f"## #{i}: {item['name']}")
    print(f"**Parent ID:** {item['parent_id']}")
    print(f"**Min Coverage:** {item['min_days']} days ({item['min_years']:.3f} years)")
    print()
    print("| Size | Qty | Sales/yr | Years (Days) |")
    print("|------|-----|----------|--------------|")
    for size in ['Half', '10x10', '5x10', '5x5']:
        if size in item['sizes']:
            s = item['sizes'][size]
            if s['days'] < 999:
                years_days_str = f"{s['years']:.3f} ({s['days']} days)"
            else:
                years_days_str = "N/A (no sales)"
            print(f"| {size} | {s['qty']} | {s['purchased']} | {years_days_str} |")
    print()
    # Find which size is the minimum
    min_size = None
    for size in ['Half', '10x10', '5x10', '5x5']:
        if size in item['sizes']:
            s = item['sizes'][size]
            if s['days'] == item['min_days']:
                min_size = size
                break
    print(f"**Why Well Balanced:** {min_size} is at {item['min_years']:.3f} years ({item['min_days']} days) - meets 0.25 year threshold. No cutting needed.")
    print()
    print("-" * 70)
    print()

print(f"Showing {start}-{min(end, len(well_balanced))} of {len(well_balanced)}")
print(f"Next batch: python display_well_balanced.py {end + 1}")
