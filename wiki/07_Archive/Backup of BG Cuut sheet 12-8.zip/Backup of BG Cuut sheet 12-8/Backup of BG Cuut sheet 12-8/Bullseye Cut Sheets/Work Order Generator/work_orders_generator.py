#!/usr/bin/env python3
import sys, re
from pathlib import Path
import pandas as pd
import numpy as np
from collections import Counter

# -------------------- Config (don’t change unless needed) --------------------
ORDER = ["24x24","12x12","6x12","6x6"]              # size order, largest → smallest
SIZE_SORT = {"24x24":0,"12x12":1,"6x12":2,"6x6":3}
AREA_BY_SIZE = {"24x24":576,"12x12":144,"6x12":72,"6x6":36}

# Tabs to create (fixed by spec)
CREATE_TABS = ["Picks","Steps","Barcode_Labels","Inventory_Deltas"]

# -------------------- Column detection helpers --------------------
def detect_prod_col(columns):
    # exact matches
    for c in columns:
        if c in ["Product_ID","Products_ID","ID","ProductID"]:
            return c
    # contains "product" and "id"
    for c in columns:
        cl = c.lower()
        if "product" in cl and "id" in cl:
            return c
    return None

def detect_parent_col(columns):
    for c in columns:
        cl = c.lower()
        if "parent" in cl and "id" in cl:
            return c
    return None

def detect_qty_col(columns):
    cands = {"qty","quantity","quantity_in_stock","qty_in_stock","stock","onhand","on_hand","on hand"}
    for c in columns:
        if c.lower() in cands:
            return c
    return None

def normalize_size(s):
    if not isinstance(s, str): return None
    sl = s.lower().replace("×","x").replace("”",'"').replace("“",'"')
    m = re.search(r'(\d+(?:\.\d+)?)\s*(?:\"|in|inch|inches)?\s*[x×]\s*(\d+(?:\.\d+)?)\s*(?:\"|in|inch|inches)?', sl)
    if not m: return None
    a,b = m.group(1), m.group(2)
    try:
        return f"{float(a):g}x{float(b):g}"
    except:
        return None

def closest_known(sz):
    if not isinstance(sz,str) or 'x' not in sz: return None
    try:
        a,b = map(float, sz.split('x')); area = a*b
    except:
        return None
    return min(AREA_BY_SIZE.keys(), key=lambda k: abs(area - AREA_BY_SIZE[k]))

# -------------------- Per-parent planning --------------------
def plan_for_parent(df, prod_col, parent_col, qty_col, yis_col, name_col, parent_id):
    fam = df[(df[parent_col]==parent_id) | (df[prod_col]==parent_id)].copy()
    children = fam[fam[parent_col]==parent_id].copy()
    if children.empty:
        return None

    # Map sizes, child IDs, product names
    if name_col and name_col in children.columns:
        children["_size_raw"] = children[name_col].apply(normalize_size)
    else:
        children["_size_raw"] = None
    children["_known"] = children["_size_raw"].apply(closest_known)

    id_by_known = {}
    name_by_child = {}
    for k in ORDER:
        sub = children[children["_known"]==k]
        if not sub.empty and prod_col in sub.columns:
            try:
                cid = int(float(sub.iloc[0][prod_col]))
            except:
                cid = str(sub.iloc[0][prod_col])
            id_by_known[k] = cid
            name_by_child[cid] = str(sub.iloc[0][name_col]) if (name_col in sub.columns) else ""

    # Sales estimate from displayed YIS (if present); else fallback = 100
    if yis_col and yis_col in children.columns:
        children[yis_col] = pd.to_numeric(children[yis_col], errors='coerce')
        children[qty_col] = pd.to_numeric(children[qty_col], errors='coerce').fillna(0.0)
        children["sales_est"] = np.where(children[yis_col]>0, children[qty_col]/children[yis_col], np.nan)
    else:
        children["sales_est"] = np.nan
    if children["sales_est"].notna().sum() > 0:
        fill = children["sales_est"].median()
        children["sales_est"] = children["sales_est"].fillna(fill)
    else:
        children["sales_est"] = 100.0

    stock_before = children.groupby("_known")[qty_col].sum()
    sales = children.groupby("_known")["sales_est"].median()
    for k in ORDER:
        if k not in stock_before.index: stock_before.loc[k]=0.0
        if (k not in sales.index) or pd.isna(sales.get(k)):
            sales.loc[k] = 100.0

    # Greedy plan to minimize YIS std-dev
    yields = {"24x24":{"12x12":4,"6x12":8,"6x6":16},
              "12x12":{"6x12":2,"6x6":4},
              "6x12":{"6x6":2}}
    stock = stock_before.reindex(ORDER).fillna(0.0).astype(float)

    def yis_std(st):
        y = st / sales.reindex(ORDER)
        return float(np.nanstd(y.values, ddof=0))

    plan_steps = []  # (donor_size, target_size, yield_units)
    for _ in range(500):
        cur = yis_std(stock)
        best_gain=0; best=None; best_new=None; best_yld=0
        for donor, outs in yields.items():
            if stock.get(donor,0) < 1: continue
            for target, yld in outs.items():
                trial=stock.copy(); trial[donor]-=1; trial[target]+=yld
                gain = cur - yis_std(trial)
                if gain > best_gain + 1e-12:
                    best_gain, best, best_new, best_yld = gain, (donor, target), trial, yld
        if best_new is None: break
        stock = best_new
        plan_steps.append((best[0], best[1], best_yld))

    # Build tabs
    # Picks (NO Parent_ID in output)
    donor_counts = Counter([d for d,_,_ in plan_steps])
    picks_rows = []
    for donor_size, cnt in sorted(donor_counts.items(), key=lambda x: SIZE_SORT.get(x[0], 99)):
        if cnt <= 0: continue
        cid = id_by_known.get(donor_size, "")
        pname = name_by_child.get(cid, "")
        picks_rows.append({"Donor_Child_ID": cid, "Donor_Name": pname, "Donor_Size": donor_size, "Pick_Qty": int(cnt)})
    picks = pd.DataFrame(picks_rows)

    # Steps (KEEP Parent_ID for context)
    label_map = {("24x24","12x12"):"Cut 24×24 → 4× 12×12",
                 ("24x24","6x12"):"Cut 24×24 → 8× 6×12",
                 ("24x24","6x6"):"Cut 24×24 → 16× 6×6",
                 ("12x12","6x12"):"Cut 12×12 → 2× 6×12",
                 ("12x12","6x6"):"Cut 12×12 → 4× 6×6",
                 ("6x12","6x6"):"Cut 6×12 → 2× 6×6"}
    combo_counts = Counter([(d,t) for d,t,_ in plan_steps])
    step_rows=[]; step_num=1
    for (donor_size, target_size), repeat in sorted(combo_counts.items(), key=lambda x:(SIZE_SORT.get(x[0][0],99), x[0][1])):
        donor_cid  = id_by_known.get(donor_size, "")
        target_cid = id_by_known.get(target_size, "")
        step_rows.append({"Parent_ID": int(parent_id),
                          "Step": step_num,
                          "Donor_Child_ID": donor_cid,
                          "Donor_Name": name_by_child.get(donor_cid, ""),
                          "Instruction": label_map[(donor_size, target_size)],
                          "Repeat": int(repeat),
                          "Target_Child_ID": target_cid,
                          "Target_Name": name_by_child.get(target_cid, "")})
        step_num += 1
    steps = pd.DataFrame(step_rows)

    # Barcode_Labels (NO Parent_ID)
    produced_units = {}
    for _, target, yld in plan_steps:
        produced_units[target] = produced_units.get(target, 0) + yld
    label_rows = []
    for sz, n in produced_units.items():
        cid = id_by_known.get(sz, "")
        if cid != "":
            label_rows.append({"Child_ID": cid, "Labels_to_Print": int(n), "Product_Name": name_by_child.get(cid, "")})
    labels = pd.DataFrame(label_rows)

    # Inventory_Deltas (NO Parent_ID, NO Size)
    stock_after = stock
    inv = pd.DataFrame({
        "Child_ID":      [id_by_known.get(sz, "") for sz in ORDER],
        "Product_Name":  [name_by_child.get(id_by_known.get(sz, ""), "") for sz in ORDER],
        "Qty_before":    [stock_before.get(sz, 0.0) for sz in ORDER],
        "Qty_after":     [stock_after.get(sz, 0.0) for sz in ORDER],
        "Net_Change":    [stock_after.get(sz, 0.0) - stock_before.get(sz, 0.0) for sz in ORDER],
    })
    inv = inv[inv["Net_Change"] != 0].reset_index(drop=True)

    return picks, steps, labels, inv

def main(input_csv:str, output_xlsx:str):
    df = pd.read_csv(input_csv, dtype=str)
    # Detect columns
    prod_col = detect_prod_col(df.columns)
    parent_col = detect_parent_col(df.columns)
    qty_col = detect_qty_col(df.columns)
    yis_col = df.columns[7] if len(df.columns) > 7 else None
    name_col = df.columns[2] if len(df.columns) > 2 else None

    if prod_col is None or parent_col is None or qty_col is None:
        raise SystemExit("Required columns not found (Product_ID/Parent_ID/Quantity).")

    # Coerce numerics where needed
    df[prod_col] = pd.to_numeric(df[prod_col], errors='coerce')
    df[parent_col] = pd.to_numeric(df[parent_col], errors='coerce')
    df[qty_col] = pd.to_numeric(df[qty_col], errors='coerce').fillna(0.0)

    # Build unified tables across ALL parents
    parent_vals = df[parent_col].dropna().astype(str).str.strip()
    all_parents = []
    for v in parent_vals:
        if v and v not in all_parents:
            all_parents.append(v)
    all_parent_ids = []
    for v in all_parents:
        try: all_parent_ids.append(int(float(v)))
        except: pass

    picks_all, steps_all, labels_all, inventory_all = [], [], [], []
    for pid in all_parent_ids:
        res = plan_for_parent(df, prod_col, parent_col, qty_col, yis_col, name_col, pid)
        if res is None: 
            continue
        p, s, l, inv = res
        picks_all.append(p); steps_all.append(s); labels_all.append(l); inventory_all.append(inv)

    # Concatenate
    picks_all     = pd.concat(picks_all, ignore_index=True) if picks_all else pd.DataFrame(columns=["Donor_Child_ID","Donor_Name","Donor_Size","Pick_Qty"])
    steps_all     = pd.concat(steps_all, ignore_index=True) if steps_all else pd.DataFrame(columns=["Parent_ID","Step","Donor_Child_ID","Donor_Name","Instruction","Repeat","Target_Child_ID","Target_Name"])
    labels_all    = pd.concat(labels_all, ignore_index=True) if labels_all else pd.DataFrame(columns=["Child_ID","Labels_to_Print","Product_Name"])
    inventory_all = pd.concat(inventory_all, ignore_index=True) if inventory_all else pd.DataFrame(columns=["Child_ID","Product_Name","Qty_before","Qty_after","Net_Change"])

    # Write workbook
    with pd.ExcelWriter(output_xlsx, engine="xlsxwriter") as writer:
        picks_all.to_excel(writer, index=False, sheet_name="Picks")
        steps_all.to_excel(writer, index=False, sheet_name="Steps")
        labels_all.to_excel(writer, index=False, sheet_name="Barcode_Labels")
        inventory_all.to_excel(writer, index=False, sheet_name="Inventory_Deltas")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python work_orders_generator.py /path/to/cleaned_filtered.csv /path/to/output.xlsx")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
