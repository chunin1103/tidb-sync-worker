
# Work Orders Generator — Saved Logic

This folder includes two ways to recreate your work‑order export any time:

## A) Python script (recommended for repeat use)
**File:** `work_orders_generator.py`

**What it does**
- Reads your **cleaned CSV** (the same format we've been using).
- Generates one Excel file with 4 tabs for **all parents**:
  - `Picks` — Donor_Child_ID, Donor_Name, Donor_Size, Pick_Qty (no Parent_ID)
  - `Steps` — Step, Donor_Child_ID, Donor_Name, Instruction, Repeat, Target_Child_ID, Target_Name (**keeps Parent_ID for context**)
  - `Barcode_Labels` — Child_ID, Labels_to_Print, Product_Name (no Parent_ID)
  - `Inventory_Deltas` — Child_ID, Product_Name, Qty_before, Qty_after, Net_Change (**no Size, no Parent_ID; Net_Change ≠ 0**)

**Usage**
```bash
python work_orders_generator.py "/path/to/cleaned_filtered.csv" "/path/to/output.xlsx"
```
Example:
```bash
python work_orders_generator.py "/mnt/data/cleaned_filtered oeanside after 0 stock families removed.csv" "/mnt/data/work_orders_ALL.xlsx"
```

## B) Copy‑paste prompt
**File:** `RECREATE_PROMPT.txt`  
Paste this prompt into a new chat to have ChatGPT regenerate the exact export if you don't want to run the script.

---

**Notes**
- The script auto‑detects key columns (Product_ID, Parent_ID, Quantity; Column C as name, Column H as Years in Stock).
- YIS is used only as displayed; if missing, sales rates default to 100 to allow balancing.
- Cutting yields: 24×24→4×12×12 / 8×6×12 / 16×6×6; 12×12→2×6×12 / 4×6×6; 6×12→2×6×6.
- Inventory_Deltas show **only** sizes that change (Net_Change ≠ 0).
