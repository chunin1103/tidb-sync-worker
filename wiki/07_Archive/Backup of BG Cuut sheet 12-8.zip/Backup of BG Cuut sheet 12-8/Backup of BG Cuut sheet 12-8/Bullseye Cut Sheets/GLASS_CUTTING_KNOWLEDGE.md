# Bullseye Glass Cutting - Complete Knowledge Base

## Business Overview
**ArtGlassSupplies.com** - Sells Bullseye glass art supplies, primarily Bullseye COE90 glass sheets in various sizes, colors, types, and thicknesses.

---

## Glass Specifications

### Sheet Sizes Sold
- **5x5** - Smallest retail size
- **5x10**
- **10x10**
- **Half Sheet** (~17x20)
- **Full Sheet** (20x35) - Received from Bullseye

### Bullseye Full Sheet Specifications
- **Nominal Size:** 20" × 35"
- **Tolerance:** 20" × 32" to 20" × 37"
- **Thickness Options:** 2mm (thin-rolled) and 3mm (double-rolled)
- **Types:** Transparent, Opalescent, Streaky, etc.

### Rolled Edges
- **All Bullseye sheets have at least one rolled edge** from manufacturing
- **Rolled edges are a FEATURE, not defect** - customers expect them
- **Rolled edges are included** on final pieces when sold:
  - Half Sheet: Has rolled edges
  - 10x10: Has rolled edges
  - 5x10: Has rolled edges
  - **5x5: May or may not have rolled edge** (depends on where it was cut from parent sheet)

---

## Inventory Management Workflow

### When Full Sheets Arrive from Bullseye

1. **Full sheets (20x35) are received**
2. **Immediately evaluate what sizes are needed** based on:
   - Historical sales data
   - Current stock levels
   - Years in stock (from inventory CSV)
   - Reorder quantities
3. **Cut full sheets into optimal mix of sizes**
   - This is strategic, done when receiving new inventory
   - Goal: Balance inventory across all sizes

### Between Bullseye Orders (Gap Filling)

1. **Some sizes sell faster than others** → inventory becomes unbalanced
2. **Gap filling cuts** made from existing cut inventory:
   - Use excess 10x10s to make 5x10s or 5x5s
   - Use excess 5x10s to make 5x5s
   - Use Half Sheets to make smaller sizes
3. **This is temporary** - fills gaps until next full sheet order
4. **Cut Sheet = the gap-filling plan**

---

## Glass Cutting Fundamentals

### Basic Principle
**Glass is cut by dividing pieces in half** (or into equal portions) with straight cuts.

### You NEVER Cut:
- ❌ 5x5 pieces (already the smallest retail size)

### Cutting Rules:
- ✅ Only straight cuts
- ✅ Cuts divide glass into equal or logical portions
- ✅ All cutting produces some waste strips

---

## Cutting Patterns & Yields

### Full Sheet (20x35) → Primary Cutting Options

**Option 1: Maximize 10x10s**
```
20x35 Full Sheet
├─ Cut 3 columns (10" each) × 2 rows (10" each)
├─ Result: 6×10x10 pieces
└─ Remainder: 20x5 strip
   └─ Cut: 2×5x10 pieces (or 4×5x5)

YIELD: 6×10x10 + 2×5x10 (or 6×10x10 + 4×5x5)
WASTE: Small strips
```

**Option 2: Mixed sizes**
```
Many combinations possible:
- 4×10x10 + 4×5x10 + additional smaller pieces
- Optimize based on what's needed
```

### Half Sheet (17x20) → Standard Primary Cut

**Standard Pattern (Always start this way):**
```
17x20 Half Sheet
├─ Cut down middle (20" direction) → Two 17x10 pieces
├─ Each 17x10 piece:
│  ├─ Cut at 10" → One 10x10
│  └─ Cut remainder 7x10:
│     └─ Cut at 5" → One 5x10
│     └─ Waste: 2x10 strip

YIELD: 2×10x10 + 2×5x10
WASTE: Two 2x10 strips
```

### Why Full Sheets are Better

**Full Sheet yields MORE usable glass:**
- Full Sheet: **6×10x10 + 2×5x10**

**VS Two Half Sheets:**
- 2 Half Sheets: **4×10x10 + 4×5x10**

**Result:** Full sheet gives you **2 more 10x10s** (50% more of the most valuable size!)

### 10x10 Cutting Options

**Option 1: Two 5x10 pieces**
```
10x10 → Cut in half → 2×5x10
```

**Option 2: Four 5x5 pieces**
```
10x10 → Cut in half both ways → 4×5x5
```

**Option 3: One 5x10 + Two 5x5 pieces**
```
10x10 → Cut once to get 5x10
      → Cut remaining 5x10 in half → 2×5x5
YIELD: 1×5x10 + 2×5x5
```

### 5x10 Cutting

**Only Option: Two 5x5 pieces**
```
5x10 → Cut in half → 2×5x5
```

### 5x5 Cutting

**Not cut** - this is the smallest retail size.

---

## Cascade Cutting Logic

When cutting from larger pieces, follow the cascade pattern:

### Half Sheet → 5x5 (Full Cascade)
```
Step 1: Half Sheet (17x20) → 2×10x10 + 2×5x10
Step 2: Each 10x10 → 4×5x5 (2 sheets = 8 pieces)
Step 3: Each 5x10 → 2×5x5 (2 sheets = 4 pieces)

FINAL YIELD: 12×5x5 per Half Sheet
```

### Half Sheet → 5x10 (Partial Cascade)
```
Step 1: Half Sheet (17x20) → 2×10x10 + 2×5x10
Step 2: Each 10x10 → 2×5x10 (2 sheets = 4 pieces)

FINAL YIELD: 6×5x10 per Half Sheet (2 direct + 4 from 10x10s)
```

### Half Sheet → 10x10 (Primary Cut Only)
```
Step 1: Half Sheet (17x20) → 2×10x10 + 2×5x10

FINAL YIELD: 2×10x10 per Half Sheet
BONUS: Also get 2×5x10 (can be used or held as inventory)
```

---

## Waste Management

### Waste Strips
- Cutting produces **2" waste strips** (e.g., 2x10 from half sheets)
- **Waste is NOT thrown away**
- **All waste goes into "Scrap Packs"** - sold to customers
- Therefore: **Nothing is truly wasted**

### Optimization Goal
- **Don't need to minimize waste** (it's sold as scrap packs)
- **DO need to optimize** getting the right sizes efficiently
- Focus: Match demand, not reduce waste

---

## Inventory Data Structure

### CSV File: `Bullseye Cut Sheet Sample File 12-4-25.csv`

**Key Fields:**

- `Product_Name` - Full description including size, color, type, thickness
- `Product_ID` - Unique product identifier for each child SKU
- `Products_Parent_Id` - Groups related products (same glass type, different sizes)
  - All children with same Parent ID = same glass properties = can be cut from each other
  - Parent products are organizational only, never sold (unless they have no children)
- `Purchased` - Units sold in the report date range (typically 1 year)
  - **Best indicator of product popularity/demand**
  - Higher Purchased = better seller = higher priority for restocking
- `Quantity_in_Stock` - Current inventory count
- `Years_in_Stock` - Calculated: `Quantity_in_Stock ÷ Purchased`
  - How many years the current stock will last at current sales rate
  - Example: 6 units in stock ÷ 43 sold/year = 0.14 years (~7 weeks)
  - **Low Years_in_Stock ≠ fast seller** (can be misleading from one-time bulk purchase)
  - Use `Purchased` instead for determining popularity
- `Reorder` - "Y" or "N" - **Manually set by staff**
  - Y = Should reorder when out of stock
  - N = Do not reorder (reasons: discontinued, manufacturer stopped making, don't want to sell)
  - When Quantity=0 for extended period, usually becomes InActive
- `Reorder_Quantity` - Calculated: `Purchased ÷ 4`
  - Goal: Stock enough for 1 quarter year (3 months)
  - Example: 40 sold/year → Reorder_Quantity = 10
- `Products Status` - "Active" or "InActive"
  - Active = Currently selling
  - InActive = Discontinued, no longer selling
- `Vendor SKU` - Bullseye's product SKU number
  - Not used for cut sheet optimizer
  - Critical for full sheet ordering system (Problem 1)

### Product Name Format
```
"Bullseye Glass [Color] [Type], [Rolling], [Thickness] COE90 - Size [Size]"

Example:
"Bullseye Glass Aqua Blue Transparent, Double-rolled, 3mm COE90 - Size 10"x10""
```

### Glass Properties (Must Match for Cutting)
1. **Color** - e.g., "Aqua Blue", "Deep Red"
2. **Type** - Transparent, Opalescent, Streaky, etc.
3. **Thickness** - 2mm or 3mm
4. **Size** - 5x5, 5x10, 10x10, Half Sheet

**CRITICAL:** Can only cut glass where color, type, AND thickness match!
- ❌ Cannot cut "Aqua Blue Transparent 3mm" to make "Red Opalescent 3mm"
- ✅ CAN cut "Aqua Blue Transparent 3mm 10x10" to make "Aqua Blue Transparent 3mm 5x5"

---

## Data Quality Checks

The optimizer performs automatic data quality checks on the inventory CSV:

### Error Conditions

**ERROR: InActive product has stock**
- Condition: `Status = "InActive"` AND `Quantity_in_Stock > 0`
- Problem: Discontinued products should not have inventory
- Action: Investigate why discontinued item has stock

**WARNING: Out of stock, Reorder=N, but still Active**
- Condition: `Reorder = "N"` AND `Quantity_in_Stock = 0` AND `Status = "Active"`
- Problem: Product is out of stock, not being reordered, but still marked as Active
- Action: Should probably be marked InActive

### Why These Matter

- Keeps product catalog clean
- Prevents trying to restock discontinued items
- Identifies products that should be InActive
- Ensures data consistency for accurate optimization

---

## Balanced Cutting Strategy (Weekly Cut Sheets)

### The Problem with Simple Gap-Filling

**Naive Approach:** Just fill the out-of-stock size
- Example: 10x10 is out of stock, so cut 21 Half Sheets to get 42×10x10
- **Result:** Creates new imbalances
  - Half Sheets: Nearly depleted (0.017 years)
  - 10x10: Filled (0.400 years)
  - 5x10: Massively overstocked (1.115 years)
  - Creates NEW risk of Half Sheets running out

### The Balanced Optimization Approach

**Goal:** Maximize the MINIMUM Years_in_Stock across ALL sizes
- This minimizes risk of ANY size going out of stock
- Perfect for weekly cutting cycles

**Key Insight:** Target EQUAL Years_in_Stock across all sizes after cutting

### The Algorithm

1. **For each glass type (Parent ID):**
   - Get current inventory for all 4 sizes (Half, 10x10, 5x10, 5x5)
   - Calculate current Years_in_Stock for each

2. **Try all possible cutting combinations:**
   - Half Sheets to cut: 0 to available
   - For each Half cut: produces 2×10x10 + 2×5x10
   - 10x10s to cut to 5x10: 0 to available (each makes 2×5x10)
   - 10x10s to cut to 5x5: 0 to remaining (each makes 4×5x5)
   - 5x10s to cut to 5x5: 0 to available (each makes 2×5x5)

3. **Evaluate each combination:**
   - Calculate final Years_in_Stock for all sizes
   - Find minimum Years_in_Stock (the bottleneck)
   - Calculate balance (range between min and max)

4. **Select optimal combination:**
   - **Primary goal:** Maximize minimum Years_in_Stock
   - **Secondary goal:** Minimize range (most balanced)
   - **Constraint:** No sizes go to zero (out of stock)

### Example: Parent 6018 (Clear, White Streaky)

**Before Cutting:**
- Half Sheet: 22 (0.367 years)
- 10x10: 0 (0.000 years) ← OUT OF STOCK
- 5x10: 20 (0.385 years)
- 5x5: 7 (0.304 years)
- **Minimum: 0.000** (10x10 out!)

**Naive Approach (cut 21 Half to fill 10x10):**
- Half Sheet: 1 (0.017 years) ← NEW PROBLEM!
- 10x10: 42 (0.400 years)
- 5x10: 62 (1.115 years) ← OVERSTOCKED
- 5x5: 7 (0.304 years)
- **Minimum: 0.017** (Half Sheets nearly gone!)

**Balanced Optimization:**
- Cut 10 Half Sheets → 20×10x10 + 20×5x10
- Cut 4×5x10 → 8×5x5

**After Balanced Cutting:**
- Half Sheet: 12 (0.200 years) ✓
- 10x10: 20 (0.190 years) ✓
- 5x10: 36 (0.692 years) ✓
- 5x5: 15 (0.652 years) ✓
- **Minimum: 0.190** (10× better than naive!)

### Why This Works

1. **No single point of failure** - all sizes have similar runway
2. **Weekly cycles work smoothly** - sizes deplete at similar rates
3. **Prevents over-cutting** - don't waste inventory on one size
4. **Adaptable** - adjust weekly based on actual sales

### Constraints to Consider

- **Must use ALL pieces from cuts** - Can't waste the 5x10s from Half Sheet cuts
- **Target minimum threshold** - Might want at least 0.15-0.20 years for safety
- **Don't over-cut** - If a size already has 1+ years, don't add more
- **Active products only** - Don't cut for InActive products

### Implementation Priority

**RULE #1: Always get zero-inventory products off zero FIRST**

When multiple glass types need cutting, prioritize by:
1. **Has ANY size at zero inventory** (CRITICAL - must fix immediately)
2. **Lowest minimum Years_in_Stock** (most urgent among non-zero)
3. **Highest total annual sales** (most important products)
4. **Largest imbalance** (biggest risk)

**Example:**
- Glass A: 10x10 is at ZERO (0.000 years) → Priority 1
- Glass B: All sizes have stock, but 10x10 is low (0.150 years) → Priority 2
- Glass C: All sizes well balanced (0.300+ years) → No cutting needed

**Cut Sheet Display Order:**
1. Products with zero inventory (sorted by annual sales - highest first)
2. Products needing balance (sorted by minimum years - lowest first)
3. Within each group, show highest-selling products first

---

## Two Optimization Problems

### Problem 1: Full Sheet Planning (Future Tool)
**When:** Receiving new full sheets from Bullseye
**Goal:** Decide how to cut full sheets optimally

**Inputs:**
- Number of full sheets arriving (by color/type)
- Current inventory levels
- Years in stock (sales velocity)
- Historical reorder quantities
- Seasonal trends

**Output:**
- Cutting plan: "Cut 30 sheets into 6×10x10 + 2×5x10"
- Or: "Cut 20 sheets into 4×10x10 + 6×5x10"
- Optimizes for predicted demand

**Status:** Not yet built

### Problem 2: Gap Filling Optimization (Current Tool)
**When:** Between Bullseye orders, when specific sizes run low
**Goal:** Use existing cut inventory to fill gaps temporarily

**Inputs:**
- Current inventory CSV
- Identify: What's out of stock (Quantity=0, Reorder=Y)
- Find: Excess inventory in larger sizes (same glass type)

**Output:**
- Cut sheet instructions: "Cut 3 sheets of 'Aqua Blue 10x10' into 5x10s"
- Step-by-step cascade instructions
- Final yield for each cutting operation

**Status:** Built and working (glass_cutting_optimizer.py)

---

## Current Tool: glass_cutting_optimizer.py

### What It Does
1. Reads inventory CSV
2. Finds products that need restocking (Quantity=0, Reorder=Y)
3. Finds matching glass in larger sizes with available stock
4. Calculates optimal cutting patterns using cascade logic
5. Generates CSV with step-by-step cutting instructions

### Current Scope
- **Only processes 3mm glass** (double-rolled)
- Matches glass by: color + type + thickness
- Uses cascade cutting patterns
- Prioritizes: 5x10 → 10x10 → Half Sheet as cutting sources

### Output Format
CSV with columns:
- Priority (cutting order)
- Glass Type (color/type/thickness)
- Source Product & Size
- Target Product & Size
- Sheets to Cut
- Target Pieces Produced
- Step 1, Step 2, Step 3 (cascade steps)
- Final Yield (all pieces produced)

### Usage
```bash
python glass_cutting_optimizer.py
```
Reads: `Bullseye Cut Sheet Sample File 12-4-25.csv`
Outputs: `Cutting_Instructions_Output.csv`

---

## Future Enhancements

### Immediate Next Steps
1. Add support for 2mm (thin-rolled) glass
2. Consider "Years in Stock" for prioritization
3. Add mixed 10x10 cutting option (1×5x10 + 2×5x5)
4. Handle bonus pieces from half sheet cuts

### Future Full Sheet Planner
1. Build full sheet cutting optimizer
2. Consider sales velocity (Years in Stock)
3. Predict demand by size
4. Optimize full sheet cutting patterns
5. Balance inventory across all sizes strategically

### Advanced Features
- Minimum stock thresholds (not just zero stock)
- Cost optimization (minimize cutting labor)
- Seasonal demand patterns
- Integration with order management system

---

## Important Reminders

1. **Rolled edges are normal and expected** - part of the product
2. **Nothing is wasted** - scrap goes into packs
3. **Always match glass properties** when cutting (color/type/thickness)
4. **Full sheets yield more** than equivalent half sheets
5. **Cut sheets are gap-fillers**, not strategic planning
6. **Half sheets always start** with the same primary cut (2×10x10 + 2×5x10)
7. **5x5 is the smallest size** - never cut further

---

## Key Business Insights

- **Years in Stock** indicates sales velocity (lower = sells faster)
- **Reorder = Y** with **Quantity = 0** means "we're out and customers want it"
- **Reorder Quantity** suggests historical demand level
- Some sizes sell faster than others (creates imbalance between orders)
- 10x10 is likely the most valuable/popular size (maximizing these from full sheets matters)

---

## Technical Notes

### Glass Signature Format
Used to match compatible glass for cutting:
```
[Color]|[Type]|[Thickness]

Example: "Aqua Blue|Transparent|3mm"
```

Only glass with identical signatures can be cut to fill each other's inventory.

### Cascade Calculation Examples

**5x10 → 5x5:**
- Need: 7 pieces of 5x5
- Each 5x10 makes: 2 pieces of 5x5
- Sheets needed: ⌈7 ÷ 2⌉ = 4 sheets

**10x10 → 5x5:**
- Need: 15 pieces of 5x5
- Each 10x10 makes: 4 pieces of 5x5
- Sheets needed: ⌈15 ÷ 4⌉ = 4 sheets

**Half Sheet → 5x5 (full cascade):**
- Need: 30 pieces of 5x5
- Each Half Sheet makes: 12 pieces of 5x5
- Sheets needed: ⌈30 ÷ 12⌉ = 3 sheets

---

*Document created: 2025-12-05*
*Last updated: 2025-12-05*
*For: ArtGlassSupplies.com Bullseye Glass Cutting Optimization*
