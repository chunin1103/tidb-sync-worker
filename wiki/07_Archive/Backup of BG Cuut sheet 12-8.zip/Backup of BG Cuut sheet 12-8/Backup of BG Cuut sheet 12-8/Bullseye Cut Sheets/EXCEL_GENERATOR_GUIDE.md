# Excel Work Order Generator Guide

**Version:** 1.0
**Date:** December 6-7, 2025
**Purpose:** Convert optimizer CSV output to warehouse-friendly Excel format

---

## Quick Start

### Run the Generator

```bash
python generate_work_order_excel.py
```

**Requirements:**
- `Balanced_Cutting_Instructions.csv` (from optimizer)
- `Bullseye Cut Sheet Sample File [DATE].csv` (inventory data)

**Output:**
- `Bullseye_Work_Order_[DATE].xlsx` (4-tab Excel file)

---

## What It Does

The Excel generator transforms mathematical cutting plans into warehouse-friendly work orders:

**Input:** Optimizer CSV with 30 cutting plans
**Output:** Excel file with 4 tabs (Picks, Steps, Barcode_Labels, Inventory_Deltas)

**Key Features:**
- Calculates exact Product_IDs and Vendor_SKUs for all pieces
- Handles cascade cutting (using produced pieces)
- Generates barcode labels only for pieces going back on shelf
- Tracks inventory changes for system updates

---

## Output Format

### Tab 1: Picks

**Purpose:** What worker pulls from warehouse

**Columns:**
- `Donor_Child_ID` - Product ID to pull
- `Donor_Vendor_SKU` - Vendor SKU (e.g., 2124-30.HS)
- `Donor_Name` - Full product name
- `Donor_Size` - Size (Half Sheet, 10×10, 5×10, 5×5)
- `Pick_Qty` - How many to pull

**Example:**
| Donor_Child_ID | Donor_Vendor_SKU | Donor_Name | Donor_Size | Pick_Qty |
|----------------|------------------|------------|------------|----------|
| 171316 | 2124-30.HS | Red Opal White Opal...Half Sheet | Half Sheet | 1 |

**Important:** Only shows pieces pulled from warehouse, NOT produced pieces.

---

### Tab 2: Steps

**Purpose:** Cutting instructions with final outcomes

**Columns:**
- `Parent_ID` - Parent product ID (color group)
- `Parent_Vendor_SKU` - Base vendor SKU
- `Donor_Child_ID` - Product ID being cut
- `Donor_Vendor_SKU` - Vendor SKU being cut
- `Donor_Name` - Full product name
- `Instruction` - Human-readable cutting instruction
- `Target` - Final pieces produced (net result)

**Example:**
| Parent_ID | Donor_Child_ID | Instruction | Target |
|-----------|----------------|-------------|---------|
| 171312 | 171316 | Cut 1 Half Sheet | (2) 10×10, (4) 5×5 |

**Target Format:** Lists only pieces with positive net change
- Format: `"(2) 10×10, (4) 5×10, (4) 5×5"`
- Omits sizes with net change = 0

**Example - Plan #18:**
- Cut 1 Half → produces 2×10×10 + 2×5×10
- Cut those 2×5×10 → produces 4×5×5
- **Target shows:** "(2) 10×10, (4) 5×5"
- **5×10 omitted:** Net = 0 (produced 2, cut 2)

---

### Tab 3: Barcode_Labels

**Purpose:** Labels to print for inventory going back on shelf

**Columns:**
- `Child_ID` - Product ID (encodes to Code 128 barcode)
- `Vendor_SKU` - Vendor SKU
- `Labels_to_Print` - How many labels to print
- `Product_Name` - Full product name

**Example:**
| Child_ID | Vendor_SKU | Labels_to_Print | Product_Name |
|----------|------------|-----------------|--------------|
| 171313 | 2124-30.10x10 | 2 | Red Opal...10×10 |
| 171315 | 2124-30.5x5 | 4 | Red Opal...5×5 |

**Barcode Format:** Code 128 encoding of Child_ID

**Important:**
- Only pieces with positive net inventory change
- Donor pieces already have labels (just count out)
- Each label represents one physical piece

---

### Tab 4: Inventory_Deltas

**Purpose:** System inventory updates (count in/out)

**Columns:**
- `Child_ID` - Product ID
- `Vendor_SKU` - Vendor SKU
- `Product_Name` - Full product name
- `Qty_before` - Quantity before cutting
- `Qty_after` - Quantity after cutting
- `Net_Change` - Change (+/-)

**Example:**
| Child_ID | Product_Name | Qty_before | Qty_after | Net_Change |
|----------|--------------|------------|-----------|------------|
| 171316 | ...Half Sheet | 3 | 2 | -1 |
| 171313 | ...10×10 | 2 | 4 | +2 |
| 171315 | ...5×5 | 0 | 4 | +4 |

**Important:** Only includes sizes with Net_Change ≠ 0

---

## How It Works

### 1. Load Data

Reads two input files:
- Cutting instructions CSV (30 plans from optimizer)
- Inventory CSV (1,540 products, 401 parents)

Maps products by Parent_ID and size to get Product_IDs and SKUs.

### 2. Process Each Plan

For each of the 30 cutting plans:

**Step 1:** Identify what to pick from warehouse
- Half Sheets if cutting Half Sheets
- 10×10s if cutting from inventory (no Half Sheets)
- 5×10s if cutting from inventory (no cascade)

**Step 2:** Calculate cascade cutting
- Track what's produced from each cut
- Use produced pieces for secondary cuts when possible
- Example: Cut Half → get 5×10s → cut those 5×10s (single trip)

**Step 3:** Calculate net inventory changes
- For each size: (produced) - (consumed) = net change
- Example Half cut: Half -1, 10×10 +2, 5×10 +2
- Example cascade: 5×10 +2-2=0, 5×5 +4

**Step 4:** Generate outputs
- Picks: What to pull
- Steps: Cutting instructions with targets
- Labels: Pieces going back on shelf (net > 0)
- Deltas: All changes (net ≠ 0)

---

## Cutting Patterns Reference

### Primary Cuts (20-inch direction first)

**Half Sheet (17×20):**
- Produces: 2×10×10 + 2×5×10
- Waste: Two 2×10 inch strips

**Full Sheet (32-37×20):**
- Produces: 6×10×10 + 2×5×10
- Waste: Minimal

### Secondary Cuts

**10×10:**
- Option 1: 2×5×10 (cut in half)
- Option 2: 4×5×5 (cut in quarters)
- Option 3: 1×5×10 + 2×5×5 (mixed)

**5×10:**
- Produces: 2×5×5 (cut in half)

**5×5:**
- Never cut (smallest retail size)

### Scrap Rule

Never leave waste bigger than smallest available size for that glass type.
- Varies by product (some don't have 5×5)
- Check inventory CSV for available sizes per parent

---

## Example Walkthroughs

### Example 1: Simple Cascade (Plan #18)

**Optimizer Says:**
- Cut 1 Half Sheet
- Cut 2×5×10 → 5×5

**Generator Calculates:**

**Picks Tab:**
- Pull 1 Half Sheet (171316)

**Steps Tab:**
- Donor: Half Sheet (171316)
- Instruction: "Cut 1 Half Sheet"
- Target: "(2) 10×10, (4) 5×5"
  - 5×10 omitted (net = 0)

**Barcode Labels:**
- 2 labels for 10×10 (171313)
- 4 labels for 5×5 (171315)
- No labels for 5×10 (net change = 0)

**Inventory Deltas:**
- Half: 3 → 2 (-1)
- 10×10: 2 → 4 (+2)
- 5×5: 0 → 4 (+4)
- 5×10 not shown (net = 0)

**Physical Process:**
1. Worker pulls 1 Half Sheet from bin
2. Cuts it → gets 2×10×10 + 2×5×10
3. Cuts those 2 fresh 5×10s → gets 4×5×5
4. Prints 2 labels for 10×10, 4 labels for 5×5
5. Returns to shelf: 2×10×10, 4×5×5
6. Updates system: -1 Half, +2 10×10, +4 5×5

**Single warehouse trip** ✓

---

### Example 2: Cutting from Inventory (Plan #20)

**Optimizer Says:**
- Cut 5×10×10 → 5×10

**Generator Calculates:**

**Picks Tab:**
- Pull 5×10×10 (16469)

**Steps Tab:**
- Donor: 10×10 (16469)
- Instruction: "Cut 5 10×10s"
- Target: "(10) 5×10"

**Barcode Labels:**
- 10 labels for 5×10 (16468)

**Inventory Deltas:**
- 10×10: 7 → 2 (-5)
- 5×10: 0 → 10 (+10)

**Physical Process:**
1. Worker pulls 5×10×10 from bin
2. Cuts each in half → gets 10×5×10
3. Prints 10 labels for 5×10
4. Returns to shelf: 10×5×10
5. Updates system: -5 10×10, +10 5×10

---

### Example 3: Large Operation (Plan #1)

**Optimizer Says:**
- Cut 13 Half Sheets
- Cut 3×5×10 → 5×5

**Generator Calculates:**

**Picks Tab:**
- Pull 13 Half Sheets (152090)

**Steps Tab:**
- Donor: Half Sheet (152090)
- Instruction: "Cut 13 Half Sheets"
- Target: "(26) 10×10, (23) 5×10, (6) 5×5"

**Calculation:**
- 13 Half → 26×10×10 + 26×5×10
- Cut 3 of those 5×10s → 6×5×5
- Net: 26×10×10, 23×5×10 (26-3), 6×5×5

**Barcode Labels:**
- 26 labels for 10×10
- 23 labels for 5×10
- 6 labels for 5×5
- **Total: 55 labels**

---

## Data Mapping

### Parent ID → Children

All products with same Parent_ID are the same color/type in different sizes.

**Example - Parent 171312 (Red Opal White Opal Streaky):**
| Child_ID | Vendor_SKU | Size | Qty |
|----------|------------|------|-----|
| 171316 | 2124-30.HS | Half | 3 |
| 171313 | 2124-30.10x10 | 10×10 | 2 |
| 171314 | 2124-30.5x10 | 5×10 | 4 |
| 171315 | 2124-30.5x5 | 5×5 | 0 |

**Vendor SKU Pattern:**
- Base: 2124 (color number)
- Suffix: -30 (3mm thickness)
- Size: .HS, .10x10, .5x10, .5x5

### Size Matching

Generator matches sizes by product name:
- "Half Sheet" → Half
- "10\"x10\"" or "10x10" → 10×10
- "5\"x10\"" or "5x10" → 5×10
- "5\"x5\"" or "5x5" → 5×5

---

## Output Statistics

**Typical Run (30 plans):**
- **Picks:** 30 rows (one per plan)
- **Steps:** 30 rows (one per plan)
- **Barcode Labels:** ~300-350 labels total
- **Inventory Deltas:** ~90-100 changes (3-4 per plan average)

**Plan #1 alone generates:**
- 55 barcode labels
- 4 inventory deltas (Half, 10×10, 5×10, 5×5)

---

## Troubleshooting

### No Output Generated

**Check:**
1. Cutting instructions CSV exists
2. Inventory CSV exists
3. Both files in same directory as script

### Missing Product Data

**Error:** "WARNING: No inventory found for Parent XXXXX"

**Causes:**
- Parent ID not in inventory CSV
- All children marked InActive
- No 3mm products for that parent

**Solution:** Check inventory CSV for that parent

### Wrong SKUs

**Check:**
- Vendor_SKU column in inventory CSV
- Product names contain size information
- Active status = "Active"

---

## Future Enhancements

### Planned (Not Yet Implemented)

1. **Simplification Detection**
   - Flag over-optimized plans
   - Suggest simpler alternatives
   - Example: "Cut 5 achieves 0.556, but cut 2 achieves 0.500"

2. **Complexity Scoring**
   - Assign points to each plan
   - Estimate: "Worker can complete 50 points per session"
   - Prioritize to maximize products addressed

3. **Alternative Plans**
   - Show: "Optimizer: Cut 3×10×10"
   - Suggest: "Alternative: Cut 1 Half + cascade 1×10×10 (preserves Half Sheets)"

4. **Completion Tracking**
   - Track actual completion rates
   - Adjust complexity scoring
   - Refine simplification rules

5. **Half Sheet Preservation**
   - Flag plans that consume last Half Sheet
   - Suggest alternatives when possible

---

## Version History

**v1.0 - December 7, 2025**
- Initial release
- 4-tab Excel output
- Handles all 30 optimizer plans
- Cascade cutting support
- Code 128 barcode labels

---

## Related Files

- `glass_cutting_optimizer_balanced.py` - Generates cutting instructions CSV
- `Balanced_Cutting_Instructions.csv` - Input (30 plans)
- `Bullseye Cut Sheet Sample File [DATE].csv` - Inventory data
- `OPTIMIZER_FIXES_2025-12-06.md` - Optimizer issue documentation
- `PHASE_2_LEARNINGS.md` - Business rules documentation

---

*For questions about the optimizer logic, see PHASE_2_LEARNINGS.md*
*For questions about this generator, see this file*
