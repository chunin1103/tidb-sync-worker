#!/usr/bin/env python3
"""
Bullseye Glass Cutting Optimizer
Analyzes inventory and generates cutting instructions to fill stock gaps
"""

import csv
import re
from dataclasses import dataclass
from typing import List, Dict, Tuple
from collections import defaultdict
import os

@dataclass
class GlassProduct:
    """Represents a glass product in inventory"""
    product_name: str
    product_id: str
    parent_id: str
    quantity: int
    reorder: str
    reorder_qty: float
    purchased: int  # Units sold in date range (typically 1 year)
    years_in_stock: float
    status: str  # Active or InActive

    # Parsed attributes
    color: str = ""
    glass_type: str = ""  # Transparent, Opalescent, Streaky, etc.
    thickness: str = ""   # 3mm or 2mm
    size: str = ""        # Half Sheet, 10x10, 5x10, 5x5

    def __post_init__(self):
        """Parse product name to extract glass properties"""
        self._parse_product_name()

    def _parse_product_name(self):
        """Extract glass properties from product name"""
        name = self.product_name

        # Extract size
        if "Half Sheet" in name:
            self.size = "Half Sheet"
        elif '10"x10"' in name or "10x10" in name:
            self.size = "10x10"
        elif '5"x10"' in name or "5x10" in name:
            self.size = "5x10"
        elif '5"x5"' in name or "5x5" in name:
            self.size = "5x5"
        else:
            self.size = "Unknown"

        # Extract thickness
        if "3mm" in name:
            self.thickness = "3mm"
        elif "2mm" in name:
            self.thickness = "2mm"

        # Extract glass type
        if "Opalescent" in name:
            self.glass_type = "Opalescent"
        elif "Transparent Tint" in name:
            self.glass_type = "Transparent Tint"
        elif "Transparent" in name:
            self.glass_type = "Transparent"
        elif "Streaky" in name:
            self.glass_type = "Streaky"

        # Extract color (everything before glass type and before thickness markers)
        # Remove "Bullseye Glass" prefix
        color_part = name.replace("Bullseye Glass ", "")

        # Find the position of thickness/type markers
        markers = [self.glass_type, "Double-rolled", "Thin-rolled", "Single-rolled",
                   "Rainbow Iridescent", "COE90"]

        for marker in markers:
            if marker and marker in color_part:
                color_part = color_part.split(marker)[0]
                break

        self.color = color_part.strip().rstrip(",")

    def get_glass_signature(self) -> str:
        """Get unique signature for matching glass types"""
        return f"{self.color}|{self.glass_type}|{self.thickness}"

    def needs_restock(self) -> bool:
        """Check if this product needs restocking"""
        return self.reorder == "Y" and self.quantity == 0


@dataclass
class CuttingStep:
    """Represents a single cutting step"""
    source_size: str
    target_sizes: Dict[str, int]  # size -> quantity
    description: str


@dataclass
class CuttingInstruction:
    """Represents a complete cutting instruction for staff"""
    parent_id: str  # For grouping compatible glass
    glass_signature: str

    # Cutting operations
    half_sheets_to_cut: int = 0
    ten_to_5x10: int = 0  # 10x10 -> 2x5x10
    ten_to_5x5: int = 0   # 10x10 -> 4x5x5
    five10_to_5x5: int = 0  # 5x10 -> 2x5x5

    # Before state (Years_in_Stock)
    before_half: float = 0.0
    before_10x10: float = 0.0
    before_5x10: float = 0.0
    before_5x5: float = 0.0

    # After state (Years_in_Stock)
    after_half: float = 0.0
    after_10x10: float = 0.0
    after_5x10: float = 0.0
    after_5x5: float = 0.0

    # Inventory quantities (for reference)
    before_qty: Dict[str, int] = None
    after_qty: Dict[str, int] = None

    # Balance metrics
    min_years_before: float = 0.0
    min_years_after: float = 0.0
    balance_improvement: float = 0.0

    # Product details (for display)
    product_names: Dict[str, str] = None  # size -> product name


class GlassCuttingOptimizer:
    """Optimizes glass cutting to fill inventory gaps"""

    # Primary Half Sheet cut (always the same)
    HALF_SHEET_PRIMARY = {
        "10x10": 2,
        "5x10": 2,
        "waste": "Two 2x10 strips"
    }

    # 10x10 cutting options
    TEN_BY_TEN_OPTIONS = [
        {"5x10": 2, "description": "10x10 → Two 5x10 pieces"},
        {"5x5": 4, "description": "10x10 → Four 5x5 pieces"},
        {"5x10": 1, "5x5": 2, "description": "10x10 → One 5x10 + Two 5x5 pieces"},
    ]

    # 5x10 cutting
    FIVE_BY_TEN_CUT = {
        "5x5": 2,
        "description": "5x10 → Two 5x5 pieces"
    }

    def __init__(self, csv_path: str, min_stock_threshold: int = 0):
        self.csv_path = csv_path
        self.min_stock_threshold = min_stock_threshold
        self.products: List[GlassProduct] = []
        self.glass_groups: Dict[str, List[GlassProduct]] = defaultdict(list)

    def load_inventory(self):
        """Load and parse inventory CSV"""
        print(f"Loading inventory from {self.csv_path}...")

        errors = []

        with open(self.csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)

            for row in reader:
                # Only process sheet glass (has size information)
                product_name = row['Product_Name']
                status = row['Products Status']
                quantity = int(row['Quantity_in_Stock'])

                # Check for data quality issues
                reorder = row['Reorder']

                # Error 1: InActive products should not have stock
                if status == "InActive" and quantity > 0:
                    errors.append(f"ERROR: InActive product has stock - {product_name} (ID: {row['Product_ID']}, Qty: {quantity})")

                # Error 2: Out of stock, not reordering, but still Active (should be InActive)
                if reorder == "N" and quantity == 0 and status == "Active":
                    errors.append(f"WARNING: Out of stock, Reorder=N, but still Active - {product_name} (ID: {row['Product_ID']})")

                if any(size in product_name for size in ['10"x10"', '5"x10"', '5"x5"', 'Half Sheet']):
                    # Only process 3mm glass for now
                    if "3mm" in product_name:
                        product = GlassProduct(
                            product_name=product_name,
                            product_id=row['Product_ID'],
                            parent_id=row['Products_Parent_Id'],
                            quantity=quantity,
                            reorder=row['Reorder'],
                            reorder_qty=float(row['Reorder_Quantity']),
                            purchased=int(row['Purchased']),
                            years_in_stock=float(row['Years_in_Stock']),
                            status=status
                        )

                        self.products.append(product)

                        # Group by parent ID (better than signature - exact glass match)
                        self.glass_groups[product.parent_id].append(product)

        # Report errors if found
        if errors:
            print(f"\n{'='*80}")
            print(f"DATA QUALITY ISSUES FOUND:")
            print(f"{'='*80}")
            for error in errors:
                print(f"  {error}")
            print(f"{'='*80}\n")

        print(f"Loaded {len(self.products)} sheet glass products")
        print(f"Found {len(self.glass_groups)} unique glass types (by Parent ID)")

    def analyze_cutting_opportunities(self) -> List[CuttingInstruction]:
        """Analyze inventory and find cutting opportunities using balanced optimization"""
        instructions = []

        print("\nAnalyzing cutting opportunities using BALANCED optimization...")
        print("Goal: Maximize minimum Years_in_Stock across all sizes\n")

        for parent_id, products in self.glass_groups.items():
            # Use balanced optimization for this glass type
            instruction = self._optimize_balanced_cutting(parent_id, products)
            if instruction:
                instructions.append(instruction)

        return instructions

    def _optimize_balanced_cutting(self, parent_id: str, products: List[GlassProduct]):
        """Try to cut 5x10 pieces into 5x5 pieces"""
        source_products = by_size.get("5x10", [])
        available = [p for p in source_products if p.quantity > 0]
        if not available:
            return None

        sheets_needed = (total_needed + 1) // 2  # Each 5x10 makes 2 5x5s
        total_available = sum(p.quantity for p in available)
        sheets_to_cut = min(sheets_needed, total_available)

        if sheets_to_cut > 0:
            steps = [CuttingStep("5x10", {"5x5": 2}, "5x10 → Two 5x5 pieces")]
            return CuttingInstruction(
                source_product=available[0].product_name,
                source_size="5x10",
                target_product=needs_restock[0].product_name,
                target_size="5x5",
                sheets_to_cut=sheets_to_cut,
                pieces_produced=sheets_to_cut * 2,
                glass_signature=signature,
                cutting_steps=steps,
                final_yield={"5x5": sheets_to_cut * 2},
                purchased=needs_restock[0].purchased,
                parent_id=needs_restock[0].parent_id
            )
        return None

    def _try_cut_10x10_to_5x5(self, by_size, needs_restock, total_needed, signature):
        """Try to cut 10x10 pieces into 5x5 pieces"""
        source_products = by_size.get("10x10", [])
        available = [p for p in source_products if p.quantity > 0]
        if not available:
            return None

        sheets_needed = (total_needed + 3) // 4  # Each 10x10 makes 4 5x5s
        total_available = sum(p.quantity for p in available)
        sheets_to_cut = min(sheets_needed, total_available)

        if sheets_to_cut > 0:
            steps = [CuttingStep("10x10", {"5x5": 4}, "10x10 → Four 5x5 pieces")]
            return CuttingInstruction(
                source_product=available[0].product_name,
                source_size="10x10",
                target_product=needs_restock[0].product_name,
                target_size="5x5",
                sheets_to_cut=sheets_to_cut,
                pieces_produced=sheets_to_cut * 4,
                glass_signature=signature,
                cutting_steps=steps,
                final_yield={"5x5": sheets_to_cut * 4},
                purchased=needs_restock[0].purchased,
                parent_id=needs_restock[0].parent_id
            )
        return None

    def _try_cut_half_sheet_to_5x5(self, by_size, needs_restock, total_needed, signature):
        """Try to cut Half Sheets into 5x5 pieces via cascade"""
        source_products = by_size.get("Half Sheet", [])
        available = [p for p in source_products if p.quantity > 0]
        if not available:
            return None

        # Half Sheet → 2×10x10 + 2×5x10, then all to 5x5 = (2×4) + (2×2) = 12 5x5s
        pieces_per_half = 12
        sheets_needed = (total_needed + pieces_per_half - 1) // pieces_per_half
        total_available = sum(p.quantity for p in available)
        sheets_to_cut = min(sheets_needed, total_available)

        if sheets_to_cut > 0:
            steps = [
                CuttingStep("Half Sheet", {"10x10": 2, "5x10": 2}, "Half Sheet (17x20) → Two 10x10 + Two 5x10 (waste: two 2x10 strips)"),
                CuttingStep("10x10", {"5x5": 4}, "Each 10x10 → Four 5x5 pieces (2 sheets = 8 pieces)"),
                CuttingStep("5x10", {"5x5": 2}, "Each 5x10 → Two 5x5 pieces (2 sheets = 4 pieces)")
            ]
            return CuttingInstruction(
                source_product=available[0].product_name,
                source_size="Half Sheet",
                target_product=needs_restock[0].product_name,
                target_size="5x5",
                sheets_to_cut=sheets_to_cut,
                pieces_produced=sheets_to_cut * 12,
                glass_signature=signature,
                cutting_steps=steps,
                final_yield={"5x5": sheets_to_cut * 12},
                purchased=needs_restock[0].purchased,
                parent_id=needs_restock[0].parent_id
            )
        return None

    def _try_cut_10x10_to_5x10(self, by_size, needs_restock, total_needed, signature):
        """Try to cut 10x10 pieces into 5x10 pieces"""
        source_products = by_size.get("10x10", [])
        available = [p for p in source_products if p.quantity > 0]
        if not available:
            return None

        sheets_needed = (total_needed + 1) // 2  # Each 10x10 makes 2 5x10s
        total_available = sum(p.quantity for p in available)
        sheets_to_cut = min(sheets_needed, total_available)

        if sheets_to_cut > 0:
            steps = [CuttingStep("10x10", {"5x10": 2}, "10x10 → Two 5x10 pieces")]
            return CuttingInstruction(
                source_product=available[0].product_name,
                source_size="10x10",
                target_product=needs_restock[0].product_name,
                target_size="5x10",
                sheets_to_cut=sheets_to_cut,
                pieces_produced=sheets_to_cut * 2,
                glass_signature=signature,
                cutting_steps=steps,
                final_yield={"5x10": sheets_to_cut * 2},
                purchased=needs_restock[0].purchased,
                parent_id=needs_restock[0].parent_id
            )
        return None

    def _try_cut_half_sheet_to_5x10(self, by_size, needs_restock, total_needed, signature):
        """Try to cut Half Sheets into 5x10 pieces via cascade"""
        source_products = by_size.get("Half Sheet", [])
        available = [p for p in source_products if p.quantity > 0]
        if not available:
            return None

        # Half Sheet → 2×10x10 + 2×5x10, then cut 10x10s = 2 + (2×2) = 6 5x10s
        pieces_per_half = 6
        sheets_needed = (total_needed + pieces_per_half - 1) // pieces_per_half
        total_available = sum(p.quantity for p in available)
        sheets_to_cut = min(sheets_needed, total_available)

        if sheets_to_cut > 0:
            steps = [
                CuttingStep("Half Sheet", {"10x10": 2, "5x10": 2}, "Half Sheet (17x20) → Two 10x10 + Two 5x10 (waste: two 2x10 strips)"),
                CuttingStep("10x10", {"5x10": 2}, "Each 10x10 → Two 5x10 pieces (2 sheets = 4 pieces)")
            ]
            return CuttingInstruction(
                source_product=available[0].product_name,
                source_size="Half Sheet",
                target_product=needs_restock[0].product_name,
                target_size="5x10",
                sheets_to_cut=sheets_to_cut,
                pieces_produced=sheets_to_cut * 6,
                glass_signature=signature,
                cutting_steps=steps,
                final_yield={"5x10": sheets_to_cut * 6},
                purchased=needs_restock[0].purchased,
                parent_id=needs_restock[0].parent_id
            )
        return None

    def _try_cut_half_sheet_to_10x10(self, by_size, needs_restock, total_needed, signature):
        """Try to cut Half Sheets into 10x10 pieces"""
        source_products = by_size.get("Half Sheet", [])
        available = [p for p in source_products if p.quantity > 0]
        if not available:
            return None

        # Half Sheet → 2×10x10 + 2×5x10 (keep only the 10x10s for this target)
        pieces_per_half = 2
        sheets_needed = (total_needed + pieces_per_half - 1) // pieces_per_half
        total_available = sum(p.quantity for p in available)
        sheets_to_cut = min(sheets_needed, total_available)

        if sheets_to_cut > 0:
            steps = [
                CuttingStep("Half Sheet", {"10x10": 2, "5x10": 2}, "Half Sheet (17x20) → Two 10x10 + Two 5x10 (waste: two 2x10 strips)")
            ]
            return CuttingInstruction(
                source_product=available[0].product_name,
                source_size="Half Sheet",
                target_product=needs_restock[0].product_name,
                target_size="10x10",
                sheets_to_cut=sheets_to_cut,
                pieces_produced=sheets_to_cut * 2,
                glass_signature=signature,
                cutting_steps=steps,
                final_yield={"10x10": sheets_to_cut * 2, "5x10": sheets_to_cut * 2},  # You also get 5x10s
                purchased=needs_restock[0].purchased,
                parent_id=needs_restock[0].parent_id
            )
        return None

    def _get_source_sizes(self, target_size: str) -> List[str]:
        """Get possible source sizes for a target size, in priority order"""
        if target_size == "5x5":
            return ["5x10", "10x10", "Half Sheet"]
        elif target_size == "5x10":
            return ["10x10", "Half Sheet"]
        elif target_size == "10x10":
            return ["Half Sheet"]
        return []

    def generate_cutting_report(self, instructions: List[CuttingInstruction], output_path: str):
        """Generate CSV report with cutting instructions"""
        print(f"\nGenerating cutting report to {output_path}...")

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            fieldnames = [
                'Priority',
                'Annual_Sales',
                'Glass_Type',
                'Source_Product',
                'Source_Size',
                'Sheets_to_Cut',
                'Target_Product',
                'Target_Size',
                'Target_Pieces_Produced',
                'Step_1',
                'Step_2',
                'Step_3',
                'Final_Yield'
            ]

            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            # Sort by Annual Sales (Purchased) - highest first, then by target size
            # PRIORITY LOGIC: Cut for best sellers first
            size_priority = {"5x5": 1, "5x10": 2, "10x10": 3}
            instructions.sort(key=lambda x: (-x.purchased, size_priority.get(x.target_size, 99)))

            for i, inst in enumerate(instructions, 1):
                # Format cutting steps
                step_1 = inst.cutting_steps[0].description if len(inst.cutting_steps) > 0 else ""
                step_2 = inst.cutting_steps[1].description if len(inst.cutting_steps) > 1 else ""
                step_3 = inst.cutting_steps[2].description if len(inst.cutting_steps) > 2 else ""

                # Format final yield
                yield_str = ", ".join([f"{count}× {size}" for size, count in inst.final_yield.items()])

                writer.writerow({
                    'Priority': i,
                    'Annual_Sales': inst.purchased,
                    'Glass_Type': inst.glass_signature.replace("|", " - "),
                    'Source_Product': inst.source_product,
                    'Source_Size': inst.source_size,
                    'Sheets_to_Cut': inst.sheets_to_cut,
                    'Target_Product': inst.target_product,
                    'Target_Size': inst.target_size,
                    'Target_Pieces_Produced': inst.pieces_produced,
                    'Step_1': step_1,
                    'Step_2': step_2,
                    'Step_3': step_3,
                    'Final_Yield': yield_str
                })

        print(f"Report generated with {len(instructions)} cutting instructions")

    def print_summary(self, instructions: List[CuttingInstruction]):
        """Print summary of cutting instructions"""
        if not instructions:
            print("\n✓ No cutting needed - inventory is well stocked!")
            return

        print(f"\n{'='*80}")
        print(f"CUTTING INSTRUCTIONS SUMMARY")
        print(f"{'='*80}")
        print(f"\nTotal cutting operations: {len(instructions)}")

        by_target = defaultdict(int)
        total_pieces = 0

        for inst in instructions:
            by_target[inst.target_size] += inst.pieces_produced
            total_pieces += inst.pieces_produced

        print(f"\nTotal pieces to produce: {total_pieces}")
        for size, count in sorted(by_target.items()):
            print(f"  - {size}: {count} pieces")

        print(f"\n{'='*80}\n")


def main():
    """Main execution function"""
    # Get the directory of this script
    script_dir = os.path.dirname(os.path.abspath(__file__))

    # Input and output paths
    input_csv = os.path.join(script_dir, "Bullseye Cut Sheet Sample File 12-4-25.csv")
    output_csv = os.path.join(script_dir, "Cutting_Instructions_Output.csv")

    # Check if input file exists
    if not os.path.exists(input_csv):
        print(f"Error: Input file not found: {input_csv}")
        print("Please ensure the CSV file is in the same directory as this script.")
        return

    # Create optimizer
    optimizer = GlassCuttingOptimizer(input_csv)

    # Load inventory
    optimizer.load_inventory()

    # Analyze cutting opportunities
    instructions = optimizer.analyze_cutting_opportunities()

    # Print summary
    optimizer.print_summary(instructions)

    # Generate report
    if instructions:
        optimizer.generate_cutting_report(instructions, output_csv)
        print(f"\n✓ Cutting instructions saved to: {output_csv}")

    print("\nDone!")


if __name__ == "__main__":
    main()
