# Parent ID Breakdown Verification - December 7, 2025

## Summary

**Total 3mm COE90 Sheet Glass Parents (Active products only): 401**

This matches exactly what the optimizer reports: "Found 401 unique glass types (by Parent ID)"

---

## Complete Breakdown

### 1. **Tier 1 - Zero Stock (CAN cut):** 44 parents
- Have at least one size at zero inventory (with purchases > 0)
- Have Half Sheets available
- Have 3+ sizes available
- **The optimizer generates plans for 30 of these 44 parents**
  - The 14 not included likely have minimal improvement from cutting
  - Optimizer only outputs plans where cutting provides meaningful benefit

### 2. **Tier 1 - Zero Stock (CANNOT cut):** 66 parents
- Have at least one size at zero inventory (with purchases > 0)
- BUT lack source material (no Half Sheets OR <3 sizes)
- **These need Bullseye reorders, not cutting**

### 3. **Tier 2 - Could Improve Balance:** 87 parents
- No zeros
- Minimum coverage < 0.25 years (91 days)
- Could benefit from cutting but not urgent
- **Optimizer skips these** (focuses on Priority 1: get off zero first)

### 4. **Tier 3 - Well Balanced:** 173 parents
- No zeros
- Minimum coverage >= 0.25 years
- **Don't need cutting right now**

### 5. **No Source Material:** 20 parents
- No zeros
- No Half Sheets OR <3 sizes available
- Can't cut even if we wanted to

### 6. **Partial Size Sets:** 11 parents
- Only have 1 size available
- Nothing to cut from

---

## Total: 401 Parents

**Distribution:**
- 44 + 66 = **110 parents with zeros** (27% of all parents)
  - 44 can be addressed by cutting (optimizer evaluates these)
  - 30 get cutting plans (optimizer filters for meaningful improvement)
  - 66 need Bullseye reorders instead
- 87 = **22% could improve balance** but don't have zeros
- 173 = **43% well balanced** (don't need attention)
- 31 = **8% can't be cut** (no source material or partial sets)

---

## Comparison to Original Statement

**I originally stated (before completing all 30 plan reviews):**
- 30 parents: Need cutting (Tier 1 - have zeros)
- 40 parents: Could cut but doesn't improve balance
- 271 parents: Well balanced (Tier 3 - no cutting needed)
- 53 parents: No source material to cut from
- 7 parents: Only have 1 size (can't cut)

**Corrected breakdown (after using 0.25 year threshold):**
- 30 parents: Get cutting plans (Tier 1 - optimizer output)
- 14 parents: Have zeros, could cut, but improvement too small
- 66 parents: Have zeros but can't cut (need reorders)
- 87 parents: Could improve balance (min < 0.25 years)
- 173 parents: Well balanced (min >= 0.25 years)
- 20 parents: No source material (no Half or <3 sizes, no zeros)
- 11 parents: Only have 1 size

**Why the change?**
1. Lowered threshold from 0.5 to 0.25 years based on 30-plan review
2. More accurate categorization of parents with zeros
3. Better understanding of optimizer filtering (44 parents evaluated, 30 get plans)

---

## Key Findings

### The 401 Parents Include:
- **409 total parent IDs** in the CSV (Active + InActive)
- **401 have Active products** (what optimizer counts)
- **8 have ONLY InActive products** (optimizer ignores)

### Optimizer Behavior:
- Evaluates all 401 Active parents
- Identifies 44 parents with zeros that have enough source material
- Generates plans for 30 of these (where cutting provides meaningful improvement)
- Skips 87 parents that could improve balance (Priority 1 focus on zeros)
- Skips 173 well-balanced parents

### Critical Need Categories:
1. **30 parents:** Getting cutting plans ✓ (addressed by this session)
2. **66 parents:** Need Bullseye reorders (have zeros, can't cut)
3. **87 parents:** Future cutting sessions (when zeros are cleared)

---

## Methodology

### Filtering Criteria (matching optimizer):
```python
# Must have size in product name
has_size = any(size in product_name for size in
               ['10"x10"', '5"x10"', '5"x5"', 'Half Sheet'])

# Must be 3mm
is_3mm = '3mm' in product_name

# Must be Active
status == 'Active'
```

### Categorization Logic:
1. **Single size only** → Partial size sets (can't cut)
2. **Has zero + can't cut** → Tier 1 cannot cut (need reorder)
3. **No Half or <3 sizes** → No source material
4. **Has zero + can cut** → Tier 1 can cut (optimizer evaluates)
5. **Min < 0.25 years** → Tier 2 could improve
6. **Min >= 0.25 years** → Tier 3 well balanced

---

**Verification Date:** December 7, 2025
**Source File:** Bullseye Cut Sheet Sample File 12-5-25.csv
**Optimizer Version:** v2.3 (with 0.25 year threshold)
**Status:** ✅ VERIFIED - 401 parents confirmed
