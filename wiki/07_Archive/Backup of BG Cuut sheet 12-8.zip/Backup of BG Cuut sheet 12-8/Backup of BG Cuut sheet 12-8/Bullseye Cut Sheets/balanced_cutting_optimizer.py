#!/usr/bin/env python3
"""
Optimized cutting strategy that balances Years_in_Stock across ALL sizes
Goal: Minimize risk of ANY size going out of stock
"""

# Current inventory for Parent 6018
current = {
    'Half': {'qty': 22, 'sales': 60},
    '10x10': {'qty': 0, 'sales': 105},
    '5x10': {'qty': 20, 'sales': 52},
    '5x5': {'qty': 7, 'sales': 23}
}

def years_in_stock(qty, sales):
    """Calculate years in stock"""
    return qty / sales if sales > 0 else 0

def print_state(state, label):
    """Print current state with years in stock"""
    print(f"\n{label}")
    print("=" * 100)
    for size in ['Half', '10x10', '5x10', '5x5']:
        qty = state[size]['qty']
        sales = state[size]['sales']
        years = years_in_stock(qty, sales)
        status = " [OUT]" if qty == 0 else ""
        print(f"{size:10} | Stock: {qty:3} | Sales: {sales:3} | Years: {years:.3f}{status}")

    # Calculate stats
    years_list = [years_in_stock(state[s]['qty'], state[s]['sales']) for s in ['Half', '10x10', '5x10', '5x5']]
    min_years = min(years_list)
    max_years = max(years_list)
    avg_years = sum(years_list) / len(years_list)
    std_dev = (sum((y - avg_years)**2 for y in years_list) / len(years_list)) ** 0.5

    print(f"\nBalance: Min={min_years:.3f} | Max={max_years:.3f} | Avg={avg_years:.3f} | StdDev={std_dev:.3f}")
    print(f"Range: {max_years - min_years:.3f} (lower is more balanced)")

    return min_years, max_years, std_dev

print("CURRENT STATE:")
print_state(current, "Before Any Cutting")

print("\n" + "=" * 100)
print("GOAL: Find cutting strategy that BALANCES all sizes")
print("=" * 100)
print("\nStrategy: Maximize the MINIMUM Years_in_Stock across all sizes")
print("This ensures no size is at high risk of going out of stock\n")

# Search for optimal cutting strategy
best_solution = None
best_min_years = 0

print("Searching for optimal balance...")

for half_to_cut in range(0, 23):  # Can cut 0-22 half sheets
    initial_10x10 = half_to_cut * 2
    initial_5x10_from_half = half_to_cut * 2

    # Try cutting some 10x10s to 2x5x10
    for ten_to_5x10 in range(0, initial_10x10 + 1):
        remaining_10x10 = initial_10x10 - ten_to_5x10
        added_5x10_from_10 = ten_to_5x10 * 2

        # Try cutting some 10x10s to 4x5x5
        for ten_to_5x5 in range(0, remaining_10x10 + 1):
            final_10x10 = remaining_10x10 - ten_to_5x5
            added_5x5_from_10 = ten_to_5x5 * 4

            # Calculate total 5x10 available
            total_5x10 = current['5x10']['qty'] + initial_5x10_from_half + added_5x10_from_10

            # Try cutting some 5x10s to 2x5x5
            for five10_to_cut in range(0, total_5x10 + 1):
                final_5x10 = total_5x10 - five10_to_cut
                added_5x5_from_5x10 = five10_to_cut * 2

                # Calculate final state
                state = {
                    'Half': {'qty': current['Half']['qty'] - half_to_cut, 'sales': current['Half']['sales']},
                    '10x10': {'qty': final_10x10, 'sales': current['10x10']['sales']},
                    '5x10': {'qty': final_5x10, 'sales': current['5x10']['sales']},
                    '5x5': {'qty': current['5x5']['qty'] + added_5x5_from_10 + added_5x5_from_5x10, 'sales': current['5x5']['sales']}
                }

                # Skip if any negative
                if any(state[s]['qty'] < 0 for s in ['Half', '10x10', '5x10', '5x5']):
                    continue

                # Skip if nothing changed
                if half_to_cut == 0 and ten_to_5x10 == 0 and ten_to_5x5 == 0 and five10_to_cut == 0:
                    continue

                # Calculate balance metrics
                years_list = [years_in_stock(state[s]['qty'], state[s]['sales']) for s in ['Half', '10x10', '5x10', '5x5']]
                min_years = min(years_list)
                max_years = max(years_list)
                range_years = max_years - min_years

                # Goal: Maximize minimum years (safety first!)
                # Secondary: Minimize range (balance)
                # Weighted score
                score = min_years - (range_years * 0.05)

                if best_solution is None or score > (best_min_years - (best_solution['range'] * 0.05)):
                    best_min_years = min_years
                    best_solution = {
                        'half_cut': half_to_cut,
                        '10x10_to_5x10': ten_to_5x10,
                        '10x10_to_5x5': ten_to_5x5,
                        '5x10_to_5x5': five10_to_cut,
                        'state': state.copy(),
                        'min': min_years,
                        'max': max_years,
                        'range': range_years
                    }

if best_solution:
    print("\n" + "=" * 100)
    print("OPTIMAL BALANCED CUTTING STRATEGY:")
    print("=" * 100)

    print(f"\n1. Cut {best_solution['half_cut']} Half Sheets")
    print(f"   -> Produces: {best_solution['half_cut'] * 2} x 10x10 + {best_solution['half_cut'] * 2} x 5x10")

    if best_solution['10x10_to_5x10'] > 0:
        print(f"\n2. Cut {best_solution['10x10_to_5x10']} x 10x10 -> {best_solution['10x10_to_5x10'] * 2} x 5x10")

    if best_solution['10x10_to_5x5'] > 0:
        print(f"\n3. Cut {best_solution['10x10_to_5x5']} x 10x10 -> {best_solution['10x10_to_5x5'] * 4} x 5x5")

    if best_solution['5x10_to_5x5'] > 0:
        print(f"\n4. Cut {best_solution['5x10_to_5x5']} x 5x10 -> {best_solution['5x10_to_5x5'] * 2} x 5x5")

    min_y, max_y, std = print_state(best_solution['state'], "\nFINAL BALANCED STATE:")

    print("\n" + "=" * 100)
    print("WHY THIS IS OPTIMAL:")
    print("=" * 100)
    print(f"- Minimum Years_in_Stock: {best_solution['min']:.3f} (highest possible)")
    print(f"- All sizes have similar Years_in_Stock (range: {best_solution['range']:.3f})")
    print(f"- NO sizes are out of stock")
    print(f"- Risk of running out is BALANCED across all sizes")
    print(f"- Good for weekly cutting cycles")

print("\n" + "=" * 100)
print("KEY INSIGHT:")
print("=" * 100)
print("Targeting EQUAL Years_in_Stock across sizes minimizes overall risk!")
print("Don't optimize for one size - optimize for BALANCE across all sizes!")
