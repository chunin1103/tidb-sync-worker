#!/usr/bin/env python3
"""
Bullseye Glass Cut Sheet Generator
Generates Excel workbook with multiple tabs for warehouse operations

Input: Bullseye inventory CSV
Output: Excel file with tabs:
  - Summary (overview and top priorities)
  - Picks (items to pull from warehouse)
  - Steps (cutting instructions)
  - Barcode_Labels (labels for cut pieces)
  - Inventory_Deltas (all inventory changes)
  - Reorder_List (items needing Bullseye reorder)
"""

import csv
from collections import defaultdict
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

# Configuration
csv_file = r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye Cut Sheet Sample File 12-5-25.csv"
TARGET_DAYS = 91  # 0.25 years minimum stock coverage

# Data structures
parents = defaultdict(lambda: {
    'Half': {'qty': 0, 'purchased': 0, 'product_id': '', 'vendor_sku': '', 'product_name': ''},
    '10x10': {'qty': 0, 'purchased': 0, 'product_id': '', 'vendor_sku': '', 'product_name': ''},
    '5x10': {'qty': 0, 'purchased': 0, 'product_id': '', 'vendor_sku': '', 'product_name': ''},
    '5x5': {'qty': 0, 'purchased': 0, 'product_id': '', 'vendor_sku': '', 'product_name': ''},
    'name': ''
})

# Load data
print("Loading inventory data...")
with open(csv_file, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        product_name = row.get('Product_Name', '')
        status = row.get('Products Status', '')
        has_size = any(size in product_name for size in ['10"x10"', '5"x10"', '5"x5"', 'Half Sheet'])
        is_3mm = '3mm' in product_name
        if not (has_size and is_3mm and status == 'Active'):
            continue
        parent_id = row.get('Products_Parent_Id', '').strip()
        if not parent_id:
            continue

        qty = int(float(row.get('Quantity_in_Stock', 0) or 0))
        purchased = int(float(row.get('Purchased', 0) or 0))
        product_id = row.get('Product_ID', '')
        vendor_sku = row.get('Vendor SKU', '')

        # Set parent name (without size suffix)
        if not parents[parent_id]['name']:
            name = product_name
            for suffix in [' Half Sheet', ' 10"x10"', ' 5"x10"', ' 5"x5"', ' 3mm']:
                name = name.replace(suffix, '')
            parents[parent_id]['name'] = name

        # Determine size and store data
        size = None
        if 'Half Sheet' in product_name:
            size = 'Half'
        elif '10"x10"' in product_name:
            size = '10x10'
        elif '5"x10"' in product_name:
            size = '5x10'
        elif '5"x5"' in product_name:
            size = '5x5'

        if size:
            parents[parent_id][size]['qty'] += qty
            parents[parent_id][size]['purchased'] += purchased
            # Keep the product details (use first one found)
            if not parents[parent_id][size]['product_id']:
                parents[parent_id][size]['product_id'] = product_id
                parents[parent_id][size]['vendor_sku'] = vendor_sku
                parents[parent_id][size]['product_name'] = product_name

print(f"  Loaded {len(parents)} parent products")


def get_days(qty, sales):
    """Calculate days of stock coverage"""
    if sales == 0:
        return 9999
    return int((qty / sales) * 365)


def get_years_days(qty, sales):
    """Return formatted years and days string"""
    if sales == 0:
        return "∞"
    days = int((qty / sales) * 365)
    years = days // 365
    remaining_days = days % 365
    if years > 0:
        return f"{years}y {remaining_days}d"
    return f"{days}d"


def generate_cut_instructions(data):
    """Generate cutting instructions and track individual cuts"""
    sizes = ['Half', '10x10', '5x10', '5x5']

    qty = {s: data[s]['qty'] for s in sizes}
    sales = {s: data[s]['purchased'] for s in sizes}

    # Track individual cut operations
    cuts = {
        'half_sheets': 0,      # Number of Half Sheets to cut
        '10x10_to_5x10': 0,    # Number of 10x10 to cut into 5x10
        '10x10_to_5x5': 0,     # Number of 10x10 to cut into 5x5
        '5x10_to_5x5': 0       # Number of 5x10 to cut into 5x5
    }

    instructions = []
    max_iterations = 20
    iteration = 0

    # Step 1: Cut Half Sheets
    while qty['Half'] > 0 and iteration < max_iterations:
        iteration += 1
        needs_cut = False

        for s in ['10x10', '5x10']:
            if sales[s] > 0 and get_days(qty[s], sales[s]) < TARGET_DAYS:
                needs_cut = True
                break

        if not needs_cut:
            break

        qty['Half'] -= 1
        qty['10x10'] += 2
        qty['5x10'] += 2
        cuts['half_sheets'] += 1
        instructions.append('Cut 1 Half -> 2x10x10 + 2x5x10')

    # Step 2: Cut 10x10 to 5x10 if needed
    iteration = 0
    while qty['10x10'] > 0 and sales['5x10'] > 0 and iteration < max_iterations:
        iteration += 1
        days_10x10 = get_days(qty['10x10'], sales['10x10']) if sales['10x10'] > 0 else 9999
        days_5x10 = get_days(qty['5x10'], sales['5x10'])

        if days_5x10 >= TARGET_DAYS:
            break
        if days_10x10 < TARGET_DAYS + 50:
            break

        qty['10x10'] -= 1
        qty['5x10'] += 2
        cuts['10x10_to_5x10'] += 1
        instructions.append('Cut 1x10x10 -> 2x5x10')

    # Step 3: Cut to 5x5 if needed
    iteration = 0
    while sales['5x5'] > 0 and get_days(qty['5x5'], sales['5x5']) < TARGET_DAYS and iteration < max_iterations:
        iteration += 1
        days_5x10 = get_days(qty['5x10'], sales['5x10']) if sales['5x10'] > 0 else 9999
        days_10x10 = get_days(qty['10x10'], sales['10x10']) if sales['10x10'] > 0 else 9999

        if qty['5x10'] > 0 and days_5x10 > TARGET_DAYS + 50:
            qty['5x10'] -= 1
            qty['5x5'] += 2
            cuts['5x10_to_5x5'] += 1
            instructions.append('Cut 1x5x10 -> 2x5x5')
        elif qty['10x10'] > 0 and days_10x10 > TARGET_DAYS + 50:
            qty['10x10'] -= 1
            qty['5x5'] += 4
            cuts['10x10_to_5x5'] += 1
            instructions.append('Cut 1x10x10 -> 4x5x5')
        else:
            break

    return instructions, qty, cuts


def consolidate_instructions(instructions):
    """Consolidate repeated instructions into counts"""
    instr_count = {}
    for instr in instructions:
        instr_count[instr] = instr_count.get(instr, 0) + 1
    consolidated = []
    for instr, count in instr_count.items():
        if count > 1:
            consolidated.append(f"{instr} x{count}")
        else:
            consolidated.append(instr)
    return ' | '.join(consolidated)


# Process all parents
print("Analyzing cutting opportunities...")
cut_sheet = []
reorder_list = []

for parent_id, data in parents.items():
    sizes = ['Half', '10x10', '5x10', '5x5']
    existing_sizes = sum(1 for s in sizes if data[s]['qty'] > 0 or data[s]['purchased'] > 0)
    total_sales = sum(data[s]['purchased'] for s in sizes)

    if total_sales == 0:
        continue
    if existing_sizes <= 1:
        continue

    has_zero = any(data[s]['qty'] == 0 and data[s]['purchased'] > 0 for s in sizes)
    has_low = any(data[s]['purchased'] > 0 and get_days(data[s]['qty'], data[s]['purchased']) < TARGET_DAYS for s in sizes)

    if not has_zero and not has_low:
        continue

    has_half = data['Half']['qty'] > 0
    has_10x10 = data['10x10']['qty'] > 0
    has_5x10 = data['5x10']['qty'] > 0

    # Check if we have any cutting source
    if has_half or has_10x10 or has_5x10:
        instructions, new_qty, cuts = generate_cut_instructions(data)

        if instructions:
            cut_sheet.append({
                'parent_id': parent_id,
                'name': data['name'],
                'total_sales': total_sales,
                'instructions': instructions,
                'cuts': cuts,
                'before': {s: data[s]['qty'] for s in sizes},
                'after': new_qty,
                'sales': {s: data[s]['purchased'] for s in sizes},
                'data': data  # Keep full data for product details
            })
        elif has_zero:
            zero_sizes = [s for s in sizes if data[s]['qty'] == 0 and data[s]['purchased'] > 0]
            reorder_list.append({
                'parent_id': parent_id,
                'name': data['name'],
                'total_sales': total_sales,
                'zero_sizes': zero_sizes,
                'data': data
            })
    else:
        zero_sizes = [s for s in sizes if data[s]['qty'] == 0 and data[s]['purchased'] > 0]
        if zero_sizes:
            reorder_list.append({
                'parent_id': parent_id,
                'name': data['name'],
                'total_sales': total_sales,
                'zero_sizes': zero_sizes,
                'data': data
            })

# Sort by total sales
cut_sheet.sort(key=lambda x: -x['total_sales'])
reorder_list.sort(key=lambda x: -x['total_sales'])

print(f"  Found {len(cut_sheet)} items with cutting instructions")
print(f"  Found {len(reorder_list)} items needing reorder")


# Generate Excel workbook
print("\nGenerating Excel workbook...")
wb = Workbook()

# Styles
header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
header_font = Font(bold=True, color='FFFFFF')
header_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
thin_border = Border(
    left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin')
)


def format_header(ws):
    """Format header row"""
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = header_align
        cell.border = thin_border


def auto_width(ws):
    """Auto-size columns"""
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 60)
        ws.column_dimensions[column_letter].width = adjusted_width


# Remove default sheet
if 'Sheet' in wb.sheetnames:
    wb.remove(wb['Sheet'])


# TAB 1: Summary
ws_summary = wb.create_sheet('Summary')
ws_summary.append(['BULLSEYE GLASS CUT SHEET'])
ws_summary['A1'].font = Font(bold=True, size=16)
ws_summary.append([f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}'])
ws_summary.append([])
ws_summary.append(['Statistics'])
ws_summary.append(['Items with cutting instructions:', len(cut_sheet)])
ws_summary.append(['Items needing Bullseye reorder:', len(reorder_list)])
ws_summary.append(['Target stock coverage:', f'{TARGET_DAYS} days (0.25 years)'])
ws_summary.append([])
ws_summary.append(['TOP 20 CUTTING PRIORITIES'])
ws_summary.append(['Priority', 'Parent_ID', 'Glass Type', 'Sales/yr', 'Cut Instructions'])

for i, item in enumerate(cut_sheet[:20], 1):
    ws_summary.append([
        i,
        item['parent_id'],
        item['name'][:55],
        item['total_sales'],
        consolidate_instructions(item['instructions'])
    ])

# Format summary
for row in ws_summary.iter_rows(min_row=10, max_row=10):
    for cell in row:
        cell.fill = header_fill
        cell.font = header_font
auto_width(ws_summary)


# TAB 2: Picks (items to pull from warehouse)
ws_picks = wb.create_sheet('Picks')
ws_picks.append(['Priority', 'Parent_ID', 'Donor_Child_ID', 'Donor_Vendor_SKU', 'Donor_Name', 'Donor_Size', 'Pick_Qty'])

for i, item in enumerate(cut_sheet, 1):
    data = item['data']
    cuts = item['cuts']

    # Half Sheets to pick
    if cuts['half_sheets'] > 0:
        half_data = data['Half']
        ws_picks.append([
            i,
            item['parent_id'],
            half_data['product_id'],
            half_data['vendor_sku'],
            half_data['product_name'][:55],
            'Half Sheet',
            cuts['half_sheets']
        ])

    # 10x10 to pick (when not cutting from Half)
    if cuts['half_sheets'] == 0 and (cuts['10x10_to_5x10'] > 0 or cuts['10x10_to_5x5'] > 0):
        ten_data = data['10x10']
        total_10 = cuts['10x10_to_5x10'] + cuts['10x10_to_5x5']
        ws_picks.append([
            i,
            item['parent_id'],
            ten_data['product_id'],
            ten_data['vendor_sku'],
            ten_data['product_name'][:55],
            '10x10',
            total_10
        ])

    # 5x10 to pick (when not cutting from Half or 10x10)
    if cuts['half_sheets'] == 0 and cuts['5x10_to_5x5'] > 0:
        five_data = data['5x10']
        ws_picks.append([
            i,
            item['parent_id'],
            five_data['product_id'],
            five_data['vendor_sku'],
            five_data['product_name'][:55],
            '5x10',
            cuts['5x10_to_5x5']
        ])

format_header(ws_picks)
auto_width(ws_picks)


# TAB 3: Steps (cutting instructions with targets)
ws_steps = wb.create_sheet('Steps')
ws_steps.append(['Priority', 'Parent_ID', 'Donor_Vendor_SKU', 'Donor_Name', 'Instruction', 'Target_Output'])

for i, item in enumerate(cut_sheet, 1):
    data = item['data']
    cuts = item['cuts']
    before = item['before']
    after = item['after']

    # Calculate net production for target output
    produced = {
        '10x10': after['10x10'] - before['10x10'],
        '5x10': after['5x10'] - before['5x10'],
        '5x5': after['5x5'] - before['5x5']
    }

    # Build target string
    targets = []
    if produced['10x10'] > 0:
        targets.append(f"({produced['10x10']}) 10x10")
    if produced['5x10'] > 0:
        targets.append(f"({produced['5x10']}) 5x10")
    if produced['5x5'] > 0:
        targets.append(f"({produced['5x5']}) 5x5")
    target_str = ", ".join(targets) if targets else "None"

    # Get donor info
    if cuts['half_sheets'] > 0:
        donor = data['Half']
        instr = f"Cut {cuts['half_sheets']} Half Sheet{'s' if cuts['half_sheets'] > 1 else ''}"
    elif cuts['10x10_to_5x10'] > 0 or cuts['10x10_to_5x5'] > 0:
        donor = data['10x10']
        total = cuts['10x10_to_5x10'] + cuts['10x10_to_5x5']
        instr = f"Cut {total} 10x10{'s' if total > 1 else ''}"
    else:
        donor = data['5x10']
        instr = f"Cut {cuts['5x10_to_5x5']} 5x10{'s' if cuts['5x10_to_5x5'] > 1 else ''}"

    ws_steps.append([
        i,
        item['parent_id'],
        donor['vendor_sku'],
        donor['product_name'][:55],
        instr,
        target_str
    ])

format_header(ws_steps)
auto_width(ws_steps)


# TAB 4: Barcode_Labels (labels for cut pieces)
ws_labels = wb.create_sheet('Barcode_Labels')
ws_labels.append(['Priority', 'Parent_ID', 'Child_ID', 'Vendor_SKU', 'Product_Name', 'Labels_to_Print'])

for i, item in enumerate(cut_sheet, 1):
    data = item['data']
    before = item['before']
    after = item['after']

    # Calculate net production for each size
    for size in ['10x10', '5x10', '5x5']:
        produced = after[size] - before[size]
        if produced > 0:
            size_data = data[size]
            ws_labels.append([
                i,
                item['parent_id'],
                size_data['product_id'],
                size_data['vendor_sku'],
                size_data['product_name'][:55],
                produced
            ])

format_header(ws_labels)
auto_width(ws_labels)


# TAB 5: Inventory_Deltas (all inventory changes)
ws_deltas = wb.create_sheet('Inventory_Deltas')
ws_deltas.append(['Priority', 'Parent_ID', 'Child_ID', 'Vendor_SKU', 'Product_Name', 'Qty_Before', 'Qty_After', 'Net_Change'])

for i, item in enumerate(cut_sheet, 1):
    data = item['data']
    before = item['before']
    after = item['after']

    for size in ['Half', '10x10', '5x10', '5x5']:
        net_change = after[size] - before[size]
        if net_change != 0:
            size_data = data[size]
            ws_deltas.append([
                i,
                item['parent_id'],
                size_data['product_id'],
                size_data['vendor_sku'],
                size_data['product_name'][:55],
                before[size],
                after[size],
                net_change
            ])

format_header(ws_deltas)
auto_width(ws_deltas)


# TAB 6: Reorder_List (items needing Bullseye reorder)
ws_reorder = wb.create_sheet('Reorder_List')
ws_reorder.append([
    'Priority', 'Parent_ID', 'Glass_Type', 'Total_Sales', 'Zero_Sizes',
    'Half_Qty', 'Half_Sales', 'Half_Coverage',
    '10x10_Qty', '10x10_Sales', '10x10_Coverage',
    '5x10_Qty', '5x10_Sales', '5x10_Coverage',
    '5x5_Qty', '5x5_Sales', '5x5_Coverage'
])

for i, item in enumerate(reorder_list, 1):
    d = item['data']
    ws_reorder.append([
        i,
        item['parent_id'],
        item['name'][:55],
        item['total_sales'],
        ', '.join(item['zero_sizes']),
        d['Half']['qty'], d['Half']['purchased'], get_years_days(d['Half']['qty'], d['Half']['purchased']),
        d['10x10']['qty'], d['10x10']['purchased'], get_years_days(d['10x10']['qty'], d['10x10']['purchased']),
        d['5x10']['qty'], d['5x10']['purchased'], get_years_days(d['5x10']['qty'], d['5x10']['purchased']),
        d['5x5']['qty'], d['5x5']['purchased'], get_years_days(d['5x5']['qty'], d['5x5']['purchased'])
    ])

format_header(ws_reorder)
auto_width(ws_reorder)


# TAB 7: Full Cut Sheet (detailed view)
ws_full = wb.create_sheet('Full_Cut_Sheet')
ws_full.append([
    'Priority', 'Parent_ID', 'Glass_Type', 'Total_Sales', 'Cut_Instructions',
    'Half_Before', 'Half_After', 'Half_Sales',
    '10x10_Before', '10x10_After', '10x10_Sales',
    '5x10_Before', '5x10_After', '5x10_Sales',
    '5x5_Before', '5x5_After', '5x5_Sales'
])

for i, item in enumerate(cut_sheet, 1):
    ws_full.append([
        i,
        item['parent_id'],
        item['name'][:55],
        item['total_sales'],
        consolidate_instructions(item['instructions']),
        item['before']['Half'], item['after']['Half'], item['sales']['Half'],
        item['before']['10x10'], item['after']['10x10'], item['sales']['10x10'],
        item['before']['5x10'], item['after']['5x10'], item['sales']['5x10'],
        item['before']['5x5'], item['after']['5x5'], item['sales']['5x5']
    ])

format_header(ws_full)
auto_width(ws_full)


# Save workbook
date_str = datetime.now().strftime("%Y-%m-%d")
output_file = rf"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye_Cut_Sheet_{date_str}.xlsx"
wb.save(output_file)

print(f"\n{'='*60}")
print("CUT SHEET GENERATED")
print(f"{'='*60}")
print(f"Items with cutting instructions: {len(cut_sheet)}")
print(f"Items needing reorder: {len(reorder_list)}")
print()
print(f"Output file: {output_file}")
print()
print("Tabs created:")
print("  1. Summary - Overview and top 20 priorities")
print("  2. Picks - Items to pull from warehouse")
print("  3. Steps - Cutting instructions with targets")
print("  4. Barcode_Labels - Labels for cut pieces")
print("  5. Inventory_Deltas - All inventory changes")
print("  6. Reorder_List - Items needing Bullseye reorder")
print("  7. Full_Cut_Sheet - Detailed before/after view")
print()
print("TOP 10 CUTTING PRIORITIES:")
print()
for i, item in enumerate(cut_sheet[:10], 1):
    print(f"{i}. {item['name'][:45]}")
    print(f"   Parent: {item['parent_id']} | Sales: {item['total_sales']}/yr")
    print(f"   {consolidate_instructions(item['instructions'][:50])}")
    print()
