import csv
import re

# Read the main inventory file
with open('Bullseye Cut Sheet Sample File 12-5-25.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    rows = list(reader)

# Get cutting candidate IDs
cutting_ids = set()
with open('101_Cutting_Candidates.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        cutting_ids.add(row['Parent_ID'])

# Group by parent ID
parents = {}
for row in rows:
    parent_id = row.get('Products_Parent_Id', '0')
    if parent_id and parent_id != '0':
        if parent_id not in parents:
            parents[parent_id] = []
        parents[parent_id].append(row)

# Check remaining parents for size types
size_pattern_half = re.compile(r'Half Sheet|1/2 Sheet', re.IGNORECASE)
size_pattern_10x10 = re.compile(r'10\s*[xX]\s*10|10x10', re.IGNORECASE)
size_pattern_5x10 = re.compile(r'5\s*[xX]\s*10|5x10', re.IGNORECASE)
size_pattern_5x5 = re.compile(r'5\s*[xX]\s*5|5x5', re.IGNORECASE)

cuttable_parents = []
for parent_id, children in parents.items():
    if parent_id in cutting_ids:
        continue

    has_half = False
    has_10x10 = False
    has_5x10 = False
    has_5x5 = False

    for child in children:
        name = child.get('Product_Name', '')
        if size_pattern_half.search(name):
            has_half = True
        if size_pattern_10x10.search(name):
            has_10x10 = True
        if size_pattern_5x10.search(name):
            has_5x10 = True
        if size_pattern_5x5.search(name):
            has_5x5 = True

    # Count how many sizes they have
    size_count = sum([has_half, has_10x10, has_5x10, has_5x5])
    if size_count >= 3:  # At least 3 of our 4 sizes
        cuttable_parents.append((parent_id, has_half, has_10x10, has_5x10, has_5x5, size_count))

print(f'Total parents with children: {len(parents)}')
print(f'Already in cutting candidates: {len(cutting_ids)}')
print(f'Parents with 3+ sizes (potentially cuttable): {len(cuttable_parents)}')
print(f'Parents with fewer sizes (not cuttable): {len(parents) - len(cutting_ids) - len(cuttable_parents)}')
