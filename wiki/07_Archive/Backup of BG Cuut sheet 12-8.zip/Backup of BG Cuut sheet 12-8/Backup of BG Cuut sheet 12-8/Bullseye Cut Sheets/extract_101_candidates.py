import csv
from collections import defaultdict

csv_file = r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye Cut Sheet Sample File 12-5-25.csv"

parents = defaultdict(lambda: {
    'Half': {'id': None, 'qty': 0, 'purchased': 0},
    '10x10': {'id': None, 'qty': 0, 'purchased': 0},
    '5x10': {'id': None, 'qty': 0, 'purchased': 0},
    '5x5': {'id': None, 'qty': 0, 'purchased': 0},
    'name': ''
})

with open(csv_file, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)

    for row in reader:
        product_name = row.get('Product_Name', '')
        status = row.get('Products Status', '')

        has_size = any(size in product_name for size in ['10"x10"', '5"x10"', '5"x5"', 'Half Sheet'])
        is_3mm = '3mm' in product_name

        if not (has_size and is_3mm and status == 'Active'):
            continue

        parent_id = row.get('Products_Parent_Id', '').strip()
        if not parent_id:
            continue

        qty = int(float(row.get('Quantity_in_Stock', 0)))
        purchased = int(float(row.get('Purchased', 0)))

        if not parents[parent_id]['name']:
            parents[parent_id]['name'] = product_name

        size = None
        if 'Half Sheet' in product_name:
            size = 'Half'
        elif '10"x10"' in product_name or '10x10' in product_name:
            size = '10x10'
        elif '5"x10"' in product_name or '5x10' in product_name:
            size = '5x10'
        elif '5"x5"' in product_name or '5x5' in product_name:
            size = '5x5'

        if size:
            parents[parent_id][size]['qty'] += qty
            parents[parent_id][size]['purchased'] += purchased
            if not parents[parent_id][size]['id']:
                parents[parent_id][size]['id'] = row.get('Product_ID', '')

# Load the 30 parents that got cutting plans
cutting_plans = set()
with open(r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Balanced_Cutting_Instructions.csv", 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        cutting_plans.add(row['Parent_ID'])

# Categorize
tier1_zeros_can_cut = []
tier1_zeros_skipped = []
tier2_could_improve = []

for parent_id, data in parents.items():
    sizes = ['Half', '10x10', '5x10', '5x5']

    # FIX: Count sizes that EXIST (have stock OR sales), not just sizes with stock
    existing_size_count = sum(1 for s in sizes if data[s]['qty'] > 0 or data[s]['purchased'] > 0)

    # Skip if can't cut: need Half Sheets AND 3+ existing sizes
    if existing_size_count < 3 or data['Half']['qty'] == 0:
        continue

    has_zero = any(data[s]['qty'] == 0 and data[s]['purchased'] > 0 for s in sizes)

    if has_zero:
        if parent_id in cutting_plans:
            tier1_zeros_can_cut.append(parent_id)
        else:
            tier1_zeros_skipped.append(parent_id)
        continue

    years = {}
    for s in sizes:
        if data[s]['purchased'] > 0:
            years[s] = data[s]['qty'] / data[s]['purchased']

    if years:
        min_years = min(years.values())

        if min_years < 0.25:
            tier2_could_improve.append(parent_id)

print(f"30 parents with cutting plans: {len(tier1_zeros_can_cut)}")
print(f"14 parents with zeros (skipped by optimizer): {len(tier1_zeros_skipped)}")
print(f"87 parents could improve balance: {len(tier2_could_improve)}")
print(f"Total cutting candidates to review: {len(tier1_zeros_skipped) + len(tier2_could_improve)}")
print("")

# Sort tier1_zeros_skipped by total purchased (descending)
tier1_data = []
for pid in tier1_zeros_skipped:
    total_purch = sum(parents[pid][s]['purchased'] for s in ['Half', '10x10', '5x10', '5x5'])
    tier1_data.append((pid, total_purch))
tier1_data.sort(key=lambda x: -x[1])

# Sort tier2 by min_years (ascending)
tier2_data = []
for pid in tier2_could_improve:
    years = {}
    for s in ['Half', '10x10', '5x10', '5x5']:
        if parents[pid][s]['purchased'] > 0:
            years[s] = parents[pid][s]['qty'] / parents[pid][s]['purchased']
    if years:
        min_years = min(years.values())
        total_purch = sum(parents[pid][s]['purchased'] for s in ['Half', '10x10', '5x10', '5x5'])
        tier2_data.append((pid, min_years, total_purch))
tier2_data.sort(key=lambda x: (x[1], -x[2]))

# Write to CSV for review
with open(r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\101_Cutting_Candidates.csv", 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['Priority', 'Tier', 'Parent_ID', 'Glass_Type', 'Total_Purchased',
                     'Half_Qty', 'Half_Purchased', 'Half_Years',
                     '10x10_Qty', '10x10_Purchased', '10x10_Years',
                     '5x10_Qty', '5x10_Purchased', '5x10_Years',
                     '5x5_Qty', '5x5_Purchased', '5x5_Years',
                     'Min_Years', 'Has_Zero'])

    priority = 1

    # Tier 1: Zeros skipped
    for pid, total_purch in tier1_data:
        data = parents[pid]
        name = data['name'].replace(' Half Sheet', '').replace(' 10"x10"', '').replace(' 5"x10"', '').replace(' 5"x5"', '')

        years_calc = {}
        for s in ['Half', '10x10', '5x10', '5x5']:
            if data[s]['purchased'] > 0:
                years_calc[s] = data[s]['qty'] / data[s]['purchased']
            else:
                years_calc[s] = 999

        min_years = min(y for y in years_calc.values() if y < 999)

        writer.writerow([
            priority,
            '1-Zero Stock (Skipped)',
            pid,
            name,
            total_purch,
            data['Half']['qty'], data['Half']['purchased'], f"{years_calc['Half']:.3f}",
            data['10x10']['qty'], data['10x10']['purchased'], f"{years_calc['10x10']:.3f}",
            data['5x10']['qty'], data['5x10']['purchased'], f"{years_calc['5x10']:.3f}",
            data['5x5']['qty'], data['5x5']['purchased'], f"{years_calc['5x5']:.3f}",
            f"{min_years:.3f}",
            'Yes'
        ])
        priority += 1

    # Tier 2: Could improve
    for pid, min_years, total_purch in tier2_data:
        data = parents[pid]
        name = data['name'].replace(' Half Sheet', '').replace(' 10"x10"', '').replace(' 5"x10"', '').replace(' 5"x5"', '')

        years_calc = {}
        for s in ['Half', '10x10', '5x10', '5x5']:
            if data[s]['purchased'] > 0:
                years_calc[s] = data[s]['qty'] / data[s]['purchased']
            else:
                years_calc[s] = 999

        writer.writerow([
            priority,
            '2-Could Improve',
            pid,
            name,
            total_purch,
            data['Half']['qty'], data['Half']['purchased'], f"{years_calc['Half']:.3f}",
            data['10x10']['qty'], data['10x10']['purchased'], f"{years_calc['10x10']:.3f}",
            data['5x10']['qty'], data['5x10']['purchased'], f"{years_calc['5x10']:.3f}",
            data['5x5']['qty'], data['5x5']['purchased'], f"{years_calc['5x5']:.3f}",
            f"{min_years:.3f}",
            'No'
        ])
        priority += 1

print("Created: 101_Cutting_Candidates.csv")
print("")
print("TIER BREAKDOWN:")
print(f"  Tier 1 (Zeros Skipped): {len(tier1_data)} parents")
print(f"  Tier 2 (Could Improve): {len(tier2_data)} parents")
