import csv
from collections import defaultdict

csv_file = r"C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye Cut Sheet Sample File 12-5-25.csv"

parents = defaultdict(lambda: {
    'Half': {'qty': 0, 'purchased': 0},
    '10x10': {'qty': 0, 'purchased': 0},
    '5x10': {'qty': 0, 'purchased': 0},
    '5x5': {'qty': 0, 'purchased': 0},
    'name': ''
})

with open(csv_file, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        product_name = row.get('Product_Name', '')
        status = row.get('Products Status', '')
        has_size = any(size in product_name for size in ['10"x10"', '5"x10"', '5"x5"', 'Half Sheet'])
        is_3mm = '3mm' in product_name
        if not (has_size and is_3mm and status == 'Active'):
            continue
        parent_id = row.get('Products_Parent_Id', '').strip()
        if not parent_id:
            continue
        qty = int(float(row.get('Quantity_in_Stock', 0) or 0))
        purchased = int(float(row.get('Purchased', 0) or 0))
        if not parents[parent_id]['name']:
            name = product_name
            for suffix in [' Half Sheet', ' 10"x10"', ' 5"x10"', ' 5"x5"', ' 3mm']:
                name = name.replace(suffix, '')
            parents[parent_id]['name'] = name
        size = None
        if 'Half Sheet' in product_name:
            size = 'Half'
        elif '10"x10"' in product_name:
            size = '10x10'
        elif '5"x10"' in product_name:
            size = '5x10'
        elif '5"x5"' in product_name:
            size = '5x5'
        if size:
            parents[parent_id][size]['qty'] += qty
            parents[parent_id][size]['purchased'] += purchased

cutting_ids = set()
with open('101_Cutting_Candidates.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        cutting_ids.add(row['Parent_ID'])

partial_sets = []
for parent_id, data in parents.items():
    if parent_id in cutting_ids:
        continue
    sizes = ['Half', '10x10', '5x10', '5x5']
    existing_sizes = sum(1 for s in sizes if data[s]['qty'] > 0 or data[s]['purchased'] > 0)

    # Partial = only 1 size exists
    if existing_sizes <= 1:
        size_data = {}
        which_size = None
        for s in sizes:
            if data[s]['qty'] > 0 or data[s]['purchased'] > 0:
                years = data[s]['qty'] / data[s]['purchased'] if data[s]['purchased'] > 0 else 999
                days = int(years * 365) if years < 999 else 999
                size_data[s] = {'qty': data[s]['qty'], 'purchased': data[s]['purchased'], 'years': years, 'days': days}
                which_size = s

        partial_sets.append({
            'parent_id': parent_id,
            'name': data['name'],
            'sizes': size_data,
            'which_size': which_size,
            'existing_sizes': existing_sizes
        })

print(f"PARTIAL SIZE SETS: {len(partial_sets)} parents")
print("=" * 70)
print()

for i, item in enumerate(partial_sets, 1):
    print(f"## #{i}: {item['name']}")
    print(f"**Parent ID:** {item['parent_id']}")
    print(f"**Why Partial:** Only {item['existing_sizes']} size exists ({item['which_size']})")
    print()
    print("| Size | Qty | Sales/yr | Years (Days) |")
    print("|------|-----|----------|--------------|")
    for size in ['Half', '10x10', '5x10', '5x5']:
        if size in item['sizes']:
            s = item['sizes'][size]
            if s['days'] < 999:
                years_days_str = f"{s['years']:.3f} ({s['days']} days)"
            else:
                years_days_str = "N/A (no sales)"
            print(f"| {size} | {s['qty']} | {s['purchased']} | {years_days_str} |")
    print()
    print("-" * 70)
    print()
