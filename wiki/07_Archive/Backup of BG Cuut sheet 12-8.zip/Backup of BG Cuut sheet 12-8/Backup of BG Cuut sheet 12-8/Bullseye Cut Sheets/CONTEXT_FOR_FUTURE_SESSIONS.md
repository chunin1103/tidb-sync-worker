# Context for Future AI Sessions

**Last Updated:** December 6-7, 2025
**Optimizer Version:** v2.2 (Cascade fixes + Good enough threshold)
**Excel Generator Version:** v1.0 (Complete)
**Status:** Production Ready

---

## Quick Start for New AI Sessions

If you're an AI assistant helping with this glass cutting optimizer in a future session, read this file first to understand the current state and context.

---

## What This Project Does

This is a **biweekly glass cutting optimizer** for ArtGlassSupplies.com that helps warehouse staff decide which Bullseye glass sheets to cut to maintain optimal inventory levels across 4 sizes: Half Sheet, 10x10, 5x10, and 5x5.

**Input:** CSV export with ~1,540 products (401 parent IDs)
**Output:** Prioritized cutting instructions for ~30 glass types that need attention

---

## Current State (v2.1)

### Optimizer Performance
- ✅ All 30 cutting plans validated
- ✅ All 5 Phase 2 rules working correctly
- ✅ Handles edge cases properly
- ✅ Ready for production use

### Files Structure

**Production Tools:**
- `glass_cutting_optimizer_balanced.py` - Main optimizer v2.2 (USE THIS)
- `generate_work_order_excel.py` - Excel generator v1.0 (NEW!)
- `Bullseye Cut Sheet Sample File 12-5-25.csv` - Latest inventory data
- `Balanced_Cutting_Instructions.csv` - Optimizer output (30 plans)
- `Bullseye_Work_Order_[DATE].xlsx` - Excel output (4 tabs)

**Documentation (READ THESE FIRST):**
- `CONTEXT_FOR_FUTURE_SESSIONS.md` - This file (overview)
- `README.md` - User-facing quick reference
- `EXCEL_GENERATOR_GUIDE.md` - Excel generator documentation (NEW!)
- `PHASE_2_LEARNINGS.md` - Complete rule documentation with examples
- `SESSION_SUMMARY_2025-12-05_EVENING.md` - Phase 2 validation session
- `SESSION_SUMMARY_2025-12-06.md` - Cascade fixes & Excel generator session (NEW!)
- `OPTIMIZER_FIXES_2025-12-06.md` - v2.2 optimizer fixes documentation (NEW!)
- `GLASS_CUTTING_KNOWLEDGE.md` - Technical reference

**Development/Research:**
- `analyze_cutting_balance.py` - Research tool
- `balanced_cutting_optimizer.py` - Prototype
- `glass_cutting_optimizer_old.py` - Original (backup)
- `find_well_stocked.py` - Analysis utility

---

## Critical Business Context

### Three Explicit Priorities (ORDERED)

All cutting decisions are evaluated against these priorities in order:

1. **Get products off zero** (Priority 1: Prevent stockouts → Revenue loss)
2. **Optimize balance** (Priority 2: Minimize range between min/max years → Risk management)
3. **Minimize labor** (Priority 3: Simple operations → Labor is limiting factor)

Priority 1 trumps Priority 2, which trumps Priority 3.

### Operational Cycle

- **Frequency:** Biweekly (NOT weekly)
- **Completion:** Cut sheets often incomplete due to limited labor
- **Philosophy:** Iterative adjustment based on real demand, not perfect mathematical balance
- **Bullseye Orders:** Available regularly for reordering

---

## The Five Phase 2 Rules

### Rule #1: Minimize Warehouse Trips - Cascade Cutting
**Prefer:** Cut Half Sheets, then cut those fresh 5x10s
**Avoid:** Cut Half Sheets, then go pull more 5x10s from warehouse
**Impact:** Single-trip operations, reduced labor time

### Rule #2: Getting Off Zero > Perfect Safety Margins
**Accept:** Low but non-zero inventory (e.g., 0.059 years)
**Reject:** Hard safety thresholds that reject valid plans
**Impact:** Biweekly cycles allow corrections, stockout costs more than low inventory

### Rule #3: Byproduct Accumulation is Acceptable
**Accept:** 5x10s pile up when cutting Half Sheets for 10x10s
**Understand:** Half Sheet cuts ALWAYS produce 5x10 byproducts
**Solution:** Run overstock sales when needed
**Impact:** Focus on primary goal, don't over-optimize away from it

### Rule #4: Don't Sacrifice Popular Sizes for Less Popular Ones ⭐
**Protect:** Don't cut popular 10x10s to make less popular 5x5s
**Allow Cutting If:**
1. Target is more popular than source, OR
2. Source has excessive stock (>1 year), OR
3. No other option (all Half Sheets exhausted)

**Impact:** Protects revenue from bestselling sizes, simpler plans

### Rule #5: Priority-Based Half Sheet Overstock Decisions ⭐
**When:** Half Sheets extremely overstocked (>3 years)
**Framework:** Apply three priorities to choose between cutting 1, 2, or 3 Half Sheets
**Decision:** If cutting 1 vs 2 = same labor → choose better balance
**Philosophy:** Half Sheets most acceptable to overstock (can't be created), BUT address extreme overstock opportunistically

---

## Common Patterns Observed

**Sales Profiles:**
- Half Sheet: 1-3/year (very low demand)
- 10x10: Often bestseller (30-60/year typical)
- 5x10: Medium demand (15-30/year)
- 5x5: Low to medium (10-20/year)

**Inventory Issues:**
- Half Sheet overstock: ~40% of plans (low demand)
- 10x10 out of stock: ~30% of plans (high demand)
- Multiple sizes at zero: ~20% of plans (critical situations)

**Cutting Operations:**
- Single-trip plans: ~90%
- Cascade cutting: ~25%
- 10x10 cuts allowed: ~10% (all justified by Rule #4)

---

## Edge Cases Validated

### Partial Size Sets
Some glass types only have 3 sizes (e.g., Plan #24 - no 5x5 size exists)
**Status:** Optimizer handles correctly ✓

### Multiple Stockouts
Some plans have 2-3 sizes out of stock simultaneously
**Examples:** Plans #12, #14, #25, #29
**Status:** All handled correctly ✓

### Extreme Overstock
Some glass types have 5-8 years of inventory on slow-selling sizes
**Examples:** Plan #21 (8.000 years of 5x5), Plan #27 (7.000 years)
**Status:** Identified as overstock sale candidates ✓

### When 10x10 Cutting is Appropriate
**Plan #20:** 10x10 at 3.500 years, targets more popular → ALLOWED ✓
**Plan #24:** 10x10 at 1.300 years (>1 year threshold) → ALLOWED ✓
**Plan #30:** 10x10 at 2.000 years, targets equally popular → ALLOWED ✓
**Plan #5:** 10x10 bestseller (57/year), <1 year → BLOCKED ✓

---

## User Preferences & Working Style

### Communication Style
- User wants **honest, critical analysis** - not just agreement
- "I always want the best recommendation to get to the best outcomes"
- "You can ask questions and challenge me"
- "Let's make a great tool, do not worry about my feelings"

### Decision-Making Approach
- Prioritizes **practical outcomes** over mathematical perfection
- Values **simplicity** (fewer operations > perfect balance)
- Thinks **iteratively** (adjust biweekly based on actual sales)
- Accepts **acceptable imperfection** (0.200 years acceptable if gets off zero)

### Technical Comfort
- Comfortable with CSV data analysis
- Understands inventory metrics (years in stock, sales velocity)
- Makes informed tradeoff decisions (balance vs labor vs risk)
- Engaged in optimizer logic development

---

## How to Help in Future Sessions

### If User Asks to Review Plans:
1. Read `Balanced_Cutting_Instructions.csv` for current plans
2. Read `Bullseye Cut Sheet Sample File [DATE].csv` for inventory data
3. Reference `PHASE_2_LEARNINGS.md` for rule explanations
4. Apply the three priorities framework to any decisions
5. Challenge assumptions and ask critical questions

### If User Needs Excel Output:
1. Run `python generate_work_order_excel.py`
2. Check output: `Bullseye_Work_Order_[DATE].xlsx`
3. Verify 4 tabs: Picks, Steps, Barcode_Labels, Inventory_Deltas
4. Reference `EXCEL_GENERATOR_GUIDE.md` for format details

### If User Reports Issues:
1. **Optimizer issues:** Check version (v2.2 expected), see `OPTIMIZER_FIXES_2025-12-06.md`
2. **Excel issues:** Check `EXCEL_GENERATOR_GUIDE.md` troubleshooting section
3. Verify input CSV format matches expected structure
4. Review edge case handling in `PHASE_2_LEARNINGS.md`
5. Check if issue violates any of the 5 rules
6. Document any new edge cases discovered

### If User Wants Enhancements:
1. Read `PHASE_2_LEARNINGS.md` → "Future Enhancements" section
2. Read `EXCEL_GENERATOR_GUIDE.md` → "Future Enhancements" section
3. Ensure enhancement aligns with three priorities
4. Consider **throughput over perfection** (maximize products addressed per labor-hour)
5. Test against existing 30 plans to ensure no regressions
6. Document new rules/patterns discovered

---

## Key Files to Reference

**For understanding business logic:**
→ `PHASE_2_LEARNINGS.md` (COMPLETE RULE DOCUMENTATION)

**For understanding recent sessions:**
→ `SESSION_SUMMARY_2025-12-06.md` (CASCADE FIXES & EXCEL GENERATOR)
→ `SESSION_SUMMARY_2025-12-05_EVENING.md` (PHASE 2 VALIDATION)

**For optimizer technical details:**
→ `OPTIMIZER_FIXES_2025-12-06.md` (v2.2 FIXES DOCUMENTATION)
→ `GLASS_CUTTING_KNOWLEDGE.md` (TECHNICAL SPECS)

**For Excel generator:**
→ `EXCEL_GENERATOR_GUIDE.md` (COMPLETE EXCEL OUTPUT GUIDE)

**For user-facing explanations:**
→ `README.md` (QUICK REFERENCE)

**For current output:**
→ `Balanced_Cutting_Instructions.csv` (OPTIMIZER CSV - 30 PLANS)
→ `Bullseye_Work_Order_[DATE].xlsx` (EXCEL OUTPUT - 4 TABS)

---

## Known Limitations & Future Work

### Current Limitations
- Manual CSV export/import process
- No automated overstock sale flagging
- No explicit cascade operation display in output
- No warning flags for concerning situations (<0.10 years after cutting)
- No alternative plan suggestions

### Planned Enhancements (Phase 3)
1. Explicit cascade display in CSV output
2. Warning flags for low inventory situations
3. Alternative plan suggestions
4. Cost/time estimates per plan
5. Automated overstock sale candidate list

### Not Planned (Explicitly Rejected)
- ❌ Hard safety thresholds (rejected in Phase 2)
- ❌ Pure revenue-weighted optimization (too complex)
- ❌ Never cut 10x10s rule (context matters)

---

## Success Metrics

**Optimizer is working well if:**
- ✓ Zero stockouts addressed (Priority 1)
- ✓ Most plans single-trip operations (Priority 3)
- ✓ Bestsellers protected from unnecessary cutting (Rule #4)
- ✓ Plans completed by warehouse staff (practical)
- ✓ Balance maintained across sizes (Priority 2)

**Red flags to watch for:**
- ⚠️ Cutting popular sizes to fill unpopular ones
- ⚠️ Multiple warehouse trips for single glass type
- ⚠️ Rejecting valid plans due to low (but non-zero) inventory
- ⚠️ Complex cascade operations for marginal gains
- ⚠️ Plans not getting completed due to complexity

---

## Version History Summary

### Optimizer Versions:
**v2.2 (Current - Dec 6, 2025):** Cascade cutting fixes, good enough threshold (0.5 years), same-bin simplicity recognition
**v2.1 (Dec 5, 2025):** Phase 2 complete, all 30 plans validated, 5 rules working, production ready
**v2.0 (Dec 5, 2025):** Phase 2 initial implementation, 4 rules, tested with plans 1-7
**v1.0 (Dec 5, 2025):** Basic balanced optimizer, no business rules

### Excel Generator Versions:
**v1.0 (Dec 7, 2025):** Initial release, 4-tab Excel output, cascade cutting support, Code 128 barcodes

---

## Final Notes

This optimizer embodies the principle: **Business rules > Pure math**

The goal is not perfect mathematical optimization, but **practical, executable cutting plans** that warehouse staff can complete within labor constraints while minimizing stockout risk.

The three priorities framework and five Phase 2 rules ensure the optimizer makes decisions that align with real business needs, not just theoretical optimization.

---

*If you're reading this in a future session and have questions, refer to the specific documentation files listed above. All rules are explained with examples and business justifications.*

**Last Sessions:**
- **December 6-7, 2025:** Optimizer updated to v2.2, Excel generator v1.0 created and tested
- **December 5, 2025 (Evening):** All 30 plans validated, 5 Phase 2 rules confirmed working
- **December 5, 2025:** Optimizer v2.1 with Phase 2 business rules

**Current Tools Ready for Use:**
- ✅ Optimizer v2.2 (`glass_cutting_optimizer_balanced.py`)
- ✅ Excel Generator v1.0 (`generate_work_order_excel.py`)
- ✅ Complete documentation suite
- ✅ Production ready
