# 109 Cutting Candidates - Complete Review

**Created:** December 7, 2025
**Status:** Ready for batch review

---

## Overview

We have completed review of **30 of 401 parents** (Priority 1 - Zero Stock with cutting plans).

**Remaining cutting candidates: 109 parents**

### Breakdown:

**Tier 1 - Zero Stock (Skipped by Optimizer): 22 parents**
- Have at least one size at zero inventory
- Have source material (Half Sheets + 3+ sizes)
- Optimizer skipped them (cutting provides minimal improvement)
- **Question: Why were these skipped? Should we cut anyway?**

**Tier 2 - Could Improve Balance: 87 parents**
- No zeros
- Minimum coverage < 0.25 years (91 days)
- Could benefit from cutting to improve balance
- Optimizer skipped (Priority 1 focus on zeros first)
- **Question: Should we cut these now or wait?**

---

## Tier 1 - Zero Stock (Skipped) - 22 Parents

These have zeros but the optimizer didn't generate cutting plans for them.

### Top 10 by Total Purchased/Year:

| Priority | Parent_ID | Glass Type | Total Purch/yr | Min Years | Why Zero? |
|----------|-----------|------------|----------------|-----------|-----------|
| 1 | 388 | White Opalescent | 92 | 0.000 | 10×10 at ZERO |
| 2 | 16381 | Marigold Yellow Transparent | 71 | 0.000 | 5×10 at ZERO |
| 3 | 6972 | White Orange Opal Streaky | 42 | 0.000 | 5×10 at ZERO |
| 4 | 146032 | Light Aquamarine Blue Transparent Iridescent | 36 | 0.000 | 10×10 at ZERO |
| 5 | 16441 | Soft Yellow Opal Deep Red Streaky | 35 | 0.000 | 5×10 at ZERO |
| 6 | 158750 | Emerald Green Transparent Iridescent | 30 | 0.000 | Half & 10×10 at ZERO |
| 7 | 6010 | Charcoal Gray White Streaky | 26 | 0.000 | Half & 5×10 at ZERO |
| 8 | 156043 | Erbium Pink Transparent Tint | 25 | 0.000 | Half & 5×10 at ZERO |
| 9 | 16331 | Umber Opalescent | 25 | 0.000 | 5×10 at ZERO |
| 10 | 153140 | Alchemy Clear Transparent Silver to Gold | 23 | 0.000 | Half & 5×10 at ZERO |

### Common Pattern - Why Optimizer Skipped:

Looking at **Parent_ID 388 (White Opalescent)** as example:
- Half Sheet: 1 (9/yr) = 0.111 years
- 10×10: **0** (54/yr) = **ZERO**
- 5×10: 34 (21/yr) = 1.619 years
- 5×5: 14 (8/yr) = 1.750 years

**Issue:** No Half Sheets available (only 1) OR Half Sheets have zero purchases
- Many show "Half_Purchased = 0" or very low purchases
- Cutting 1 Half Sheet won't meaningfully improve the zero

**Hypothesis:** Optimizer skips when:
1. Very limited Half Sheet source material (≤2 pieces)
2. Cutting 1-2 Half won't bring zero size above 0.25 year threshold
3. Better to flag for Bullseye reorder instead

---

## Tier 2 - Could Improve Balance - 87 Parents

These have min < 0.25 years but no zeros. Optimizer skipped them to focus on Priority 1.

### Top 20 by Lowest Min_Years:

| Priority | Parent_ID | Glass Type | Total Purch/yr | Min Years | Which Size? |
|----------|-----------|------------|----------------|-----------|-------------|
| 23 | 445 | Red Opalescent | 169 | 0.010 | 10×10 (1 pc, 102/yr) |
| 24 | 6968 | Clear Egyptian Blue Opal Streaky | 72 | 0.025 | 10×10 (1 pc, 40/yr) |
| 25 | 6822 | Reactive Cloud Opalescent | 51 | 0.027 | 10×10 (1 pc, 37/yr) |
| 26 | 8304 | Canary Yellow Opalescent | 115 | 0.040 | 5×5 (1 pc, 25/yr) |
| 27 | 172007 | Peacock Blue Transparent Iridescent | 34 | 0.043 | 10×10 (1 pc, 23/yr) |
| 28 | 827 | Aventurine Green Transparent | 107 | 0.056 | 5×10 (2 pc, 36/yr) |
| 29 | 401 | Turquoise Blue Opalescent | 96 | 0.056 | Half (1 pc, 18/yr) |
| 30 | 15044 | Tan Transparent | 35 | 0.056 | Half (3 pc, **0/yr**) |
| 31 | 166670 | Light Green White Opal Streaky | 50 | 0.061 | 10×10 (2 pc, 33/yr) |
| 32 | 457 | Spring Green Opalescent | 102 | 0.065 | 5×10 (2 pc, 31/yr) |
| 33 | 169757 | Copper Blue White Opal | 44 | 0.071 | 10×10 (2 pc, 28/yr) |
| 34 | 9699 | Clear Black Opal Streaky | 42 | 0.074 | 10×10 (2 pc, 27/yr) |
| 35 | 16451 | Olive Green Opal Forest Green Deep Brown Streaky | 30 | 0.077 | 5×10 (1 pc, 13/yr) |
| 36 | 163659 | Light Bronze Transparent Gold Iridescent | 26 | 0.077 | 10×10 (1 pc, 13/yr) |
| 37 | 161099 | Lily Pad Green Transparent | 25 | 0.077 | 10×10 (1 pc, 13/yr) |
| 38 | 160903 | Blue Opal Plum Streaky | 48 | 0.080 | 10×10 (2 pc, 25/yr) |
| 39 | 470 | French Vanilla Opalescent | 176 | 0.083 | 10×10 (9 pc, 109/yr) |
| 40 | 163624 | Glacier Blue Opalescent | 97 | 0.086 | 10×10 (5 pc, 58/yr) |
| 41 | 168538 | White Aventurine Green Streaky | 44 | 0.094 | 10×10 (3 pc, 32/yr) |
| 42 | 9104 | Deep Royal Purple Transparent | 75 | 0.100 | 10×10 (4 pc, 40/yr) |

### Common Pattern:

**Critical Issue: 10×10 size extremely low!**
- 18 of top 20 have 10×10 as the minimum
- Many have only 1-2 pieces of 10×10 with high demand
- Examples:
  - Parent 445: 1 pc, 102/yr = 0.010 years = **4 DAYS**
  - Parent 6968: 1 pc, 40/yr = 0.025 years = **9 DAYS**
  - Parent 6822: 1 pc, 37/yr = 0.027 years = **10 DAYS**

**Why Optimizer Skipped:**
- Priority 1 (zeros) comes first
- These are technically "stocked" (not at zero)
- But coverage is VERY low (< 30 days)

**Should We Cut These?**
- Yes! Many are critically low on 10×10
- Cutting Half → 10×10 would dramatically improve coverage
- Could prevent future stockouts

---

## Key Questions for Review

### For Tier 1 (22 Skipped with Zeros):

1. **Should we cut anyway despite optimizer skipping?**
   - Many have very limited source material (1-2 Half Sheets)
   - Would cutting 1-2 Half really help?
   - Or better to flag for Bullseye reorder?

2. **Why did optimizer skip these?**
   - Minimal improvement from cutting available source
   - Need to order more from Bullseye first
   - Then cut on next session

### For Tier 2 (87 Could Improve):

1. **Should we cut these NOW?**
   - Many have critically low 10×10 coverage (< 30 days)
   - Priority says "zeros first" but these are nearly zero
   - Risk of stockout before next cutting session

2. **Which ones are highest priority?**
   - Focus on min < 0.10 years (36 days)
   - Focus on high demand (total_purchased > 50/yr)
   - Combination of both

3. **Labor throughput consideration:**
   - We have 109 candidates
   - Could we cut top 20-30 from Tier 2 in this session?
   - Or save for next session after Tier 1 reorders arrive?

---

## Recommendations for Batch Review

### Option A: Review All 109 in Detail
- Go through each one like we did for the 30 plans
- Ask: "Should we cut this? Why or why not?"
- Time: ~2-4 hours

### Option B: Set Filtering Criteria
- Define rules: When to cut Tier 1 skipped vs reorder
- Define rules: Which Tier 2 to cut now vs later
- Apply rules automatically
- Review only exceptions/edge cases
- Time: ~30-60 minutes

### Option C: Focus on High-Value Subset
- Tier 1: Review top 10 by demand
- Tier 2: Review only min < 0.10 years (very critical)
- ~30-40 parents total
- Time: ~1-2 hours

---

## Data Available

**Full CSV:** `101_Cutting_Candidates.csv` (actually 109 parents)

**Columns:**
- Priority (1-109)
- Tier (1-Zero Stock Skipped, 2-Could Improve)
- Parent_ID
- Glass_Type (cleaned name)
- Total_Purchased (all sizes combined)
- For each size: Qty, Purchased, Years
- Min_Years
- Has_Zero (Yes/No)

**Ready for your decision on how to proceed!**

---

## Next Steps

1. **Choose review approach** (A, B, or C above)
2. **Review the 109 cutting candidates**
3. **Then review the 270 non-cutting parents** (to understand complete inventory)
4. **Total: All 401 parents reviewed**

**Current Progress: 30 of 401 complete (7.5%)**
**Remaining: 371 parents**
