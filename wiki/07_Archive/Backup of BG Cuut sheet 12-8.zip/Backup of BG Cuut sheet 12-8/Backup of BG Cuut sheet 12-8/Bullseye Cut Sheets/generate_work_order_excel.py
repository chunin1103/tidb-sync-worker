#!/usr/bin/env python3
"""
Bullseye Glass Work Order Generator
Converts optimizer CSV output to warehouse-friendly Excel format

Input: Balanced_Cutting_Instructions.csv + inventory CSV
Output: Excel file with 4 tabs (Picks, Steps, Barcode_Labels, Inventory_Deltas)
"""

import csv
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from collections import defaultdict
import os
from datetime import datetime

class WorkOrderGenerator:
    """Generate Excel work orders from optimizer output"""

    def __init__(self, cutting_instructions_csv, inventory_csv):
        self.cutting_csv = cutting_instructions_csv
        self.inventory_csv = inventory_csv

        # Data structures
        self.plans = []
        self.inventory = {}  # parent_id -> {size -> product_data}

        # Output data
        self.picks = []
        self.steps = []
        self.labels = []
        self.deltas = []

    def load_data(self):
        """Load cutting instructions and inventory data"""
        print("Loading cutting instructions...")
        with open(self.cutting_csv, 'r') as f:
            reader = csv.DictReader(f)
            self.plans = list(reader)
        print(f"  Loaded {len(self.plans)} cutting plans")

        print("Loading inventory data...")
        with open(self.inventory_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)

            for row in reader:
                # Only process active 3mm sheet glass
                if row['Products Status'] != 'Active':
                    continue
                if '3mm' not in row['Product_Name']:
                    continue

                parent_id = row['Products_Parent_Id']
                product_name = row['Product_Name']

                # Determine size
                size = None
                if 'Half Sheet' in product_name:
                    size = 'Half'
                elif '10"x10"' in product_name or '10x10' in product_name:
                    size = '10x10'
                elif '5"x10"' in product_name or '5x10' in product_name:
                    size = '5x10'
                elif '5"x5"' in product_name or '5x5' in product_name:
                    size = '5x5'

                if size:
                    if parent_id not in self.inventory:
                        self.inventory[parent_id] = {}

                    self.inventory[parent_id][size] = {
                        'product_id': row['Product_ID'],
                        'vendor_sku': row['Vendor SKU'],
                        'product_name': product_name,
                        'qty': int(float(row['Quantity_in_Stock']))
                    }

        print(f"  Loaded inventory for {len(self.inventory)} parent IDs")

    def generate_work_order(self):
        """Generate all 4 tabs from cutting plans"""
        print("\nGenerating work order...")

        for plan in self.plans:
            parent_id = plan['Parent_ID']

            # Get product data for this parent
            products = self.inventory.get(parent_id, {})
            if not products:
                print(f"  WARNING: No inventory found for Parent {parent_id}")
                continue

            # Parse cutting operations
            cut_half = int(plan['Cut_Half_Sheets'])
            cut_10_to_510 = int(plan['Cut_10x10_to_5x10'])
            cut_10_to_55 = int(plan['Cut_10x10_to_5x5'])
            cut_510_to_55 = int(plan['Cut_5x10_to_5x5'])

            # Process this plan
            self._process_plan(parent_id, products, plan,
                             cut_half, cut_10_to_510, cut_10_to_55, cut_510_to_55)

        print(f"\nGenerated:")
        print(f"  {len(self.picks)} picks")
        print(f"  {len(self.steps)} cutting steps")
        print(f"  {sum(label['labels'] for label in self.labels)} barcode labels")
        print(f"  {len(self.deltas)} inventory deltas")

    def _process_plan(self, parent_id, products, plan,
                     cut_half, cut_10_to_510, cut_10_to_55, cut_510_to_55):
        """Process one cutting plan and generate all tab data"""

        # Track what we're producing
        produced = defaultdict(int)

        # PICKS TAB: What to pull from warehouse
        picks_for_plan = []

        if cut_half > 0:
            # Pull Half Sheets
            half_data = products.get('Half', {})
            if half_data:
                picks_for_plan.append({
                    'donor_id': half_data['product_id'],
                    'donor_sku': half_data['vendor_sku'],
                    'donor_name': half_data['product_name'],
                    'donor_size': 'Half Sheet',
                    'pick_qty': cut_half
                })

                # Cutting Half Sheets produces 10x10s and 5x10s
                produced['10x10'] += cut_half * 2
                produced['5x10'] += cut_half * 2

        # If cutting 10x10s from inventory (no Half Sheets cut)
        if cut_half == 0 and (cut_10_to_510 > 0 or cut_10_to_55 > 0):
            total_10_needed = cut_10_to_510 + cut_10_to_55
            ten_data = products.get('10x10', {})
            if ten_data:
                picks_for_plan.append({
                    'donor_id': ten_data['product_id'],
                    'donor_sku': ten_data['vendor_sku'],
                    'donor_name': ten_data['product_name'],
                    'donor_size': '10x10',
                    'pick_qty': total_10_needed
                })

        # If cutting 5x10s from inventory (no Half Sheets cut, no cascade)
        if cut_half == 0 and cut_510_to_55 > 0:
            five10_data = products.get('5x10', {})
            if five10_data:
                picks_for_plan.append({
                    'donor_id': five10_data['product_id'],
                    'donor_sku': five10_data['vendor_sku'],
                    'donor_name': five10_data['product_name'],
                    'donor_size': '5x10',
                    'pick_qty': cut_510_to_55
                })

        # Add picks to master list
        self.picks.extend(picks_for_plan)

        # STEPS TAB: Cutting instructions with final targets
        if cut_half > 0:
            # Calculate final targets from Half Sheet cutting
            final_10x10 = produced['10x10']
            final_5x10 = produced['5x10']
            final_5x5 = 0

            # Account for cascade cutting
            if cut_10_to_510 > 0:
                final_10x10 -= cut_10_to_510
                final_5x10 += cut_10_to_510 * 2

            if cut_10_to_55 > 0:
                final_10x10 -= cut_10_to_55
                final_5x5 += cut_10_to_55 * 4

            if cut_510_to_55 > 0:
                final_5x10 -= cut_510_to_55
                final_5x5 += cut_510_to_55 * 2

            # Build target string
            targets = []
            if final_10x10 > 0:
                targets.append(f"({final_10x10}) 10×10")
            if final_5x10 > 0:
                targets.append(f"({final_5x10}) 5×10")
            if final_5x5 > 0:
                targets.append(f"({final_5x5}) 5×5")

            target_str = ", ".join(targets) if targets else "None"

            half_data = products.get('Half', {})
            if half_data:
                self.steps.append({
                    'parent_id': parent_id,
                    'parent_sku': half_data['vendor_sku'].split('.')[0],  # Base SKU
                    'donor_id': half_data['product_id'],
                    'donor_sku': half_data['vendor_sku'],
                    'donor_name': half_data['product_name'],
                    'instruction': f"Cut {cut_half} Half Sheet{'s' if cut_half > 1 else ''}",
                    'target': target_str
                })

        # If cutting from inventory (no Half Sheets)
        elif cut_10_to_510 > 0 or cut_10_to_55 > 0:
            final_5x10 = cut_10_to_510 * 2
            final_5x5 = cut_10_to_55 * 4

            targets = []
            if final_5x10 > 0:
                targets.append(f"({final_5x10}) 5×10")
            if final_5x5 > 0:
                targets.append(f"({final_5x5}) 5×5")

            target_str = ", ".join(targets)

            ten_data = products.get('10x10', {})
            if ten_data:
                total_10 = cut_10_to_510 + cut_10_to_55
                self.steps.append({
                    'parent_id': parent_id,
                    'parent_sku': ten_data['vendor_sku'].split('.')[0],
                    'donor_id': ten_data['product_id'],
                    'donor_sku': ten_data['vendor_sku'],
                    'donor_name': ten_data['product_name'],
                    'instruction': f"Cut {total_10} 10×10{'s' if total_10 > 1 else ''}",
                    'target': target_str
                })

        elif cut_510_to_55 > 0:
            final_5x5 = cut_510_to_55 * 2

            five10_data = products.get('5x10', {})
            if five10_data:
                self.steps.append({
                    'parent_id': parent_id,
                    'parent_sku': five10_data['vendor_sku'].split('.')[0],
                    'donor_id': five10_data['product_id'],
                    'donor_sku': five10_data['vendor_sku'],
                    'donor_name': five10_data['product_name'],
                    'instruction': f"Cut {cut_510_to_55} 5×10{'s' if cut_510_to_55 > 1 else ''}",
                    'target': f"({final_5x5}) 5×5"
                })

        # BARCODE_LABELS TAB: Labels for pieces going back on shelf
        # Calculate net production for each size
        size_production = {
            'Half': -cut_half if cut_half > 0 else 0,
            '10x10': 0,
            '5x10': 0,
            '5x5': 0
        }

        # Add produced from Half Sheets
        if cut_half > 0:
            size_production['10x10'] += cut_half * 2
            size_production['5x10'] += cut_half * 2

        # Subtract cuts and add production
        if cut_10_to_510 > 0:
            size_production['10x10'] -= cut_10_to_510
            size_production['5x10'] += cut_10_to_510 * 2

        if cut_10_to_55 > 0:
            size_production['10x10'] -= cut_10_to_55
            size_production['5x5'] += cut_10_to_55 * 4

        if cut_510_to_55 > 0:
            size_production['5x10'] -= cut_510_to_55
            size_production['5x5'] += cut_510_to_55 * 2

        # Generate labels for positive production
        for size, qty in size_production.items():
            if qty > 0 and size in products:
                prod_data = products[size]
                self.labels.append({
                    'child_id': prod_data['product_id'],
                    'vendor_sku': prod_data['vendor_sku'],
                    'labels': qty,
                    'product_name': prod_data['product_name']
                })

        # INVENTORY_DELTAS TAB: All changes
        for size in ['Half', '10x10', '5x10', '5x5']:
            if size in products:
                net_change = size_production.get(size, 0)
                if net_change != 0:  # Only include changes
                    prod_data = products[size]
                    qty_before = prod_data['qty']
                    qty_after = qty_before + net_change

                    self.deltas.append({
                        'child_id': prod_data['product_id'],
                        'vendor_sku': prod_data['vendor_sku'],
                        'product_name': prod_data['product_name'],
                        'qty_before': qty_before,
                        'qty_after': qty_after,
                        'net_change': net_change
                    })

    def write_excel(self, output_path):
        """Write all data to Excel file with 4 tabs"""
        print(f"\nWriting Excel file to {output_path}...")

        wb = Workbook()

        # Remove default sheet
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])

        # Tab 1: Picks
        ws_picks = wb.create_sheet('Picks')
        ws_picks.append(['Donor_Child_ID', 'Donor_Vendor_SKU', 'Donor_Name', 'Donor_Size', 'Pick_Qty'])
        for pick in self.picks:
            ws_picks.append([
                pick['donor_id'],
                pick['donor_sku'],
                pick['donor_name'],
                pick['donor_size'],
                pick['pick_qty']
            ])
        self._format_header(ws_picks)

        # Tab 2: Steps
        ws_steps = wb.create_sheet('Steps')
        ws_steps.append(['Parent_ID', 'Parent_Vendor_SKU', 'Donor_Child_ID', 'Donor_Vendor_SKU',
                        'Donor_Name', 'Instruction', 'Target'])
        for step in self.steps:
            ws_steps.append([
                step['parent_id'],
                step['parent_sku'],
                step['donor_id'],
                step['donor_sku'],
                step['donor_name'],
                step['instruction'],
                step['target']
            ])
        self._format_header(ws_steps)

        # Tab 3: Barcode_Labels
        ws_labels = wb.create_sheet('Barcode_Labels')
        ws_labels.append(['Child_ID', 'Vendor_SKU', 'Labels_to_Print', 'Product_Name'])
        for label in self.labels:
            ws_labels.append([
                label['child_id'],
                label['vendor_sku'],
                label['labels'],
                label['product_name']
            ])
        self._format_header(ws_labels)

        # Tab 4: Inventory_Deltas
        ws_deltas = wb.create_sheet('Inventory_Deltas')
        ws_deltas.append(['Child_ID', 'Vendor_SKU', 'Product_Name', 'Qty_before', 'Qty_after', 'Net_Change'])
        for delta in self.deltas:
            ws_deltas.append([
                delta['child_id'],
                delta['vendor_sku'],
                delta['product_name'],
                delta['qty_before'],
                delta['qty_after'],
                delta['net_change']
            ])
        self._format_header(ws_deltas)

        # Save
        wb.save(output_path)
        print(f"  Excel file saved successfully!")

    def _format_header(self, worksheet):
        """Format header row with bold and fill"""
        header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
        header_font = Font(bold=True, color='FFFFFF')

        for cell in worksheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')

        # Auto-size columns
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            worksheet.column_dimensions[column_letter].width = adjusted_width


def main():
    """Main execution"""
    script_dir = os.path.dirname(os.path.abspath(__file__))

    cutting_csv = os.path.join(script_dir, "Balanced_Cutting_Instructions.csv")
    inventory_csv = os.path.join(script_dir, "Bullseye Cut Sheet Sample File 12-5-25.csv")

    # Generate output filename with date
    date_str = datetime.now().strftime("%Y-%m-%d")
    output_excel = os.path.join(script_dir, f"Bullseye_Work_Order_{date_str}.xlsx")

    if not os.path.exists(cutting_csv):
        print(f"Error: Cutting instructions not found: {cutting_csv}")
        print("Run glass_cutting_optimizer_balanced.py first!")
        return

    if not os.path.exists(inventory_csv):
        print(f"Error: Inventory file not found: {inventory_csv}")
        return

    # Generate work order
    generator = WorkOrderGenerator(cutting_csv, inventory_csv)
    generator.load_data()
    generator.generate_work_order()
    generator.write_excel(output_excel)

    print(f"\n[OK] Work order generated: {output_excel}")
    print("\nDone!")


if __name__ == "__main__":
    main()
