# Resume Point: Candidate #21 of 109

**Date:** December 7, 2025
**Progress:** Completed 20 of 109 cutting candidates (Tier 1: 20/22 complete)
**Next:** Continue with Candidate #21

---

## CRITICAL REFERENCE FILES

1. **Full candidate list:** `101_Cutting_Candidates.csv` (actually 109 candidates)
2. **Inventory data:** `Bullseye Cut Sheet Sample File 12-5-25.csv`
3. **Cutting reference guide:** `CUTTING_REFERENCE_GUIDE.md`
4. **All 30 completed plans:** `FINAL_DECISIONS_ALL_30_PLANS.md`

---

## DECISIONS FOR CANDIDATES 1-20

### Candidate #1: White Opalescent (388) - **REVISIT**
- Status: Marked to revisit at end
- Issue: Only 1 Half, creates zero, only 14 days on 10×10

### Candidate #2: Marigold Yellow Transparent (16381) - **CUT**
- **Decision: Cut 1 Half → 2×10×10 + 2×5×10**
- Gets 5×10 off zero
- Half sells only 2/year - acceptable to create zero

### Candidate #3: White Orange Opal Streaky (6972) - **CUT**
- **Decision: Cut 2×10×10 → 4×5×10**
- Gets 5×10 off zero to 122 days
- Applying "good enough" - evaluated 1,2,3,4,5 options

### Candidate #4: Light Aquamarine Blue Transparent Iridescent (146032) - **CUT**
- **Decision: Cut 1 Half → 2×10×10 + 2×5×10**
- Trade Half (4/year) for 10×10 (19/year - highest demand)

### Candidate #5: Soft Yellow Opal Deep Red Streaky (16441) - **CUT**
- **Decision: Cut 2×10×10 → 4×5×10**
- Gets 5×10 off zero to 162 days
- 10×10 has plenty to spare (12 pieces)

### Candidate #6: Emerald Green Transparent Iridescent (158750) - **CUT**
- **Decision: Cut 2 Half → 4×10×10 + 4×5×10**
- Half has ZERO sales - safe to cut all
- Perfect dead stock conversion

### Candidate #7: Charcoal Gray White Streaky (6010) - **CUT**
- **Decision: Cut 1 Half + cascade 1×10×10 → 5×5**
- Keeps Half in stock (not 2 Half)
- Important: 0 sales might be due to being out of stock

### Candidate #8: Erbium Pink Transparent Tint (156043) - **CUT**
- **Decision: Cut 1 Half + cascade 1×10×10 → 5×10**
- Better than cutting 2×10×10 - keeps 10×10 higher
- Gets 5×10 to 112 days

### Candidate #9: Umber Opalescent (16331) - **CUT**
- **Decision: Cut 1 Half → 2×10×10 + 2×5×10**
- Trade Half (1/year) for 10×10 & 5×10 (both 10/year)

### Candidate #10: Alchemy Clear Silver to Gold (153140) - **CUT**
- **Decision: Cut 1 Half + cascade 1×10×10 → 5×10**
- Half has 0 sales
- Gets 5×10 to 122 days

### Candidate #11: Olive Green Opal Forest Green Streaky (6984) - **CUT**
- **Decision: Cut 2 Half + cascade 1×10×10 → 5×5**
- Keeps 1 Half in stock
- Excellent balance: all 200+ days

### Candidate #12: Red Transparent Rainbow Iridescent (9714) - **CUT**
- **Decision: Cut 1 Half + cascade 1×10×10 → 5×10**
- Half has 0 sales
- 5×5 massively overstocked (4 years)

### Candidate #13: White Gold Pink Mottle Mix (179487) - **CUT**
- **Decision: Cut 1 Half + cascade 1×10×10 → 5×10**
- Keeps 1 Half in stock
- All sizes 100+ days

### Candidate #14: Garnet Red Transparent Iridescent (152454) - **CUT**
- **Decision: Cut 1 Half → 2×10×10 + 2×5×10**
- Half has 0 sales
- 5×5 massively overstocked (8 years!)

### Candidate #15: Red Amber Transparent Tint (146042) - **CUT**
- **Decision: Cut 2 Half → 4×10×10 + 4×5×10 (NO cascade)**
- Simpler than cascade option
- Min 182 days (better than 137 with cascade)

### Candidate #16: Black Opalescent Granite Ripple (171977) - **CUT**
- **Decision: Cut 2×10×10 → 4×5×10**
- Use overstocked 10×10 (not Half)
- Applying "good enough" - evaluated 1,2,3,4 options

### Candidate #17: Patina Green Mottle Opalescent (179433) - **CUT**
- **Decision: Cut 1 Half → 2×10×10 + 2×5×10**
- Low total sales (13/year) - better coverage needed
- Better than cutting 1×10×10 (146 vs 104 day min)

### Candidate #18: Opaline Opal with Light Cyan Opal (182344) - **CUT**
- **Decision: Cut 2 Half → 4×10×10 + 4×5×10**
- Chose 2 over 1 for better coverage (228 vs 137 day min)
- Low sales volume justified extra coverage

### Candidate #19: Neo-Lavender Shift Transparent Iridescent (153366) - **CUT**
- **Decision: Cut 1 Half → 2×10×10 + 2×5×10**
- Half has 0 sales
- Only gets 81 days but limited source

### Candidate #20: Reactive Ice Clear Transparent (6834) - **CUT**
- **Decision: Cut 1 Half → 2×10×10 + 2×5×10**
- Keeps 1 Half in stock
- Gets 10×10 to 73 days (below threshold but limited source)
- Makes 5×10 overstock worse (6.5→7.5 years) but necessary

---

## KEY LEARNINGS FROM CANDIDATES 1-20

### 1. Zero Sales ≠ No Demand
- **If sales = 0, might be out of stock**
- Keep at least 1 piece in stock for demand tracking
- Examples: Candidates #6, #7, #8, #11

### 2. Trade Slow-Sellers for Fast-Sellers
- Creating zero on 1-2/year item to help 10-20/year item is smart
- Examples: Candidates #2 (2/yr→zero), #4 (4/yr→zero), #9 (1/yr→zero)

### 3. Evaluate ALL Reasonable Options
- Don't stop at first solution
- Compare 1, 2, 3, 4+ operations
- Choose "good enough" (91+ days minimum)
- Examples: Candidates #3, #16, #17

### 4. Cascade vs Simple
- Cascade can be better OR worse
- Always compare both
- Example: Candidate #8 (cascade better), #15 (simple better)

### 5. Don't Overcut
- User corrected this tendency multiple times
- Start with MINIMUM to reach 91 days
- Only cut more if strong reason
- Examples: Candidates #16, #17

### 6. Consider Total Sales Volume
- Low volume (10-15/year) → extra coverage makes sense
- Better safe than sorry on slow-movers
- Examples: Candidates #17, #18

### 7. Use Overstocked Inventory First
- If 10×10 overstocked (2+ years), cut that instead of Half
- Example: Candidate #16 (10×10 at 2.3 years)

---

## DECISION FRAMEWORK (UPDATED)

### Priority Order:
1. Get products off zero
2. Optimize balance (0.25+ years = 91+ days)
3. Minimize labor (simplest solution that works)

### Cutting Strategy:
1. **Evaluate options:** 1, 2, 3, 4+ operations
2. **Find minimum:** What's the least cutting to reach 91 days?
3. **Check exceptions:**
   - Low total sales? Extra coverage might be worth it
   - Overstocked source? Use that instead
   - Cascade better or simpler?
4. **Apply "good enough":** Don't overcut

### Special Cases:
- **Half with 0 sales:** Safe to cut (but keep 1+ for tracking if possible)
- **Overstock source (2+ years):** Use that instead of Half
- **Low volume products (<15/year):** Extra coverage justified
- **Limited source (1-2 Half):** Accept below-threshold results

---

## HOW TO CONTINUE

### Next Candidate: #21

**Command to get data:**
```bash
grep "^21," "C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\101_Cutting_Candidates.csv"
```

Then get inventory:
```bash
grep ",[PARENT_ID]," "C:\Users\shawn\OneDrive\Documents\Claude Tools\Bullseye Cut Sheets\Bullseye Cut Sheet Sample File 12-5-25.csv"
```

### Format for Each Candidate:

```markdown
## Candidate #[X] of 109: [Glass Type]

**Parent ID:** [ID]
**Total Annual Sales:** [X] pieces/year

### CURRENT INVENTORY:

| Size | Qty | Sales/yr | **Years (Days)** |
|------|-----|----------|------------------|
| Half | X | X | X.XXX (XXX days) |
| 10×10 | X | X | X.XXX (XXX days) |
| 5×10 | X | X | X.XXX (XXX days) |
| 5×5 | X | X | X.XXX (XXX days) |

### RECOMMENDATION:

**[CUT or DON'T CUT]: [Operation]**

**AFTER CUTTING:**

| Size | After | Years (Days) |
|------|-------|--------------|
| [sizes with results] |

**Min: X.XXX years (XXX days)**

**Reasoning:**
- [Why this decision]
```

---

## REMAINING WORK

### Tier 1 Remaining: 2 candidates
- Candidate #21
- Candidate #22

### Tier 2: 87 candidates
- Candidates #23-109
- These are "could improve balance" (no zeros)

### After 109 Candidates:
- Review 270 non-cutting parents
- Finalize all decisions
- Generate Excel cut sheets

---

## CUTTING YIELDS (QUICK REFERENCE)

- **1 Half** → 2×10×10 + 2×5×10 (BOTH!)
- **1×10×10** → 2×5×10 OR 4×5×5
- **1×5×10** → 2×5×5

---

## SESSION NOTES

**Completed:** 20 of 109 (18%)
**Learning:** User corrected overcutting tendency - be more conservative
**Quality:** High - detailed evaluation of all options
**Speed:** ~3 minutes per candidate with discussion

**Resume from Candidate #21 with same methodology!**
