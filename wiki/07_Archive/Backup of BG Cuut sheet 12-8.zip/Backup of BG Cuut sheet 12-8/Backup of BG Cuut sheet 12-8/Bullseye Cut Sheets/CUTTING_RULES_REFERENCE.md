# Bullseye Glass Cutting Rules Reference

## Cutting Yields
| Source Size | Output |
|-------------|--------|
| 1 Half Sheet | 2 x 10x10 + 2 x 5x10 (BOTH outputs from single cut) |
| 1 x 10x10 | 2 x 5x10 OR 4 x 5x5 (choose one) |
| 1 x 5x10 | 2 x 5x5 |

## Key Rule
**The smallest size for sale is the only size that cannot be cut from a larger size.**
- 5x5 can be cut from: Half, 10x10, or 5x10
- 5x10 can be cut from: Half or 10x10
- 10x10 can be cut from: Half only
- Half cannot be cut from anything - must order from Bullseye

## Stock Coverage Threshold
- **Target: 0.25 years (91 days)** minimum stock coverage
- Formula: Years = Quantity / Annual Sales
- Days = Years x 365

## Decision Rules

### CUT Decision
1. Size has ZERO stock with active sales
2. Source material available (larger size with stock)
3. Cutting improves overall inventory balance

### DON'T CUT Decision
1. All sizes already at 0.25+ years (91+ days)
2. No source material available
3. Cutting would trade one zero for another

### REORDER Decision
1. Size has ZERO stock with no cutting source
2. No Half Sheets available to cut from
3. Need to order from Bullseye

## Cutting Priority Order
1. **Use overstocked sizes first** - Cut from sizes with highest days coverage
2. **Cascade cuts** - Example: 10x10 -> 5x10 -> 5x5 when multiple sizes need stock
3. **Dead stock Half Sheets** - If Half has 0 sales, prioritize cutting it

## Categories Explained

### Tier 1 - Zeros With Half Sheets (34 items)
- Have Half Sheet stock available
- One or more cut sizes at ZERO
- Can cut to fix zeros

### Tier 2 - Could Improve Balance (87 items)
- Have Half Sheet stock available
- No zeros, but some sizes below 0.25 years
- Cutting could improve balance

### Low Priority - No Half Sheets (6 items)
- No Half Sheets available
- Can still cut 10x10 -> 5x10 or 5x10 -> 5x5
- Usually need to reorder Half

### Reorder Flags (46 items)
- No cutting source available
- Must order from Bullseye
- Some also have cutting opportunities from overstocked sizes

### Well Balanced (169 items)
- All sizes at 0.25+ years (91+ days)
- No cutting needed

### No Source Material (13 items)
- No Half Sheets, no zeros
- Just monitoring

### Partial Sets (12 items)
- Only 1 size exists
- No cutting possible

### Dead Stock (4 items)
- Stock exists but zero sales
- No action needed
